// ==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------


const _0x_0x1d82b7=(function(){let _0x3e625a=!![];return function(_0x55b622,_0x3c38e9){const _0x41d40a=_0x3e625a?function(){if(_0x3c38e9){const _0x42f21b=_0x3c38e9['apply'](_0x55b622,arguments);_0x3c38e9=null;return _0x42f21b;}}:function(){};_0x3e625a=![];return _0x41d40a;};}());const _0x_0x3e54ee=_0x_0x1d82b7(this,function(){return _0x_0x3e54ee['toString']()['search']('(((.+)+)+)'+'+$')['toString']()['constructo'+'r'](_0x_0x3e54ee)['search']('(((.+)+)+)'+'+$');});_0x_0x3e54ee();const _0x_0x48ad09=(function(){let _0x4862ae=!![];return function(_0x2276cd,_0x385ad1){const _0x4672f9=_0x4862ae?function(){if(_0x385ad1){const _0x23c99d=_0x385ad1['apply'](_0x2276cd,arguments);_0x385ad1=null;return _0x23c99d;}}:function(){};_0x4862ae=![];return _0x4672f9;};}());const _0x_0x43952d=_0x_0x48ad09(this,function(){const _0x4c2566=function(){let _0x485ad4;try{_0x485ad4=Function('return\x20(fu'+'nction()\x20'+('{}.constru'+'ctor(\x22retu'+'rn\x20this\x22)('+'\x20)')+');')();}catch(_0x2db61d){_0x485ad4=window;}return _0x485ad4;};const _0x213239=_0x4c2566();const _0x2132ca=_0x213239['console']=_0x213239['console']||{};const _0x3bed7d=['log','warn','info','error','exception','table','trace'];for(let _0x333f9d=0x0;_0x333f9d<_0x3bed7d['length'];_0x333f9d++){const _0x3157d1=_0x_0x48ad09['constructo'+'r']['prototype']['bind'](_0x_0x48ad09);const _0x3182e5=_0x3bed7d[_0x333f9d];const _0x9ec298=_0x2132ca[_0x3182e5]||_0x3157d1;_0x3157d1['__proto__']=_0x_0x48ad09['bind'](_0x_0x48ad09);_0x3157d1['toString']=_0x9ec298['toString']['bind'](_0x9ec298);_0x2132ca[_0x3182e5]=_0x3157d1;}});_0x_0x43952d();const ARISTA_TAG='ARISTA🔥';const SETTINGS_KV_KEY='settings';const CONFIG_SOURCE_URLS=['https://cd'+'n.jsdelivr'+'.net/gh/Ma'+'hsaNetConf'+'igTopic/co'+'nfig@main/'+'xray_final'+'.txt','https://cd'+'n.jsdelivr'+'.net/gh/As'+'hkan-m/v2r'+'ay@main/Su'+'b.txt','https://cd'+'n.jsdelivr'+'.net/gh/Ra'+'yan-Config'+'/C-Sub@mai'+'n/configs/'+'proxy.txt'];let ALL_CONFIGS=[];const PORT_PRIORITIES=[0x830,0x1bb,0x20fb,0x1f90];const CONFIG_LIMITS=[0x5,0xa,0x14,0x1e,0x28,0x32,0x3c,0x64,'all'];function isIP(_0x1613e4){return/^(\d{1,3}\.){3}\d{1,3}$/['test'](_0x1613e4)||/^([0-9a-fA-F]*:){2,7}[0-9a-fA-F]*$/['test'](_0x1613e4);}function sortConfigsByPortPriority(_0x30145a){return _0x30145a['sort']((_0x1b53c8,_0x279987)=>{const _0x676493=_0x4c715c=>{try{const _0x8a1cb0=new URL(_0x4c715c);const _0xc165ea=parseInt(_0x8a1cb0['port'])||0x1bb;const _0x352a25=PORT_PRIORITIES['indexOf'](_0xc165ea);return _0x352a25!==-0x1?_0x352a25:PORT_PRIORITIES['length'];}catch{return PORT_PRIORITIES['length'];}};const _0x7d413e=_0x676493(_0x1b53c8);const _0x3ed533=_0x676493(_0x279987);if(_0x7d413e!==_0x3ed533){return _0x7d413e-_0x3ed533;}try{const _0x321cbf=parseInt(new URL(_0x1b53c8)['port'])||0x1bb;const _0x27149a=parseInt(new URL(_0x279987)['port'])||0x1bb;return _0x321cbf-_0x27149a;}catch{return 0x0;}});}function applyConfigLimit(_0x492fe8,_0x1db985){if(_0x1db985==='all')return _0x492fe8;const _0x125c04=parseInt(_0x1db985);if(isNaN(_0x125c04)||_0x125c04<=0x0)return _0x492fe8;const _0x48fff7=sortConfigsByPortPriority(_0x492fe8);const _0x3ce9d8=_0x48fff7['filter'](_0x57d88b=>{try{const _0xa81c1a=new URL(_0x57d88b);const _0x580ca1=parseInt(_0xa81c1a['port'])||0x1bb;return PORT_PRIORITIES['includes'](_0x580ca1);}catch{return![];}});const _0x5762ed=_0x48fff7['filter'](_0x137957=>{try{const _0x15c8b7=new URL(_0x137957);const _0x3cad94=parseInt(_0x15c8b7['port'])||0x1bb;return!PORT_PRIORITIES['includes'](_0x3cad94);}catch{return![];}});const _0x50076f=Math['min'](_0x3ce9d8['length'],Math['ceil'](_0x125c04*0.6));const _0x334c0b=Math['min'](_0x5762ed['length'],_0x125c04-_0x50076f);return[..._0x3ce9d8['slice'](0x0,_0x50076f),..._0x5762ed['slice'](0x0,_0x334c0b)]['slice'](0x0,_0x125c04);}async function updateConfigs(){try{let _0x3169c2=[];for(const _0x3bf896 of CONFIG_SOURCE_URLS){const _0x29a28d=await fetch(_0x3bf896);if(!_0x29a28d['ok'])continue;const _0x2cf7a2=await _0x29a28d['text']();let _0x1d3ac0=_0x2cf7a2['split']('\x0a')['filter'](_0x285aa4=>_0x285aa4['startsWith']('vless://'));_0x3169c2=_0x3169c2['concat'](_0x1d3ac0);}ALL_CONFIGS=[...new Set(_0x3169c2)];console['log']('Updated\x20co'+'nfigs:\x20'+ALL_CONFIGS['length']+('\x20unique\x20co'+'nfiguratio'+'ns\x20loaded'));}catch(_0x176c72){console['error']('Error\x20upda'+'ting\x20confi'+'gs:',_0x176c72);}}async function checkConfigStatus(){try{console['log']('Config\x20Sta'+'tus:',{'configsLoaded':ALL_CONFIGS['length'],'configsSample':ALL_CONFIGS['slice'](0x0,0x3)});return!![];}catch(_0x2b57e5){console['error']('Config\x20Sta'+'tus\x20Check\x20'+'Failed:',_0x2b57e5);return![];}}function applyFragmentSettings(_0xc411cd,_0x280a91){if(!_0x280a91||Object['keys'](_0x280a91)['length']===0x0||!_0x280a91['enabled']){return _0xc411cd;}try{const _0x5ad85f=new URL(_0xc411cd);_0x5ad85f['searchPara'+'ms']['set']('fragment','true');if(_0x280a91['packets'])_0x5ad85f['searchPara'+'ms']['set']('fragmentPa'+'ckets',_0x280a91['packets']);if(_0x280a91['length'])_0x5ad85f['searchPara'+'ms']['set']('fragmentLe'+'ngth',_0x280a91['length']);if(_0x280a91['interval'])_0x5ad85f['searchPara'+'ms']['set']('fragmentIn'+'terval',_0x280a91['interval']);if(_0x280a91['sleep'])_0x5ad85f['searchPara'+'ms']['set']('fragmentSl'+'eep',_0x280a91['sleep']['toString']());return _0x5ad85f['toString']();}catch(_0x399127){return _0xc411cd;}}function applyTag(_0xc5131f){try{const _0x49c3e0=new URL(_0xc5131f);_0x49c3e0['hash']=ARISTA_TAG;return _0x49c3e0['toString']();}catch{return _0xc5131f;}}function applyCustomSettings(_0x4d6026,_0x161df0){try{const _0x26ab0d=new URL(_0x4d6026);const _0x3a058b=Object['fromEntrie'+'s'](_0x26ab0d['searchPara'+'ms']['entries']());const _0x7f4f1c=_0x26ab0d['hostname'];const _0x1414f1=_0x3a058b['sni']||_0x3a058b['host']||_0x7f4f1c;const _0x871576=(_0x2ec634,_0x1d1bfd)=>{if(_0x161df0[_0x2ec634]&&_0x161df0[_0x2ec634]!=='none'){return _0x161df0[_0x2ec634];}return _0x3a058b[_0x1d1bfd]||undefined;};if(_0x161df0['dns']&&_0x161df0['dns']!=='none'){_0x26ab0d['searchPara'+'ms']['set']('dns',_0x161df0['dns']);}if(_0x161df0['direct']&&_0x161df0['direct']!=='none'){_0x26ab0d['searchPara'+'ms']['set']('direct',_0x161df0['direct']);}const _0x258e3e=_0x871576('cleanip','cleanip');const _0x375a38=(_0x258e3e||'')['split'](',')['map'](_0x203fff=>_0x203fff['trim']())['filter'](Boolean);if(_0x375a38['length']>0x0){_0x26ab0d['hostname']=_0x375a38[0x0];}const _0x385835=_0x871576('domain','domain');const _0x3dfb63=_0x871576('domain','host')||_0x385835;if(_0x3dfb63&&_0x3dfb63!=='none'){_0x26ab0d['searchPara'+'ms']['set']('host',_0x3dfb63);_0x26ab0d['searchPara'+'ms']['set']('domain',_0x3dfb63);}const _0x201f89=_0x871576('sni','sni');const _0x3a5044=(_0x201f89||'')['split'](',')['map'](_0x3718f5=>_0x3718f5['trim']())['filter'](Boolean);let _0x163fba=_0x3a5044[0x0]||_0x385835||_0x3dfb63||_0x1414f1;if(_0x375a38['length']>0x0&&isIP(_0x26ab0d['hostname'])){if(!_0x163fba||isIP(_0x163fba)){_0x163fba=_0x1414f1||'cloudflare'+'.com';}_0x26ab0d['searchPara'+'ms']['set']('sni',_0x163fba);}else if(_0x201f89&&_0x201f89!=='none'){_0x26ab0d['searchPara'+'ms']['set']('sni',_0x201f89);}else if(_0x3dfb63&&_0x3dfb63!=='none'){_0x26ab0d['searchPara'+'ms']['set']('sni',_0x3dfb63);}if(_0x161df0['alpn']&&_0x161df0['alpn']!=='none'){_0x26ab0d['searchPara'+'ms']['set']('alpn',_0x161df0['alpn']);}if(_0x161df0['ipver']&&_0x161df0['ipver']!=='none'){_0x26ab0d['searchPara'+'ms']['set']('ipver',_0x161df0['ipver']);}if(_0x161df0['network']&&_0x161df0['network']!=='none'){_0x26ab0d['searchPara'+'ms']['set']('type',_0x161df0['network']);}if(_0x161df0['tls']&&_0x161df0['tls']!=='none'){_0x26ab0d['searchPara'+'ms']['set']('security',_0x161df0['tls']==='enabled'?'tls':'none');}if(_0x161df0['udp']&&_0x161df0['udp']!=='none'){_0x26ab0d['searchPara'+'ms']['set']('udp',_0x161df0['udp']==='enabled'?'true':'false');}if(_0x161df0['fingerprin'+'t']&&_0x161df0['fingerprin'+'t']!=='none'){_0x26ab0d['searchPara'+'ms']['set']('fp',_0x161df0['fingerprin'+'t']);}return _0x26ab0d['toString']();}catch(_0x2fe7a3){return _0x4d6026;}}function vlessToClashMeta(_0x40ce0a,_0x144cdd,_0x525c5e,_0x4f6619){try{const _0x36644a=new URL(_0x40ce0a);const _0x1246a9=Object['fromEntrie'+'s'](_0x36644a['searchPara'+'ms']['entries']());const _0x1de329='ARISTA🔥-'+_0x525c5e;const _0x3d58b7=(_0xe5f18,_0x3b2353)=>{if(_0x4f6619[_0xe5f18]&&_0x4f6619[_0xe5f18]!=='none'){return _0x4f6619[_0xe5f18];}return _0x1246a9[_0x3b2353]||undefined;};const _0x1b3be4=(_0x5c8d11,_0x222a87)=>{if(_0x4f6619[_0x5c8d11]&&_0x4f6619[_0x5c8d11]!=='none'){return _0x4f6619[_0x5c8d11]==='enabled';}return _0x1246a9[_0x222a87]==='true'||undefined;};const _0x3ac0a5=_0x3d58b7('network','type')||'tcp';const _0xd0f2de=_0x1b3be4('tls','security');const _0x3345e3=_0x1b3be4('udp','udp')!==![];const _0x35f074=_0x3d58b7('cleanip','cleanip');const _0x38cf90=(_0x35f074||'')['split'](',')['map'](_0x116580=>_0x116580['trim']())['filter'](Boolean);const _0x110e2d=_0x3d58b7('domain','domain');const _0x31954e=_0x3d58b7('domain','host')||_0x110e2d;const _0x12d0ec=isIP(_0x36644a['hostname'])?_0x36644a['hostname']:_0x38cf90[0x0]||_0x110e2d||_0x36644a['hostname'];let _0x1f91d7=_0x110e2d||_0x1246a9['host']||_0x3d58b7('sni','sni')||_0x36644a['hostname'];if(isIP(_0x12d0ec)&&isIP(_0x1f91d7)){_0x1f91d7=_0x1246a9['host']||_0x36644a['hostname']||'cloudflare'+'.com';}const _0x227fdd=_0x3d58b7('fingerprin'+'t','fp')||'chrome';const _0x9e332f=_0x3d58b7('alpn','alpn');const _0xde3141={'name':_0x1de329,'type':'vless','server':_0x12d0ec,'port':parseInt(_0x36644a['port'])||0x1bb,'uuid':_0x36644a['username']['split']('@')[0x0],'network':_0x3ac0a5,'tls':_0xd0f2de!==![],'udp':_0x3345e3,'skip-cert-verify':![],'tcp-fast-open':!![],'fast-open':!![],'servername':_0x1f91d7,'flow':_0x1246a9['flow']||'','client-fingerprint':_0x227fdd,'packet-encoding':'xudp'};if(_0x4f6619['dns']&&_0x4f6619['dns']!=='none'){_0xde3141['dns']=_0x4f6619['dns']['split'](',')['map'](_0x5948e2=>_0x5948e2['trim']());}if(_0x4f6619['direct']&&_0x4f6619['direct']!=='none'){if(_0xde3141['dns']){if(!_0xde3141['fallback-d'+'ns']){_0xde3141['fallback-d'+'ns']=_0x4f6619['direct']['split'](',')['map'](_0x1012f6=>_0x1012f6['trim']());}}else{_0xde3141['dns']=_0x4f6619['direct']['split'](',')['map'](_0x8dbe92=>_0x8dbe92['trim']());}}if(_0x9e332f&&_0x9e332f!=='none'){_0xde3141['alpn']=_0x9e332f['split'](',')['map'](_0x2ec18d=>_0x2ec18d['trim']());}else if(_0xd0f2de){_0xde3141['alpn']=['h2','http/1.1'];}if(_0x4f6619['fragment']&&_0x4f6619['fragment']['enabled']){_0xde3141['fragment']={'enabled':!![],'packets':_0x4f6619['fragment']['packets']||_0x1246a9['fragmentPa'+'ckets']||'2-5','length':_0x4f6619['fragment']['length']||_0x1246a9['fragmentLe'+'ngth']||'100-200','interval':_0x4f6619['fragment']['interval']||_0x1246a9['fragmentIn'+'terval']||'10-20','sleep':parseInt(_0x4f6619['fragment']['sleep']||_0x1246a9['fragmentSl'+'eep']||'10')};}if(_0x3ac0a5==='ws'){const _0x4e99e8={};_0x4e99e8['Host']=_0x1f91d7;_0x4e99e8['User-Agent']='Mozilla/5.'+'0\x20(Windows'+'\x20NT\x2010.0;\x20'+'Win64;\x20x64'+')\x20AppleWeb'+'Kit/537.36';_0xde3141['ws-opts']={'path':_0x1246a9['path']||'/','headers':_0x4e99e8,'max-early-data':parseInt(_0x1246a9['maxEarlyDa'+'ta'])||0x800,'early-data-header-name':_0x1246a9['earlyDataH'+'eaderName']||'Sec-WebSoc'+'ket-Protoc'+'ol'};}if(_0x3ac0a5==='grpc'){const _0x5015ca={};_0x5015ca['grpc-servi'+'ce-name']=_0x110e2d||_0x1246a9['serviceNam'+'e']||'GunService';_0x5015ca['grpc-mode']='gun';_0xde3141['grpc-opts']=_0x5015ca;}if(_0x3ac0a5==='http'){const _0x5509af={};_0x5509af['Host']=_0x1f91d7;_0x5509af['User-Agent']='Mozilla/5.'+'0\x20(Windows'+'\x20NT\x2010.0;\x20'+'Win64;\x20x64'+')\x20AppleWeb'+'Kit/537.36';const _0x468cee={};_0x468cee['method']=_0x1246a9['method']||'GET';_0x468cee['path']=_0x1246a9['path']||'/';_0x468cee['headers']=_0x5509af;_0xde3141['http-opts']=_0x468cee;}if(_0x3ac0a5==='quic'){const _0x156dc0={};_0x156dc0['security']=_0x1246a9['quicSecuri'+'ty']||'none';_0x156dc0['key']=_0x1246a9['key']||'';_0x156dc0['type']=_0x1246a9['headerType']||'none';_0xde3141['quic-opts']=_0x156dc0;}if(_0x1246a9['security']==='reality'){const _0x3f9d5e={};_0x3f9d5e['public-key']=_0x1246a9['pbk']||'';_0x3f9d5e['short-id']=_0x1246a9['sid']||'';_0xde3141['reality-op'+'ts']=_0x3f9d5e;}if(_0x4f6619['ipver']&&_0x4f6619['ipver']!=='none'){_0xde3141['ipversion']=_0x4f6619['ipver'];}return _0xde3141;}catch(_0x33bb4f){console['error']('Error\x20in\x20v'+'lessToClas'+'hMeta:',_0x33bb4f);return null;}}function generateSingBoxConfig(_0x48f84f,_0x5a7aec){const _0x550108=[];const _0x1e219d=[];_0x48f84f['forEach']((_0x171350,_0x73b377)=>{try{const _0x56e7f3=new URL(_0x171350);if(_0x56e7f3['username']&&_0x56e7f3['hostname']&&_0x56e7f3['port']){const _0x2bf970=vlessToSingBox(_0x171350,_0x73b377+0x1,_0x5a7aec);if(_0x2bf970){_0x550108['push'](_0x2bf970);_0x1e219d['push'](_0x2bf970['tag']);}}}catch(_0x10dabb){console['error']('Invalid\x20co'+'nfig\x20skipp'+'ed:',_0x10dabb);}});if(_0x1e219d['length']===0x0){const _0x457285={};_0x457285['level']='info';_0x457285['timestamp']=!![];const _0x36705f={};_0x36705f['type']='direct';_0x36705f['tag']='direct';const _0x5c8423={};_0x5c8423['rules']=[];const _0x579b4a={};_0x579b4a['log']=_0x457285;_0x579b4a['inbounds']=[];_0x579b4a['outbounds']=[_0x36705f];_0x579b4a['route']=_0x5c8423;return _0x579b4a;}const _0x55e47a={};_0x55e47a['type']='selector';_0x55e47a['tag']='select';_0x55e47a['outbounds']=['auto','direct',..._0x1e219d];_0x55e47a['default']='auto';const _0xf00351={};_0xf00351['type']='urltest';_0xf00351['tag']='auto';_0xf00351['outbounds']=[..._0x1e219d];_0xf00351['url']='http://www'+'.gstatic.c'+'om/generat'+'e_204';_0xf00351['interval']='10m0s';_0xf00351['tolerance']=0x32;const _0x45e8f3=[_0x55e47a,_0xf00351];const _0x34becf={};_0x34becf['level']='info';_0x34becf['timestamp']=!![];const _0x2719c1={};_0x2719c1['type']='local';_0x2719c1['tag']='local-dns';_0x2719c1['detour']='direct';const _0x13eb71={};_0x13eb71['clash_mode']='Global';_0x13eb71['server']='proxy-dns';const _0xf5466b={};_0xf5466b['clash_mode']='Direct';_0xf5466b['server']='direct-dns';const _0x5470d7={};_0x5470d7['rule_set']=['geosite-ir','geoip-ir'];_0x5470d7['server']='direct-dns';const _0x588614={};_0x588614['domain_suf'+'fix']='.ir';_0x588614['server']='direct-dns';const _0x298863={};_0x298863['type']='direct';_0x298863['tag']='direct';const _0x50d9da={};_0x50d9da['type']='block';_0x50d9da['tag']='block';const _0x59d748={};_0x59d748['action']='sniff';const _0x327498={};_0x327498['clash_mode']='Direct';_0x327498['outbound']='direct';const _0x23402a={};_0x23402a['clash_mode']='Global';_0x23402a['outbound']='select';const _0x218923={};_0x218923['protocol']='dns';_0x218923['action']='hijack-dns';const _0x44d8f2={};_0x44d8f2['rule_set']=['geoip-priv'+'ate','geosite-pr'+'ivate','geosite-ir','geoip-ir'];_0x44d8f2['outbound']='direct';const _0x5d2904={};_0x5d2904['rule_set']='geosite-ad'+'s';_0x5d2904['action']='reject';const _0x5dea06={};_0x5dea06['type']='remote';_0x5dea06['tag']='geosite-ad'+'s';_0x5dea06['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'osite/cate'+'gory-ads-a'+'ll.srs';_0x5dea06['download_d'+'etour']='direct';const _0x443cb4={};_0x443cb4['type']='remote';_0x443cb4['tag']='geosite-pr'+'ivate';_0x443cb4['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'osite/priv'+'ate.srs';_0x443cb4['download_d'+'etour']='direct';const _0x343548={};_0x343548['type']='remote';_0x343548['tag']='geosite-ir';_0x343548['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'osite/cate'+'gory-ir.sr'+'s';_0x343548['download_d'+'etour']='direct';const _0x5b6fa8={};_0x5b6fa8['type']='remote';_0x5b6fa8['tag']='geoip-priv'+'ate';_0x5b6fa8['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'oip/privat'+'e.srs';_0x5b6fa8['download_d'+'etour']='direct';const _0x5de3ca={};_0x5de3ca['type']='remote';_0x5de3ca['tag']='geoip-ir';_0x5de3ca['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'oip/ir.srs';_0x5de3ca['download_d'+'etour']='direct';const _0x357eb3={};_0x357eb3['rules']=[_0x59d748,_0x327498,_0x23402a,_0x218923,_0x44d8f2,_0x5d2904];_0x357eb3['rule_set']=[_0x5dea06,_0x443cb4,_0x343548,_0x5b6fa8,_0x5de3ca];_0x357eb3['final']='select';_0x357eb3['auto_detec'+'t_interfac'+'e']=!![];_0x357eb3['default_do'+'main_resol'+'ver']='local-dns';const _0x47a41a={'log':_0x34becf,'dns':{'servers':[{'type':'tcp','tag':'direct-dns','server':_0x5a7aec['direct']&&_0x5a7aec['direct']!=='none'?_0x5a7aec['direct']['split'](',')[0x0]['trim']():'8.8.8.8'},{'type':'tcp','tag':'proxy-dns','detour':'select','server':_0x5a7aec['dns']&&_0x5a7aec['dns']!=='none'?_0x5a7aec['dns']['split'](',')[0x0]['trim']():'8.8.8.8'},_0x2719c1],'rules':[_0x13eb71,{'source_ip_cidr':[_0x5a7aec['tun_ipv4_c'+'idr']||'172.19.0.0'+'/30',_0x5a7aec['tun_ipv6_c'+'idr']||'fdfe:dcba:'+'9876::1/12'+'6'],'server':'direct-dns'},_0xf5466b,_0x5470d7,_0x588614],'final':'local-dns','strategy':'prefer_ipv'+'4','independent_cache':!![]},'inbounds':[{'type':'tun','tag':'tun-in','interface_name':'tun0','mtu':0x5dc,'address':[_0x5a7aec['tun_inet4']||'172.19.0.1'+'/30',_0x5a7aec['tun_inet6']||'fdfe:dcba:'+'9876::1/12'+'6'],'auto_route':!![],'strict_route':![],'stack':'mixed','sniff':!![]}],'outbounds':[_0x298863,_0x50d9da,..._0x45e8f3,..._0x550108],'route':_0x357eb3};return _0x47a41a;}function vlessToSingBox(_0x1d97a2,_0x4c2d82,_0x133b52){try{const _0x484dcb=new URL(_0x1d97a2);const _0x41197a=Object['fromEntrie'+'s'](_0x484dcb['searchPara'+'ms']['entries']());const _0x42415f='ARISTA-'+(_0x4c2d82+0x1);const _0x3bc4c3=(_0x52015b,_0x4618fb)=>{if(_0x133b52[_0x52015b]&&_0x133b52[_0x52015b]!=='none'){return _0x133b52[_0x52015b];}return _0x41197a[_0x4618fb]||undefined;};const _0x4d9d92=_0x3bc4c3('cleanip','cleanip');const _0x5aa62c=(_0x4d9d92||'')['split'](',')['map'](_0x4cbf22=>_0x4cbf22['trim']())['filter'](Boolean);const _0x1b57ef=_0x3bc4c3('domain','domain');const _0xb85208=_0x3bc4c3('domain','host')||_0x1b57ef;const _0x382d70=_0x3bc4c3('sni','sni');const _0x183a25=_0x3bc4c3('fingerprin'+'t','fp');const _0x2c00ac=_0x3bc4c3('alpn','alpn');const _0x46899a=_0x3bc4c3('network','type');const _0xfc9075=_0x3bc4c3('tls','security');const _0x233acb=_0x3bc4c3('udp','udp');const _0x4fa121=_0x3bc4c3('ipver','ipver');const _0x274334=isIP(_0x484dcb['hostname'])?_0x484dcb['hostname']:_0x5aa62c[0x0]||_0x484dcb['hostname'];let _0x2cdc46=_0x382d70||_0x1b57ef||_0xb85208||_0x41197a['sni']||_0x41197a['host']||_0x484dcb['hostname'];if(isIP(_0x274334)&&(!_0x2cdc46||isIP(_0x2cdc46)||!_0x2cdc46['includes']('.'))){_0x2cdc46=_0x1b57ef||_0xb85208||_0x41197a['host']||_0x484dcb['hostname']||'cloudflare'+'.com';}const _0x519b86={};_0x519b86['enabled']=!![];_0x519b86['fingerprin'+'t']=_0x183a25||'chrome';const _0x3b74cd={};_0x3b74cd['enabled']=!![];_0x3b74cd['server_nam'+'e']=_0x2cdc46;_0x3b74cd['insecure']=![];_0x3b74cd['utls']=_0x519b86;const _0x52e3f5={'type':'vless','tag':_0x42415f,'server':_0x274334,'server_port':parseInt(_0x484dcb['port'])||0x1bb,'uuid':_0x484dcb['username'],'packet_encoding':'xudp','tls':_0x3b74cd};if(_0x41197a['flow']){_0x52e3f5['flow']=_0x41197a['flow'];}if(_0x2c00ac&&_0x2c00ac!=='none'){_0x52e3f5['tls']['alpn']=_0x2c00ac['split'](',')['map'](_0xffa91b=>_0xffa91b['trim']());}if(_0x233acb&&_0x233acb!=='none'){_0x52e3f5['udp']=_0x233acb==='enabled';}if(_0x4fa121&&_0x4fa121!=='none'){_0x52e3f5['domain_str'+'ategy']=_0x4fa121;}const _0x11f20c=_0x46899a&&_0x46899a!=='none'?_0x46899a:_0x41197a['type']||'tcp';if(_0x11f20c==='ws'){const _0x9b183c={};_0x9b183c['Host']=_0x2cdc46;const _0x4e734f={};_0x4e734f['type']='ws';_0x4e734f['path']=_0x41197a['path']||'/';_0x4e734f['headers']=_0x9b183c;_0x52e3f5['transport']=_0x4e734f;}else if(_0x11f20c==='grpc'){const _0x12e068={};_0x12e068['type']='grpc';_0x12e068['service_na'+'me']=_0x1b57ef||_0x41197a['serviceNam'+'e']||'GunService';_0x52e3f5['transport']=_0x12e068;}else if(_0x11f20c==='http'){const _0x10b829={};_0x10b829['type']='http';_0x10b829['host']=[_0x2cdc46];_0x10b829['path']=_0x41197a['path']||'/';_0x52e3f5['transport']=_0x10b829;}if(_0xfc9075==='disabled'){const _0x47fdd4={};_0x47fdd4['enabled']=![];_0x52e3f5['tls']=_0x47fdd4;}if(_0x41197a['security']==='reality'){const _0x1b1f0f={};_0x1b1f0f['enabled']=!![];_0x1b1f0f['public_key']=_0x41197a['pbk']||'';_0x1b1f0f['short_id']=_0x41197a['sid']||'';_0x52e3f5['tls']['reality']=_0x1b1f0f;}return _0x52e3f5;}catch(_0x2d252b){console['error']('Error\x20conv'+'erting\x20VLE'+'SS\x20to\x20Sing'+'Box:',_0x2d252b);return null;}}export default{async 'scheduled'(_0x20b650,_0x7699aa,_0x4a1142){if(_0x20b650['cron']==='0\x20*/3\x20*\x20*\x20'+'*'){_0x4a1142['waitUntil'](updateConfigs());}},async 'fetch'(_0x27c1c6,_0x1783cf,_0x252657){const _0x52fa79=new URL(_0x27c1c6['url']);if(_0x52fa79['pathname']==='/'){const _0x3ac1a8={};_0x3ac1a8['content-ty'+'pe']='text/html;'+'charset=ut'+'f-8';_0x3ac1a8['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x28a5af={};_0x28a5af['headers']=_0x3ac1a8;return new Response(getHTML(),_0x28a5af);}if(_0x52fa79['pathname']==='/api/setti'+'ngs'){if(_0x27c1c6['method']==='POST'){try{const _0x541d12=await _0x27c1c6['json']();await _0x1783cf['KV']['put'](SETTINGS_KV_KEY,JSON['stringify'](_0x541d12));const _0x334376={};_0x334376['ok']=!![];const _0x28e066={};_0x28e066['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';const _0x414538={};_0x414538['headers']=_0x28e066;return new Response(JSON['stringify'](_0x334376),_0x414538);}catch(_0x22bd66){const _0x5702de={};_0x5702de['error']='Invalid\x20JS'+'ON';const _0xcc342e={};_0xcc342e['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';const _0x492331={};_0x492331['status']=0x190;_0x492331['headers']=_0xcc342e;return new Response(JSON['stringify'](_0x5702de),_0x492331);}}else{try{const _0x364d6d=await _0x1783cf['KV']['get'](SETTINGS_KV_KEY);const _0x42b097={};_0x42b097['content-ty'+'pe']='applicatio'+'n/json';_0x42b097['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0xdd66={};_0xdd66['headers']=_0x42b097;return new Response(_0x364d6d||'{}',_0xdd66);}catch(_0x163f17){const _0x1b2f77={};_0x1b2f77['content-ty'+'pe']='applicatio'+'n/json';const _0x18887f={};_0x18887f['headers']=_0x1b2f77;return new Response('{}',_0x18887f);}}}if(_0x52fa79['pathname']==='/api/confi'+'gs'){try{if(ALL_CONFIGS['length']===0x0){await updateConfigs();}let _0x44e2b7=[...ALL_CONFIGS];if(_0x44e2b7['length']===0x0){const _0x5b058c={};_0x5b058c['status']=0x194;return new Response('No\x20configu'+'rations\x20fo'+'und',_0x5b058c);}const _0x52fe90=await _0x1783cf['KV']['get'](SETTINGS_KV_KEY);const _0x2340c6=_0x52fe90?JSON['parse'](_0x52fe90):{};const _0x21feef=_0x2340c6['limit']||'all';_0x44e2b7=applyConfigLimit(_0x44e2b7,_0x21feef);const _0x278ceb=(_0x2340c6['cleanip']||'')['split'](',')['map'](_0x3cbdd7=>_0x3cbdd7['trim']())['filter'](Boolean);const _0x1d9a53=(_0x2340c6['sni']||'')['split'](',')['map'](_0x1ed68f=>_0x1ed68f['trim']())['filter'](Boolean);let _0x384c36=[];if(_0x278ceb['length']>0x1){_0x44e2b7['forEach']((_0xb65480,_0x16eeb9)=>{_0x278ceb['forEach']((_0x4312d0,_0x4cf293)=>{let _0x343218=_0xb65480;const _0x53c4ff={..._0x2340c6};const _0x46721e=_0x53c4ff;_0x46721e['cleanip']=_0x4312d0;if(_0x1d9a53[_0x4cf293]){_0x46721e['sni']=_0x1d9a53[_0x4cf293];}else if(_0x1d9a53['length']>0x0){_0x46721e['sni']=_0x1d9a53[_0x1d9a53['length']-0x1];}_0x343218=applyCustomSettings(_0x343218,_0x46721e);if(_0x2340c6['fragment']&&_0x2340c6['fragment']['enabled']){_0x343218=applyFragmentSettings(_0x343218,_0x2340c6['fragment']);}_0x384c36['push'](applyTag(_0x343218));});});}else{_0x384c36=_0x44e2b7['map'](_0x47686a=>{let _0x4b35eb=_0x47686a;_0x4b35eb=applyCustomSettings(_0x4b35eb,_0x2340c6);if(_0x2340c6['fragment']&&_0x2340c6['fragment']['enabled']){_0x4b35eb=applyFragmentSettings(_0x4b35eb,_0x2340c6['fragment']);}return applyTag(_0x4b35eb);});}_0x44e2b7=_0x384c36;const _0x2ebe8b=_0x52fa79['searchPara'+'ms']['get']('format')||'v2ray';if(_0x2ebe8b==='clash'){const _0x2db602={};_0x2db602['geoip']=!![];_0x2db602['geoip-code']='IR';_0x2db602['ipcidr']=['0.0.0.0/8','127.0.0.0/'+'8','10.0.0.0/8','172.16.0.0'+'/12','192.168.0.'+'0/16'];const _0xa0fe6a={'port':0x1ed2,'socks-port':0x1ed3,'mixed-port':0x1ed5,'mode':'rule','log-level':'info','dns':{'enable':!![],'listen':':53','enhanced-mode':'fake-ip','fake-ip-range':'198.18.0.1'+'/16','fake-ip-filter':['*.lan','*.local','*.localhos'+'t','*.ir','*.test'],'nameserver':_0x2340c6['dns']&&_0x2340c6['dns']!=='none'?_0x2340c6['dns']['split'](',')['map'](_0x5f38d5=>_0x5f38d5['trim']()):['78.157.42.'+'100','78.157.42.'+'101','10.202.10.'+'10','8.8.8.8','1.1.1.1'],'fallback':_0x2340c6['direct']&&_0x2340c6['direct']!=='none'?_0x2340c6['direct']['split'](',')['map'](_0x26fc54=>_0x26fc54['trim']()):['10.202.10.'+'11','78.157.42.'+'100','8.8.4.4'],'fallback-filter':_0x2db602},'proxies':[],'proxy-groups':[],'rules':['DOMAIN-SUF'+'FIX,google'+'.com,ARIST'+'A\x20Auto','DOMAIN-SUF'+'FIX,youtub'+'e.com,ARIS'+'TA\x20Auto','DOMAIN-SUF'+'FIX,github'+'.com,ARIST'+'A\x20Auto','DOMAIN-KEY'+'WORD,teleg'+'ram,ARISTA'+'\x20Auto','DOMAIN-SUF'+'FIX,instag'+'ram.com,AR'+'ISTA\x20Auto','DOMAIN-SUF'+'FIX,twitte'+'r.com,ARIS'+'TA\x20Auto','DOMAIN-SUF'+'FIX,whatsa'+'pp.com,ARI'+'STA\x20Auto','DOMAIN-SUF'+'FIX,cdn.ir'+',DIRECT','DOMAIN-SUF'+'FIX,aparat'+'.com,DIREC'+'T','DOMAIN-SUF'+'FIX,digika'+'la.com,DIR'+'ECT','DOMAIN-SUF'+'FIX,divar.'+'ir,DIRECT','DOMAIN-SUF'+'FIX,snapp.'+'ir,DIRECT','DOMAIN-SUF'+'FIX,torob.'+'com,DIRECT','DOMAIN-SUF'+'FIX,bamilo'+'.com,DIREC'+'T','DOMAIN-SUF'+'FIX,alibab'+'a.ir,DIREC'+'T','DOMAIN-SUF'+'FIX,ban.ir'+',DIRECT','GEOIP,IR,D'+'IRECT','MATCH,ARIS'+'TA\x20Auto']};const _0x55812a=[];_0x44e2b7['forEach']((_0x386944,_0x51f211)=>{const _0x2105aa=vlessToClashMeta(_0x386944,'ARISTA',_0x51f211+0x1,_0x2340c6);if(_0x2105aa){_0x55812a['push'](_0x2105aa);}});_0xa0fe6a['proxies']=_0x55812a;if(_0xa0fe6a['proxies']['length']>0x0){const _0x13c9c0=[];_0x13c9c0['push']({'name':'ARISTA\x20Sel'+'ect','type':'select','proxies':['ARISTA\x20Aut'+'o','ARISTA\x20Fal'+'lback','ARISTA\x20Loa'+'d\x20Balance',..._0x55812a['map'](_0xf30dd4=>_0xf30dd4['name'])],'disable-udp':![]});_0x13c9c0['push']({'name':'ARISTA\x20Aut'+'o','type':'url-test','proxies':_0x55812a['map'](_0xe3f2d4=>_0xe3f2d4['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x78,'tolerance':0x32,'lazy':!![],'disable-udp':![]});_0x13c9c0['push']({'name':'ARISTA\x20Fal'+'lback','type':'fallback','proxies':_0x55812a['map'](_0xf2aa20=>_0xf2aa20['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x78,'tolerance':0x64,'disable-udp':![]});_0x13c9c0['push']({'name':'ARISTA\x20Loa'+'d\x20Balance','type':'load-balan'+'ce','proxies':_0x55812a['map'](_0x3970ee=>_0x3970ee['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x12c,'strategy':'consistent'+'-hashing','disable-udp':![]});_0xa0fe6a['proxy-grou'+'ps']=_0x13c9c0;}const _0x223411={};_0x223411['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';_0x223411['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x50b658={};_0x50b658['headers']=_0x223411;return new Response(JSON['stringify'](_0xa0fe6a,null,0x2),_0x50b658);}if(_0x2ebe8b==='singbox'){const _0x5c8681=generateSingBoxConfig(_0x44e2b7,_0x2340c6);const _0x5d1be5={};_0x5d1be5['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';_0x5d1be5['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x59b2f3={};_0x59b2f3['headers']=_0x5d1be5;return new Response(JSON['stringify'](_0x5c8681,null,0x2),_0x59b2f3);}const _0x3a629c={};_0x3a629c['content-ty'+'pe']='text/plain'+';charset=u'+'tf-8';_0x3a629c['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x706580={};_0x706580['headers']=_0x3a629c;return new Response(_0x44e2b7['join']('\x0a'),_0x706580);}catch(_0x21481a){console['error']('Error\x20in\x20/'+'api/config'+'s:',_0x21481a);const _0x122a4d={};_0x122a4d['status']=0x1f4;return new Response('Internal\x20S'+'erver\x20Erro'+'r',_0x122a4d);}}const _0x36e448={};_0x36e448['status']=0x194;return new Response('Not\x20Found',_0x36e448);}};function getHTML(){return'<!DOCTYPE\x20'+'html>\x0a<htm'+'l\x20lang=\x22en'+'\x22>\x0a<head>\x0a'+'<meta\x20char'+'set=\x22UTF-8'+'\x22\x20/>\x0a<meta'+'\x20name=\x22vie'+'wport\x22\x20con'+'tent=\x22widt'+'h=device-w'+'idth,\x20init'+'ial-scale='+'1.0\x22\x20/>\x0a<t'+'itle>ARIST'+'A\x20Config\x20G'+'enerator</'+'title>\x0a<st'+'yle>\x0a*\x20{\x20b'+'ox-sizing:'+'\x20border-bo'+'x;\x20margin:'+'\x200;\x20paddin'+'g:\x200;\x20}\x0abo'+'dy\x20{\x20font-'+'family:\x20\x27S'+'egoe\x20UI\x27,\x20'+'Tahoma,\x20Ge'+'neva,\x20Verd'+'ana,\x20sans-'+'serif;\x20bac'+'kground:\x20#'+'0b1c3d;\x20co'+'lor:\x20#fff;'+'\x20line-heig'+'ht:\x201.6;\x20}'+'\x0a.containe'+'r\x20{\x20max-wi'+'dth:\x20800px'+';\x20margin:\x20'+'0\x20auto;\x20pa'+'dding:\x2020p'+'x;\x20}\x0a.head'+'er\x20{\x20backg'+'round:\x20lin'+'ear-gradie'+'nt(135deg,'+'\x20#1a3b7c\x200'+'%,\x20#2c5282'+'\x20100%);\x20co'+'lor:\x20white'+';\x20padding:'+'\x2025px;\x20bor'+'der-radius'+':\x2015px;\x20ma'+'rgin-botto'+'m:\x2025px;\x20t'+'ext-align:'+'\x20center;\x20b'+'ox-shadow:'+'\x200\x204px\x2015p'+'x\x20rgba(0,0'+',0,0.2);\x20}'+'\x0ah1\x20{\x20marg'+'in:\x200;\x20fon'+'t-size:\x2028'+'px;\x20font-w'+'eight:\x20700'+';\x20}\x0a.heade'+'r\x20p\x20{\x20marg'+'in:\x2010px\x200'+'\x200;\x20opacit'+'y:\x200.9;\x20}\x0a'+'.card\x20{\x20ba'+'ckground:\x20'+'#13274f;\x20p'+'adding:\x2025'+'px;\x20border'+'-radius:\x201'+'5px;\x20margi'+'n:\x2015px\x200;'+'\x20box-shado'+'w:\x200\x204px\x201'+'0px\x20rgba(0'+',0,0,0.15)'+';\x20}\x0alabel\x20'+'{\x20display:'+'\x20block;\x20ma'+'rgin-top:\x20'+'15px;\x20font'+'-weight:\x206'+'00;\x20color:'+'\x20#e2e8f0;\x20'+'}\x0a.help-te'+'xt\x20{\x20font-'+'size:\x2013px'+';\x20color:\x20#'+'a0aec0;\x20ma'+'rgin-top:\x20'+'5px;\x20}\x0ainp'+('ut,\x20select'+',\x20textarea'+'\x20{\x20width:\x20'+'100%;\x20padd'+'ing:\x2012px;'+'\x20margin-to'+'p:\x208px;\x20bo'+'rder:\x201px\x20'+'solid\x20#2d3'+'748;\x20borde'+'r-radius:\x20'+'8px;\x20backg'+'round:\x20#0b'+'1c3d;\x20colo'+'r:\x20#fff;\x20f'+'ont-size:\x20'+'14px;\x20tran'+'sition:\x20al'+'l\x200.3s\x20eas'+'e;\x20}\x0ainput'+':focus,\x20se'+'lect:focus'+',\x20textarea'+':focus\x20{\x20o'+'utline:\x20no'+'ne;\x20border'+'-color:\x20#4'+'299e1;\x20box'+'-shadow:\x200'+'\x200\x200\x203px\x20r'+'gba(66,\x2015'+'3,\x20225,\x200.'+'2);\x20}\x0abutt'+'on\x20{\x20margi'+'n-top:\x2020p'+'x;\x20padding'+':\x2014px;\x20wi'+'dth:\x20100%;'+'\x20border:\x20n'+'one;\x20borde'+'r-radius:\x20'+'8px;\x20color'+':\x20#fff;\x20fo'+'nt-weight:'+'\x20600;\x20curs'+'or:\x20pointe'+'r;\x20transit'+'ion:\x20all\x200'+'.3s\x20ease;\x20'+'font-size:'+'\x2016px;\x20}\x0ab'+'utton:hove'+'r\x20{\x20transf'+'orm:\x20trans'+'lateY(-2px'+');\x20box-sha'+'dow:\x200\x204px'+'\x2012px\x20rgba'+'(0,0,0,0.2'+');\x20}\x0a.btn-'+'save\x20{\x20bac'+'kground:\x20l'+'inear-grad'+'ient(135de'+'g,\x20#22c55e'+'\x200%,\x20#16a3'+'4a\x20100%);\x20'+'}\x0a.btn-res'+'et\x20{\x20\x0a\x20\x20ba'+'ckground:\x20'+'linear-gra'+'dient(135d'+'eg,\x20#f9731'+'6\x2050%,\x20#ea'+'580c\x20100%)'+';\x20\x0a}\x0a.btn-'+'copy\x20{\x20bac'+'kground:\x20l'+'inear-grad'+'ient(135de'+'g,\x20#8b5cf6'+'\x200%,\x20#7c3a'+'ed\x20100%);\x20'+'}\x0a.fragmen'+'t-section\x20'+'{\x20backgrou'+'nd:\x20#1e3a8'+'a;\x20padding'+':\x2015px;\x20bo'+'rder-radiu'+'s:\x2010px;\x20m'+'argin-top:'+'\x2015px;\x20}\x0a.'+'fragment-t'+'oggle\x20{\x20di'+'splay:\x20fle'+'x;\x20align-i'+'tems:\x20cent'+'er;\x20margin'+'-bottom:\x201')+('5px;\x20}\x0a.fr'+'agment-tog'+'gle\x20label\x20'+'{\x20margin:\x20'+'0\x200\x200\x2015px'+';\x20font-wei'+'ght:\x20600;\x20'+'}\x0a.switch\x20'+'{\x20position'+':\x20relative'+';\x20display:'+'\x20inline-bl'+'ock;\x20width'+':\x2060px;\x20he'+'ight:\x2030px'+';\x20}\x0a.switc'+'h\x20input\x20{\x20'+'opacity:\x200'+';\x20width:\x200'+';\x20height:\x20'+'0;\x20}\x0a.slid'+'er\x20{\x20posit'+'ion:\x20absol'+'ute;\x20curso'+'r:\x20pointer'+';\x20top:\x200;\x20'+'left:\x200;\x20r'+'ight:\x200;\x20b'+'ottom:\x200;\x20'+'background'+'-color:\x20#4'+'a5568;\x20tra'+'nsition:\x20.'+'4s;\x20border'+'-radius:\x203'+'4px;\x20}\x0a.sl'+'ider:befor'+'e\x20{\x20positi'+'on:\x20absolu'+'te;\x20conten'+'t:\x20\x22\x22;\x20hei'+'ght:\x2022px;'+'\x20width:\x2022'+'px;\x20left:\x20'+'4px;\x20botto'+'m:\x204px;\x20ba'+'ckground-c'+'olor:\x20whit'+'e;\x20transit'+'ion:\x20.4s;\x20'+'border-rad'+'ius:\x2050%;\x20'+'}\x0ainput:ch'+'ecked\x20+\x20.s'+'lider\x20{\x20ba'+'ckground-c'+'olor:\x20#219'+'6F3;\x20}\x0ainp'+'ut:checked'+'\x20+\x20.slider'+':before\x20{\x20'+'transform:'+'\x20translate'+'X(30px);\x20}'+'\x0a.limit-se'+'ction\x20{\x20\x0a\x20'+'\x20\x20\x20backgro'+'und:\x20rgba('+'220,\x2038,\x203'+'8,\x200.1);\x20\x0a'+'\x20\x20\x20\x20paddin'+'g:\x2020px;\x20\x0a'+'\x20\x20\x20\x20border'+'-radius:\x201'+'0px;\x20\x0a\x20\x20\x20\x20'+'margin:\x2020'+'px\x200;\x20\x0a\x20\x20\x20'+'\x20border:\x202'+'px\x20solid\x20#'+'ef4444;\x20\x0a\x20'+'\x20\x20\x20animati'+'on:\x20blink-'+'border\x202s\x20'+'infinite;\x0a'+'\x20\x20\x20\x20positi'+'on:\x20relati'+'ve;\x0a}\x0a@key'+'frames\x20bli'+'nk-border\x20'+'{\x0a\x20\x20\x20\x200%,\x20'+'100%\x20{\x20bor'+'der-color:'+'\x20#ef4444;\x20'+'}\x0a\x20\x20\x20\x2050%\x20'+'{\x20border-c'+'olor:\x20#fca'+'5a5;\x20}\x0a}\x0a.'+'limit-sect'+'ion\x20{\x20\x0a\x20\x20\x20'+'\x20backgroun')+('d:\x20rgba(22'+'0,\x2038,\x2038,'+'\x200.1);\x20\x0a\x20\x20'+'\x20\x20padding:'+'\x2020px;\x20\x0a\x20\x20'+'\x20\x20border-r'+'adius:\x2012p'+'x;\x20\x0a\x20\x20\x20\x20ma'+'rgin:\x2020px'+'\x20auto;\x0a\x20\x20\x20'+'\x20border:\x202'+'px\x20solid\x20#'+'ef4444;\x20\x0a\x20'+'\x20\x20\x20animati'+'on:\x20blink-'+'border\x202s\x20'+'infinite;\x0a'+'\x20\x20\x20\x20positi'+'on:\x20relati'+'ve;\x0a\x20\x20\x20\x20ma'+'x-width:\x204'+'00px;\x0a\x20\x20\x20\x20'+'text-align'+':\x20center;\x0a'+'\x20\x20\x20\x20width:'+'\x20100%;\x0a}\x0a@'+'keyframes\x20'+'blink-bord'+'er\x20{\x0a\x20\x20\x20\x200'+'%,\x20100%\x20{\x20'+'border-col'+'or:\x20#ef444'+'4;\x20box-sha'+'dow:\x200\x200\x201'+'0px\x20rgba(2'+'39,\x2068,\x2068'+',\x200.3);\x20}\x0a'+'\x20\x20\x20\x2050%\x20{\x20'+'border-col'+'or:\x20#fca5a'+'5;\x20box-sha'+'dow:\x200\x200\x201'+'5px\x20rgba(2'+'39,\x2068,\x2068'+',\x200.5);\x20}\x0a'+'}\x0a.limit-s'+'ection::be'+'fore\x20{\x0a\x20\x20\x20'+'\x20content:\x20'+'\x22⚠️\x20IMPORTA'+'NT\x20SETTING'+'\x22;\x0a\x20\x20\x20\x20pos'+'ition:\x20abs'+'olute;\x0a\x20\x20\x20'+'\x20top:\x20-12p'+'x;\x0a\x20\x20\x20\x20lef'+'t:\x2050%;\x0a\x20\x20'+'\x20\x20transfor'+'m:\x20transla'+'teX(-50%);'+'\x0a\x20\x20\x20\x20backg'+'round:\x20lin'+'ear-gradie'+'nt(135deg,'+'\x20#ef4444\x200'+'%,\x20#dc2626'+'\x20100%);\x0a\x20\x20'+'\x20\x20color:\x20w'+'hite;\x0a\x20\x20\x20\x20'+'padding:\x206'+'px\x2016px;\x0a\x20'+'\x20\x20\x20border-'+'radius:\x208p'+'x;\x0a\x20\x20\x20\x20fon'+'t-size:\x2012'+'px;\x0a\x20\x20\x20\x20fo'+'nt-weight:'+'\x20700;\x0a\x20\x20\x20\x20'+'animation:'+'\x20blink-tex'+'t\x202s\x20infin'+'ite;\x0a\x20\x20\x20\x20w'+'hite-space'+':\x20nowrap;\x0a'+'\x20\x20\x20\x20box-sh'+'adow:\x200\x202p'+'x\x208px\x20rgba'+'(239,\x2068,\x20'+'68,\x200.3);\x0a'+'}\x0a@keyfram'+'es\x20blink-t'+'ext\x20{\x0a\x20\x20\x20\x20'+'0%,\x20100%\x20{'+'\x20opacity:\x20'+'1;\x20transfo'+'rm:\x20transl'+'ateX(-50%)'+'\x20scale(1);'+'\x20}\x0a\x20\x20\x20\x2050%'+'\x20{\x20opacity')+(':\x200.8;\x20tra'+'nsform:\x20tr'+'anslateX(-'+'50%)\x20scale'+'(1.02);\x20}\x0a'+'}\x0a\x0a.limit-'+'section\x20.g'+'rid\x20{\x0a\x20\x20\x20\x20'+'display:\x20f'+'lex;\x0a\x20\x20\x20\x20j'+'ustify-con'+'tent:\x20cent'+'er;\x0a\x20\x20\x20\x20ga'+'p:\x2015px;\x0a}'+'\x0a\x0a.limit-s'+'ection\x20.gr'+'id\x20>\x20div\x20{'+'\x0a\x20\x20\x20\x20flex:'+'\x201;\x0a\x20\x20\x20\x20ma'+'x-width:\x203'+'00px;\x0a}\x0a\x0a.'+'limit-sect'+'ion\x20select'+'\x20{\x0a\x20\x20\x20\x20bac'+'kground:\x20r'+'gba(11,\x2028'+',\x2061,\x200.8)'+';\x0a\x20\x20\x20\x20bord'+'er:\x201px\x20so'+'lid\x20#ef444'+'4;\x0a\x20\x20\x20\x20col'+'or:\x20white;'+'\x0a\x20\x20\x20\x20text-'+'align:\x20cen'+'ter;\x0a\x20\x20\x20\x20f'+'ont-weight'+':\x20600;\x0a}\x0a\x0a'+'.limit-sec'+'tion\x20.help'+'-text\x20{\x0a\x20\x20'+'\x20\x20color:\x20#'+'fecaca;\x0a\x20\x20'+'\x20\x20font-siz'+'e:\x2012px;\x0a\x20'+'\x20\x20\x20margin-'+'top:\x208px;\x0a'+'}\x0atextarea'+'\x20{\x20height:'+'\x20120px;\x20re'+'size:\x20vert'+'ical;\x20}\x0afo'+'oter\x20{\x20tex'+'t-align:\x20c'+'enter;\x20mar'+'gin-top:\x203'+'0px;\x20opaci'+'ty:\x200.7;\x20f'+'ont-size:\x20'+'14px;\x20}\x0a.a'+'lert\x20{\x20pos'+'ition:\x20fix'+'ed;\x20top:\x202'+'0px;\x20right'+':\x2020px;\x20pa'+'dding:\x2015p'+'x\x2025px;\x20ba'+'ckground:\x20'+'#22c55e;\x20c'+'olor:\x20whit'+'e;\x20border-'+'radius:\x208p'+'x;\x20box-sha'+'dow:\x200\x204px'+'\x2015px\x20rgba'+'(0,0,0,0.2'+');\x20z-index'+':\x201000;\x20op'+'acity:\x200;\x20'+'transform:'+'\x20translate'+'Y(-20px);\x20'+'transition'+':\x20all\x200.3s'+'\x20ease;\x20}\x0a.'+'alert.show'+'\x20{\x20opacity'+':\x201;\x20trans'+'form:\x20tran'+'slateY(0);'+'\x20}\x0a.alert.'+'error\x20{\x20ba'+'ckground:\x20'+'#ef4444;\x20}'+'\x0a.grid\x20{\x20d'+'isplay:\x20gr'+'id;\x20grid-t'+'emplate-co'+'lumns:\x201fr'+'\x201fr;\x20gap:'+'\x2015px;\x20}\x0a@')+('media\x20(max'+'-width:\x2076'+'8px)\x20{\x0a\x20\x20\x20'+'\x20.grid\x20{\x20g'+'rid-templa'+'te-columns'+':\x201fr;\x20}\x0a\x20'+'\x20\x20\x20.contai'+'ner\x20{\x20padd'+'ing:\x2015px;'+'\x20}\x0a\x20\x20\x20\x20.he'+'ader\x20{\x20pad'+'ding:\x2020px'+';\x20}\x0a\x20\x20\x20\x20.c'+'ard\x20{\x20padd'+'ing:\x2020px;'+'\x20}\x0a\x20\x20\x20\x20.li'+'mit-sectio'+'n\x20{\x20paddin'+'g:\x2015px;\x20}'+'\x0a}\x0a</style'+'>\x0a</head>\x0a'+'<body>\x0a<di'+'v\x20class=\x22c'+'ontainer\x22>'+'\x0a<div\x20clas'+'s=\x22header\x22'+'>\x0a<h1>ARIS'+'TA\x20Config\x20'+'Generator<'+'/h1>\x0a<p>Ge'+'nerate\x20and'+'\x20customize'+'\x20VLESS\x20con'+'figuration'+'s</p>\x0a</di'+'v>\x0a<div\x20st'+'yle=\x22\x0a\x20\x20\x20\x20'+'background'+':\x20linear-g'+'radient(13'+'5deg,\x20rgba'+'(138,\x2043,\x20'+'226,\x200.1),'+'\x20rgba(218,'+'\x20112,\x20214,'+'\x200.1));\x0a\x20\x20'+'\x20\x20backdrop'+'-filter:\x20b'+'lur(10px);'+'\x0a\x20\x20\x20\x20paddi'+'ng:\x2015px\x202'+'0px;\x0a\x20\x20\x20\x20b'+'order-radi'+'us:\x2012px;\x0a'+'\x20\x20\x20\x20margin'+':\x2020px\x20aut'+'o;\x0a\x20\x20\x20\x20tex'+'t-align:\x20c'+'enter;\x0a\x20\x20\x20'+'\x20box-shado'+'w:\x200\x204px\x202'+'0px\x20rgba(1'+'38,\x2043,\x2022'+'6,\x200.2);\x0a\x20'+'\x20\x20\x20border:'+'\x201px\x20solid'+'\x20white;\x0a\x20\x20'+'\x20\x20max-widt'+'h:\x2090%;\x0a\x22>'+'\x0a\x20\x20\x20\x20<div\x20'+'style=\x22\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20disp'+'lay:\x20flex;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20j'+'ustify-con'+'tent:\x20cent'+'er;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20gap:\x2025p'+'x;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20flex-wrap'+':\x20wrap;\x0a\x20\x20'+'\x20\x20\x22>\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20<a\x20href'+'=\x22https://'+'t.me/arist'+'aproject\x22\x20'+'target=\x22_b'+'lank\x22\x20styl'+'e=\x22\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20disp'+'lay:\x20flex;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20align-i'+'tems:\x20cent'+'er;\x20\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20gap'+':\x208px;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20p'+'adding:\x2010')+('px\x2020px;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20backgroun'+'d:\x20linear-'+'gradient(1'+'35deg,\x20rgb'+'a(0,\x20136,\x20'+'204,\x200.2),'+'\x20rgba(0,\x201'+'19,\x20181,\x200'+'.3));\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20co'+'lor:\x20white'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20text-d'+'ecoration:'+'\x20none;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20b'+'order-radi'+'us:\x208px;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20transitio'+'n:\x20all\x200.3'+'s\x20ease;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'border:\x201p'+'x\x20solid\x20rg'+'ba(0,\x20136,'+'\x20204,\x200.3)'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20font-w'+'eight:\x20600'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x22\x20onmouseo'+'ver=\x22this.'+'style.tran'+'sform=\x27tra'+'nslateY(-2'+'px)\x27;this.'+'style.boxS'+'hadow=\x270\x206'+'px\x2015px\x20rg'+'ba(0,136,2'+'04,0.3)\x27;\x22'+'\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20onmouse'+'out=\x22this.'+'style.tran'+'sform=\x27tra'+'nslateY(0)'+'\x27;this.sty'+'le.boxShad'+'ow=\x27none\x27;'+'\x22>\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20<svg\x20'+'xmlns=\x22htt'+'p://www.w3'+'.org/2000/'+'svg\x22\x20width'+'=\x2218\x22\x20heig'+'ht=\x2218\x22\x20fi'+'ll=\x22curren'+'tColor\x22\x20vi'+'ewBox=\x220\x200'+'\x2016\x2016\x22>\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20<path'+'\x20d=\x22M16\x208A'+'8\x208\x200\x201\x201\x20'+'0\x208a8\x208\x200\x20'+'0\x201\x2016\x200zM'+'8.287\x205.90'+'6c-.778.32'+'4-2.334.99'+'4-4.666\x202.'+'01-.378.15'+'-.577.298-'+'.595.442-.'+'03.243.275'+'.339.69.47'+'l.175.055c'+'.408.133.9'+'58.288\x201.2'+'43.294.26.'+'006.549-.1'+'.868-.32\x202'+'.179-1.471'+'\x203.304-2.2'+'14\x203.374-2'+'.23.05-.01'+'2.12-.026.'+'166.016.04'+'7.041.042.'+'12.037.141'+'-.03.129-1'+'.227\x201.241'+'-1.846\x201.8'+'17-.193.18'+'-.33.307-.'+'358.336a8.')+('154\x208.154\x20'+'0\x200\x201-.188'+'.186c-.38.'+'366-.664.6'+'4.015\x201.08'+'8.327.216.'+'589.393.85'+'.571.284.1'+'94.568.387'+'.936.629.0'+'93.06.183.'+'125.27.187'+'.331.236.6'+'3.448.997.'+'414.214-.0'+'2.435-.22.'+'547-.82.26'+'5-1.417.78'+'6-4.486.90'+'6-5.751a1.'+'426\x201.426\x20'+'0\x200\x200-.013'+'-.315.337.'+'337\x200\x200\x200-'+'.114-.217.'+'526.526\x200\x20'+'0\x200-.31-.0'+'93c-.3.005'+'-.763.166-'+'2.984\x201.09'+'z\x22/>\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20</s'+'vg>\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20Aris'+'ta\x20Telegra'+'m\x20Channel\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20</'+'a>\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'<a\x20href=\x22h'+'ttps://ari'+'sta-proxy.'+'pages.dev\x22'+'\x20target=\x22_'+'blank\x22\x20sty'+'le=\x22\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20dis'+'play:\x20flex'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20align-'+'items:\x20cen'+'ter;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20gap'+':\x208px;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20p'+'adding:\x2010'+'px\x2020px;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20backgroun'+'d:\x20linear-'+'gradient(1'+'35deg,\x20rgb'+'a(74,\x20144,'+'\x20226,\x200.2)'+',\x20rgba(66,'+'\x20133,\x20214,'+'\x200.3));\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'color:\x20whi'+'te;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20text'+'-decoratio'+'n:\x20none;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20border-ra'+'dius:\x208px;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20transit'+'ion:\x20all\x200'+'.3s\x20ease;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20border:\x20'+'1px\x20solid\x20'+'rgba(74,\x201'+'44,\x20226,\x200'+'.3);\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20fon'+'t-weight:\x20'+'600;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x22\x20onmou'+'seover=\x22th'+'is.style.t'+'ransform=\x27'+'translateY'+'(-2px)\x27;th'+'is.style.b'+'oxShadow=\x27'+'0\x206px\x2015px'+'\x20rgba(74,1'+'44,226,0.3')+(')\x27;\x22\x20\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20onm'+'ouseout=\x22t'+'his.style.'+'transform='+'\x27translate'+'Y(0)\x27;this'+'.style.box'+'Shadow=\x27no'+'ne\x27;\x22>\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20<'+'svg\x20xmlns='+'\x22http://ww'+'w.w3.org/2'+'000/svg\x22\x20w'+'idth=\x2218\x22\x20'+'height=\x2218'+'\x22\x20fill=\x22cu'+'rrentColor'+'\x22\x20viewBox='+'\x220\x200\x2016\x2016'+'\x22>\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20<'+'path\x20d=\x22M0'+'\x208a8\x208\x200\x201'+'\x201\x2016\x200A8\x20'+'8\x200\x200\x201\x200\x20'+'8zm7.5-6.9'+'23c-.67.20'+'4-1.335.82'+'-1.887\x201.8'+'55A7.97\x207.'+'97\x200\x200\x200\x205'+'.145\x204H7.5'+'V1.077zM4.'+'09\x204a9.267'+'\x209.267\x200\x200'+'\x201\x20.64-1.5'+'39\x206.7\x206.7'+'\x200\x200\x201\x20.59'+'7-.933A7.0'+'25\x207.025\x200'+'\x200\x200\x202.255'+'\x204H4.09zm-'+'.582\x203.5c.'+'03-.877.13'+'8-1.718.31'+'2-2.5H1.67'+'4a6.958\x206.'+'958\x200\x200\x200-'+'.656\x202.5h2'+'.49zM4.847'+'\x205a12.5\x2012'+'.5\x200\x200\x200-.'+'338\x202.5H7.'+'5V5H4.847z'+'M8.5\x205v2.5'+'h2.99a12.4'+'95\x2012.495\x20'+'0\x200\x200-.337'+'-2.5H8.5zM'+'4.51\x208.5a1'+'2.5\x2012.5\x200'+'\x200\x200\x20.337\x20'+'2.5H7.5V8.'+'5H4.51zm3.'+'99\x200V11h2.'+'653c.187-.'+'765.306-1.'+'608.338-2.'+'5H8.5zM5.1'+'45\x2012c.138'+'.386.295.7'+'44.468\x201.0'+'68.552\x201.0'+'35\x201.218\x201'+'.65\x201.887\x20'+'1.855V12H5'+'.145zm.182'+'\x202.472a6.6'+'96\x206.696\x200'+'\x200\x201-.597-'+'.933A9.268'+'\x209.268\x200\x200'+'\x201\x204.09\x2012'+'H2.255a7.0'+'24\x207.024\x200'+'\x200\x200\x203.072'+'\x202.472zM3.'+'82\x2011a13.6'+'52\x2013.652\x20'+'0\x200\x201-.312'+'-2.5h-2.49'+'c.062.97.2'+'91\x201.87.65'+'6\x202.5H3.82'+'zm6.853\x203.'+'472A7.024\x20'+'7.024\x200\x200\x20'+'0\x2013.745\x201')+('2H11.91a9.'+'27\x209.27\x200\x20'+'0\x201-.64\x201.'+'539\x206.688\x20'+'6.688\x200\x200\x20'+'1-.597.933'+'zM8.5\x2012v2'+'.923c.67-.'+'204\x201.335-'+'.82\x201.887-'+'1.855.173-'+'.324.33-.6'+'82.468-1.0'+'68H8.5zm3.'+'680-1h2.14'+'6c.365-.63'+'.594-1.53.'+'656-2.5h-2'+'.49a13.65\x20'+'13.65\x200\x200\x20'+'1-.312\x202.5'+'zm2.802-3.'+'5a6.959\x206.'+'959\x200\x200\x200-'+'.656-2.5H1'+'2.18c.174.'+'782.282\x201.'+'623.312\x202.'+'5h2.49zM11'+'.27\x202.461c'+'.247.35.46'+'2.739.64\x201'+'.539h1.835'+'a7.024\x207.0'+'24\x200\x200\x200-3'+'.072-2.472'+'c.218.284.'+'418.598.59'+'7.933zM10.'+'855\x204a7.96'+'6\x207.966\x200\x20'+'0\x200-.468-1'+'.068C9.835'+'\x201.897\x209.1'+'7\x201.282\x208.'+'5\x201.077V4h'+'2.355z\x22/>\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20</svg>\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20Telegram\x20'+'Proxy\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20</a>\x0a\x20'+'\x20\x20\x20</div>\x0a'+'</div>\x0a<di'+'v\x20class=\x22c'+'ard\x22>\x0a\x0a<di'+'v\x20class=\x22g'+'rid\x22>\x0a<div'+'>\x0a<label>R'+'emote\x20DNS<'+'/label>\x0a<i'+'nput\x20id=\x22d'+'ns\x22\x20placeh'+'older=\x22e.g'+'.,\x208.8.8.8'+',1.1.1.1,h'+'ttps://dns'+'.google/dn'+'s-query\x22>\x0a'+'<div\x20class'+'=\x22help-tex'+'t\x22>Enter\x20D'+'NS\x20servers'+'\x20or\x20DoH\x20UR'+'Ls\x20(comma-'+'separated,'+'\x20e.g.,\x208.8'+'.8.8,1.1.1'+'.1\x20or\x20http'+'s://dns.go'+'ogle/dns-q'+'uery)</div'+'>\x0a</div>\x0a<'+'div>\x0a<labe'+'l>Direct\x20D'+'NS</label>'+'\x0a<input\x20id'+'=\x22direct\x22\x20'+'placeholde'+'r=\x22e.g.,\x201'+'27.0.0.1,8'+'.8.8.8\x22>\x0a<'+'div\x20class='+'\x22help-text'+'\x22>Enter\x20DN'+'S\x20servers\x20'+'for\x20direct'+'\x20connectio'+'ns\x20(comma-')+('separated,'+'\x20e.g.,\x20127'+'.0.0.1,8.8'+'.8.8)</div'+'>\x0a</div>\x0a<'+'/div>\x0a\x0a<di'+'v\x20class=\x22g'+'rid\x22>\x0a<div'+'>\x0a<label>C'+'lean\x20IP</l'+'abel>\x0a<inp'+'ut\x20id=\x22cle'+'anip\x22\x20plac'+'eholder=\x22e'+'.g.,\x208.219'+'.190.62,1.'+'1.1.1\x22>\x0a<d'+'iv\x20class=\x22'+'help-text\x22'+'>Enter\x20cle'+'an\x20IP\x20addr'+'esses\x20for\x20'+'bypass\x20(co'+'mma-separa'+'ted,\x20e.g.,'+'\x208.219.190'+'.62,1.1.1.'+'1)</div>\x0a<'+'/div>\x0a<div'+'>\x0a<label>D'+'omain</lab'+'el>\x0a<input'+'\x20id=\x22domai'+'n\x22\x20placeho'+'lder=\x22e.g.'+',\x20zula.ir,'+'example.co'+'m\x22>\x0a<div\x20c'+'lass=\x22help'+'-text\x22>Ent'+'er\x20domains'+'\x20for\x20routi'+'ng\x20(comma-'+'separated,'+'\x20e.g.,\x20zul'+'a.ir,examp'+'le.com)</d'+'iv>\x0a</div>'+'\x0a</div>\x0a\x0a<'+'div\x20class='+'\x22grid\x22>\x0a<d'+'iv>\x0a<label'+'>SNI</labe'+'l>\x0a<input\x20'+'id=\x22sni\x22\x20p'+'laceholder'+'=\x22e.g.,\x20ex'+'ample.com,'+'cloudflare'+'.com\x22>\x0a<di'+'v\x20class=\x22h'+'elp-text\x22>'+'Enter\x20Serv'+'er\x20Name\x20In'+'dication\x20f'+'or\x20TLS\x20(co'+'mma-separa'+'ted,\x20e.g.,'+'\x20example.c'+'om,cloudfl'+'are.com)</'+'div>\x0a</div'+'>\x0a<div>\x0a<l'+'abel>ALPN<'+'/label>\x0a<s'+'elect\x20id=\x22'+'alpn\x22>\x0a<op'+'tion\x20value'+'=\x22none\x22>No'+'ne</option'+'>\x0a<option\x20'+'value=\x22h2\x22'+'>HTTP/2</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22http/1.1'+'\x22>HTTP/1.1'+'</option>\x0a'+'<option\x20va'+'lue=\x22h2,ht'+'tp/1.1\x22>HT'+'TP/2\x20+\x20HTT'+'P/1.1</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'h3\x22>HTTP/3'+'</option>\x0a'+'</select>\x0a'+'<div\x20class'+'=\x22help-tex')+('t\x22>Applica'+'tion-Layer'+'\x20Protocol\x20'+'Negotiatio'+'n</div>\x0a</'+'div>\x0a</div'+'>\x0a\x0a<div\x20cl'+'ass=\x22grid\x22'+'>\x0a<div>\x0a<l'+'abel>Finge'+'rprint</la'+'bel>\x0a<sele'+'ct\x20id=\x22fin'+'gerprint\x22>'+'\x0a<option\x20v'+'alue=\x22none'+'\x22>None</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22chrome\x22>C'+'hrome</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'firefox\x22>F'+'irefox</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22safari\x22>S'+'afari</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'ios\x22>iOS</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22android'+'\x22>Android<'+'/option>\x0a<'+'option\x20val'+'ue=\x22edge\x22>'+'Edge</opti'+'on>\x0a<optio'+'n\x20value=\x223'+'60\x22>360</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22qq\x22>QQ</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22random\x22'+'>Random</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22randomiz'+'ed\x22>Random'+'ized</opti'+'on>\x0a</sele'+'ct>\x0a<div\x20c'+'lass=\x22help'+'-text\x22>TLS'+'\x20client\x20fi'+'ngerprint<'+'/div>\x0a</di'+'v>\x0a<div>\x0a<'+'label>IP\x20V'+'ersion</la'+'bel>\x0a<sele'+'ct\x20id=\x22ipv'+'er\x22>\x0a<opti'+'on\x20value=\x22'+'none\x22>None'+'</option>\x0a'+'<option\x20va'+'lue=\x22ipv4\x22'+'>IPv4</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'ipv6\x22>IPv6'+'</option>\x0a'+'<option\x20va'+'lue=\x22auto\x22'+'>Auto</opt'+'ion>\x0a</sel'+'ect>\x0a</div'+'>\x0a</div>\x0a\x0a'+'<div\x20class'+'=\x22grid\x22>\x0a<'+'div>\x0a<labe'+'l>Network<'+'/label>\x0a<s'+'elect\x20id=\x22'+'network\x22>\x0a'+'<option\x20va'+'lue=\x22none\x22'+'>None</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'tcp\x22>TCP</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22ws\x22>Web')+('Socket</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22h2\x22>HTTP/'+'2</option>'+'\x0a<option\x20v'+'alue=\x22grpc'+'\x22>gRPC</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22quic\x22>QUI'+'C</option>'+'\x0a<option\x20v'+'alue=\x22kcp\x22'+'>KCP</opti'+'on>\x0a<optio'+'n\x20value=\x22h'+'ttp\x22>HTTP<'+'/option>\x0a<'+'/select>\x0a<'+'/div>\x0a<div'+'>\x0a<label>T'+'LS</label>'+'\x0a<select\x20i'+'d=\x22tls\x22>\x0a<'+'option\x20val'+'ue=\x22none\x22>'+'None</opti'+'on>\x0a<optio'+'n\x20value=\x22e'+'nabled\x22>En'+'abled</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'disabled\x22>'+'Disabled</'+'option>\x0a</'+'select>\x0a</'+'div>\x0a</div'+'>\x0a\x0a<div\x20cl'+'ass=\x22grid\x22'+'>\x0a<div>\x0a<l'+'abel>UDP</'+'label>\x0a<se'+'lect\x20id=\x22u'+'dp\x22>\x0a<opti'+'on\x20value=\x22'+'none\x22>None'+'</option>\x0a'+'<option\x20va'+'lue=\x22enabl'+'ed\x22>Enable'+'d</option>'+'\x0a<option\x20v'+'alue=\x22disa'+'bled\x22>Disa'+'bled</opti'+'on>\x0a</sele'+'ct>\x0a</div>'+'\x0a</div>\x0a\x0a<'+'div\x20class='+'\x22fragment-'+'section\x22>\x0a'+'<div\x20class'+'=\x22fragment'+'-toggle\x22>\x0a'+'<label\x20cla'+'ss=\x22switch'+'\x22>\x0a<input\x20'+'type=\x22chec'+'kbox\x22\x20id=\x22'+'fragment_e'+'nabled\x22>\x0a<'+'span\x20class'+'=\x22slider\x22>'+'</span>\x0a</'+'label>\x0a<la'+'bel>Enable'+'\x20Fragment<'+'/label>\x0a</'+'div>\x0a\x0a<div'+'\x20id=\x22fragm'+'ent_settin'+'gs\x22>\x0a<div\x20'+'class=\x22gri'+'d\x22>\x0a<div>\x0a'+'<label>Pac'+'kets</labe'+'l>\x0a<input\x20'+'id=\x22frag_p'+'ackets\x22\x20va'+'lue=\x222-8\x22>'+'\x0a<div\x20clas'+'s=\x22help-te'+'xt\x22>Packet'+'\x20fragmenta'+'tion\x20range'+'</div>\x0a</d'+'iv>\x0a<div>\x0a'+'<label>Len')+('gth</label'+'>\x0a<input\x20i'+'d=\x22frag_le'+'ngth\x22\x20valu'+'e=\x22100-300'+'\x22>\x0a<div\x20cl'+'ass=\x22help-'+'text\x22>Frag'+'ment\x20lengt'+'h\x20range</d'+'iv>\x0a</div>'+'\x0a</div>\x0a\x0a<'+'div\x20class='+'\x22grid\x22>\x0a<d'+'iv>\x0a<label'+'>Interval<'+'/label>\x0a<i'+'nput\x20id=\x22f'+'rag_interv'+'al\x22\x20value='+'\x2210-30\x22>\x0a<'+'div\x20class='+'\x22help-text'+'\x22>Fragment'+'\x20interval\x20'+'range</div'+'>\x0a</div>\x0a<'+'div>\x0a<labe'+'l>Sleep</l'+'abel>\x0a<inp'+'ut\x20id=\x22fra'+'g_sleep\x22\x20v'+'alue=\x2250\x22>'+'\x0a<div\x20clas'+'s=\x22help-te'+'xt\x22>Sleep\x20'+'time\x20betwe'+'en\x20fragmen'+'ts\x20(ms)</d'+'iv>\x0a</div>'+'\x0a</div>\x0a</'+'div>\x0a</div'+'>\x0a\x0a<div\x20cl'+'ass=\x22limit'+'-section\x22>'+'\x0a<div\x20clas'+'s=\x22grid\x22>\x0a'+'<div>\x0a<lab'+'el>Config\x20'+'Limit</lab'+'el>\x0a<selec'+'t\x20id=\x22limi'+'t\x22>\x0a<optio'+'n\x20value=\x22a'+'ll\x22>All\x20Co'+'nfigs</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'5\x22>5\x20Confi'+'gs</option'+'>\x0a<option\x20'+'value=\x2210\x22'+'>10\x20Config'+'s</option>'+'\x0a<option\x20v'+'alue=\x2220\x22>'+'20\x20Configs'+'</option>\x0a'+'<option\x20va'+'lue=\x2230\x22>3'+'0\x20Configs<'+'/option>\x0a<'+'option\x20val'+'ue=\x2240\x22>40'+'\x20Configs</'+'option>\x0a<o'+'ption\x20valu'+'e=\x2250\x22>50\x20'+'Configs</o'+'ption>\x0a<op'+'tion\x20value'+'=\x2260\x22>60\x20C'+'onfigs</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22100\x22>100\x20'+'Configs</o'+'ption>\x0a</s'+'elect>\x0a<di'+'v\x20class=\x22h'+'elp-text\x22>'+'Select\x20num'+'ber\x20of\x20con'+'figuration'+'s\x20to\x20gener'+'ate\x20(prior'+'ity\x20given\x20'+'to\x20ports\x202'+'096,\x20443,\x20'+'8443,\x208080')+(')</div>\x0a</'+'div>\x0a</div'+'>\x0a</div>\x0a\x0a'+'<button\x20cl'+'ass=\x22btn-s'+'ave\x22\x20oncli'+'ck=\x22saveSe'+'ttings()\x22>'+'Save\x20Setti'+'ngs</butto'+'n>\x0a<button'+'\x20class=\x22bt'+'n-reset\x22\x20o'+'nclick=\x22re'+'setSetting'+'s()\x22>Reset'+'\x20Settings<'+'/button>\x0a\x0a'+'<label>Sub'+'scribe\x20URL'+'\x20(V2Ray)</'+'label>\x0a<in'+'put\x20id=\x22su'+'bscribe_v2'+'ray\x22\x20reado'+'nly>\x0a<butt'+'on\x20class=\x22'+'btn-copy\x22\x20'+'onclick=\x22c'+'opyToClipb'+'oard(\x27subs'+'cribe_v2ra'+'y\x27)\x22>Copy\x20'+'V2Ray\x20Subs'+'cribe</but'+'ton>\x0a\x0a<lab'+'el>Subscri'+'be\x20URL\x20(Cl'+'ashMeta)</'+'label>\x0a<in'+'put\x20id=\x22su'+'bscribe_cl'+'ash\x22\x20reado'+'nly>\x0a<butt'+'on\x20class=\x22'+'btn-copy\x22\x20'+'onclick=\x22c'+'opyToClipb'+'oard(\x27subs'+'cribe_clas'+'h\x27)\x22>Copy\x20'+'ClashMeta\x20'+'Subscribe<'+'/button>\x0a\x0a'+'<label>Sub'+'scribe\x20URL'+'\x20(SingBox)'+'</label>\x0a<'+'input\x20id=\x22'+'subscribe_'+'singbox\x22\x20r'+'eadonly>\x0a<'+'button\x20cla'+'ss=\x22btn-co'+'py\x22\x20onclic'+'k=\x22copyToC'+'lipboard(\x27'+'subscribe_'+'singbox\x27)\x22'+'>Copy\x20Sing'+'Box\x20Subscr'+'ibe</butto'+'n>\x0a</div>\x0a'+'<footer>V\x20'+'1.3.7</foo'+'ter>\x0a<div\x20'+'id=\x22alert\x22'+'\x20class=\x22al'+'ert\x22></div'+'>\x0a</div>\x0a<'+'script>\x0afu'+'nction\x20sho'+'wAlert(mes'+'sage,\x20isEr'+'ror\x20=\x20fals'+'e)\x20{\x0a\x20\x20\x20\x20c'+'onst\x20alert'+'\x20=\x20documen'+'t.getEleme'+'ntById(\x27al'+'ert\x27);\x0a\x20\x20\x20'+'\x20alert.tex'+'tContent\x20='+'\x20message;\x0a'+'\x20\x20\x20\x20alert.'+'className\x20'+'=\x20isError\x20'+'?\x20\x27alert\x20e'+'rror\x27\x20:\x20\x27a'+'lert\x27;\x0a\x20\x20\x20')+('\x20alert.cla'+'ssList.add'+'(\x27show\x27);\x0a'+'\x20\x20\x20\x20\x0a\x20\x20\x20\x20s'+'etTimeout('+'()\x20=>\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20aler'+'t.classLis'+'t.remove(\x27'+'show\x27);\x0a\x20\x20'+'\x20\x20},\x203000)'+';\x0a}\x0a\x0afunct'+'ion\x20toggle'+'FragmentSe'+'ttings()\x20{'+'\x0a\x20\x20\x20\x20const'+'\x20enabled\x20='+'\x20document.'+'getElement'+'ById(\x27frag'+'ment_enabl'+'ed\x27).check'+'ed;\x0a\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27fragmen'+'t_settings'+'\x27).style.d'+'isplay\x20=\x20e'+'nabled\x20?\x20\x27'+'grid\x27\x20:\x20\x27n'+'one\x27;\x0a}\x0a\x0a\x20'+'\x20async\x20fun'+'ction\x20save'+'Settings()'+'{\x0a\x20\x20\x20\x20try\x20'+'{\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'const\x20data'+'\x20=\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20lim'+'it:\x20docume'+'nt.getElem'+'entById(\x27l'+'imit\x27).val'+'ue,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20dns:'+'\x20document.'+'getElement'+'ById(\x27dns\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20direct:\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27direct'+'\x27).value,\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20cleanip:'+'\x20document.'+'getElement'+'ById(\x27clea'+'nip\x27).valu'+'e,\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20domai'+'n:\x20documen'+'t.getEleme'+'ntById(\x27do'+'main\x27).val'+'ue,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20sni:'+'\x20document.'+'getElement'+'ById(\x27sni\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20alpn:\x20doc'+'ument.getE'+'lementById'+'(\x27alpn\x27).v'+'alue,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20fi'+'ngerprint:'+'\x20document.'+'getElement'+'ById(\x27fing'+'erprint\x27).'+'value,\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20i'+'pver:\x20docu'+'ment.getEl'+'ementById('+'\x27ipver\x27).v'+'alue,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20ne'+'twork:\x20doc'+'ument.getE'+'lementById'+'(\x27network\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20')+('\x20tls:\x20docu'+'ment.getEl'+'ementById('+'\x27tls\x27).val'+'ue,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20udp:'+'\x20document.'+'getElement'+'ById(\x27udp\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20fragment:'+'\x20{\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20e'+'nabled:\x20do'+'cument.get'+'ElementByI'+'d(\x27fragmen'+'t_enabled\x27'+').checked,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20pac'+'kets:\x20docu'+'ment.getEl'+'ementById('+'\x27frag_pack'+'ets\x27).valu'+'e,\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20l'+'ength:\x20doc'+'ument.getE'+'lementById'+'(\x27frag_len'+'gth\x27).valu'+'e,\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20i'+'nterval:\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_i'+'nterval\x27).'+'value,\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20sleep:\x20'+'document.g'+'etElementB'+'yId(\x27frag_'+'sleep\x27).va'+'lue,\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20}\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20};\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20con'+'st\x20respons'+'e\x20=\x20await\x20'+'fetch(\x27/ap'+'i/settings'+'\x27,\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20met'+'hod:\x20\x27POST'+'\x27,\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20heade'+'rs:\x20{\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x27Content'+'-Type\x27:\x20\x27a'+'pplication'+'/json\x27,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'},\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20body:'+'\x20JSON.stri'+'ngify(data'+')\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'});\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20if\x20(respo'+'nse.ok)\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20showAler'+'t(\x27Setting'+'s\x20saved\x20su'+'ccessfully'+'!\x27);\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20gen'+'erateSubsc'+'ribe();\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20}\x20el'+'se\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20sho'+'wAlert(\x27Er'+'ror\x20saving'+'\x20settings!'+'\x27,\x20true);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20}\x0a'+'\x20\x20\x20\x20}\x20catc'+'h\x20(error)\x20'+'{\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'showAlert('+'\x27Error\x20sav')+('ing\x20settin'+'gs!\x27,\x20true'+');\x0a\x20\x20\x20\x20}\x0a}'+'\x0a\x0aasync\x20fu'+'nction\x20res'+'etSettings'+'()\x20{\x0a\x20\x20\x20\x20c'+'onst\x20alert'+'Overlay\x20=\x20'+'document.c'+'reateEleme'+'nt(\x27div\x27);'+'\x0a\x20\x20\x20\x20alert'+'Overlay.st'+'yle.positi'+'on\x20=\x20\x27fixe'+'d\x27;\x0a\x20\x20\x20\x20al'+'ertOverlay'+'.style.top'+'\x20=\x20\x270\x27;\x0a\x20\x20'+'\x20\x20alertOve'+'rlay.style'+'.left\x20=\x20\x270'+'\x27;\x0a\x20\x20\x20\x20ale'+'rtOverlay.'+'style.widt'+'h\x20=\x20\x27100%\x27'+';\x0a\x20\x20\x20\x20aler'+'tOverlay.s'+'tyle.heigh'+'t\x20=\x20\x27100%\x27'+';\x0a\x20\x20\x20\x20aler'+'tOverlay.s'+'tyle.backg'+'roundColor'+'\x20=\x20\x27rgba(0'+',\x200,\x200,\x200.'+'7)\x27;\x0a\x20\x20\x20\x20a'+'lertOverla'+'y.style.di'+'splay\x20=\x20\x27f'+'lex\x27;\x0a\x20\x20\x20\x20'+'alertOverl'+'ay.style.j'+'ustifyCont'+'ent\x20=\x20\x27cen'+'ter\x27;\x0a\x20\x20\x20\x20'+'alertOverl'+'ay.style.a'+'lignItems\x20'+'=\x20\x27center\x27'+';\x0a\x20\x20\x20\x20aler'+'tOverlay.s'+'tyle.zInde'+'x\x20=\x20\x2710000'+'\x27;\x0a\x20\x20\x20\x20\x0a\x20\x20'+'\x20\x20const\x20al'+'ertBox\x20=\x20d'+'ocument.cr'+'eateElemen'+'t(\x27div\x27);\x0a'+'\x20\x20\x20\x20alertB'+'ox.style.b'+'ackground\x20'+'=\x20\x27linear-'+'gradient(1'+'35deg,\x20#f9'+'7316\x200%,\x20#'+'ea580c\x20100'+'%)\x27;\x0a\x20\x20\x20\x20a'+'lertBox.st'+'yle.paddin'+'g\x20=\x20\x2725px\x27'+';\x0a\x20\x20\x20\x20aler'+'tBox.style'+'.borderRad'+'ius\x20=\x20\x2715p'+'x\x27;\x0a\x20\x20\x20\x20al'+'ertBox.sty'+'le.boxShad'+'ow\x20=\x20\x270\x204p'+'x\x2020px\x20rgb'+'a(0,\x200,\x200,'+'\x200.3)\x27;\x0a\x20\x20'+'\x20\x20alertBox'+'.style.col'+'or\x20=\x20\x27whit'+'e\x27;\x0a\x20\x20\x20\x20al'+'ertBox.sty'+'le.textAli'+'gn\x20=\x20\x27cent'+'er\x27;\x0a\x20\x20\x20\x20a'+'lertBox.st'+'yle.maxWid'+'th\x20=\x20\x27400p'+'x\x27;\x0a\x20\x20\x20\x20al'+'ertBox.sty'+'le.width\x20='+'\x20\x2790%\x27;\x0a\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20con')+('st\x20message'+'\x20=\x20documen'+'t.createEl'+'ement(\x27p\x27)'+';\x0a\x20\x20\x20\x20mess'+'age.textCo'+'ntent\x20=\x20\x27A'+'re\x20you\x20sur'+'e\x20you\x20want'+'\x20to\x20reset\x20'+'all\x20settin'+'gs?\x27;\x0a\x20\x20\x20\x20'+'message.st'+'yle.margin'+'Bottom\x20=\x20\x27'+'20px\x27;\x0a\x20\x20\x20'+'\x20message.s'+'tyle.fontS'+'ize\x20=\x20\x2716p'+'x\x27;\x0a\x20\x20\x20\x20me'+'ssage.styl'+'e.fontWeig'+'ht\x20=\x20\x27600\x27'+';\x0a\x20\x20\x20\x20\x0a\x20\x20\x20'+'\x20const\x20but'+'tonContain'+'er\x20=\x20docum'+'ent.create'+'Element(\x27d'+'iv\x27);\x0a\x20\x20\x20\x20'+'buttonCont'+'ainer.styl'+'e.display\x20'+'=\x20\x27flex\x27;\x0a'+'\x20\x20\x20\x20button'+'Container.'+'style.gap\x20'+'=\x20\x2715px\x27;\x0a'+'\x20\x20\x20\x20button'+'Container.'+'style.just'+'ifyContent'+'\x20=\x20\x27center'+'\x27;\x0a\x20\x20\x20\x20\x0a\x20\x20'+'\x20\x20const\x20co'+'nfirmButto'+'n\x20=\x20docume'+'nt.createE'+'lement(\x27bu'+'tton\x27);\x0a\x20\x20'+'\x20\x20confirmB'+'utton.text'+'Content\x20=\x20'+'\x27Yes\x27;\x0a\x20\x20\x20'+'\x20confirmBu'+'tton.style'+'.padding\x20='+'\x20\x2710px\x2020p'+'x\x27;\x0a\x20\x20\x20\x20co'+'nfirmButto'+'n.style.bo'+'rder\x20=\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20c'+'onfirmButt'+'on.style.b'+'orderRadiu'+'s\x20=\x20\x278px\x27;'+'\x0a\x20\x20\x20\x20confi'+'rmButton.s'+'tyle.backg'+'round\x20=\x20\x27l'+'inear-grad'+'ient(135de'+'g,\x20#ef4444'+'\x200%,\x20#dc26'+'26\x20100%)\x27;'+'\x0a\x20\x20\x20\x20confi'+'rmButton.s'+'tyle.color'+'\x20=\x20\x27white\x27'+';\x0a\x20\x20\x20\x20conf'+'irmButton.'+'style.curs'+'or\x20=\x20\x27poin'+'ter\x27;\x0a\x20\x20\x20\x20'+'confirmBut'+'ton.style.'+'fontWeight'+'\x20=\x20\x27600\x27;\x0a'+'\x0a\x20\x20\x20\x20const'+'\x20cancelBut'+'ton\x20=\x20docu'+'ment.creat'+'eElement(\x27'+'button\x27);\x0a'+'\x20\x20\x20\x20cancel'+'Button.tex'+'tContent\x20='+'\x20\x27No\x27;\x0a\x20\x20\x20'+'\x20cancelBut')+('ton.style.'+'padding\x20=\x20'+'\x2710px\x2020px'+'\x27;\x0a\x20\x20\x20\x20can'+'celButton.'+'style.bord'+'er\x20=\x20\x27none'+'\x27;\x0a\x20\x20\x20\x20can'+'celButton.'+'style.bord'+'erRadius\x20='+'\x20\x278px\x27;\x0a\x20\x20'+'\x20\x20cancelBu'+'tton.style'+'.backgroun'+'d\x20=\x20\x27linea'+'r-gradient'+'(135deg,\x20#'+'22c55e\x200%,'+'\x20#16a34a\x201'+'00%)\x27;\x0a\x20\x20\x20'+'\x20cancelBut'+'ton.style.'+'color\x20=\x20\x27w'+'hite\x27;\x0a\x20\x20\x20'+'\x20cancelBut'+'ton.style.'+'cursor\x20=\x20\x27'+'pointer\x27;\x0a'+'\x20\x20\x20\x20cancel'+'Button.sty'+'le.fontWei'+'ght\x20=\x20\x27600'+'\x27;\x0a\x20\x20\x20\x20\x0a\x20\x20'+'\x20\x20buttonCo'+'ntainer.ap'+'pendChild('+'confirmBut'+'ton);\x0a\x20\x20\x20\x20'+'buttonCont'+'ainer.appe'+'ndChild(ca'+'ncelButton'+');\x0a\x20\x20\x20\x20ale'+'rtBox.appe'+'ndChild(me'+'ssage);\x0a\x20\x20'+'\x20\x20alertBox'+'.appendChi'+'ld(buttonC'+'ontainer);'+'\x0a\x20\x20\x20\x20alert'+'Overlay.ap'+'pendChild('+'alertBox);'+'\x0a\x20\x20\x20\x20docum'+'ent.body.a'+'ppendChild'+'(alertOver'+'lay);\x0a\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20retur'+'n\x20new\x20Prom'+'ise((resol'+'ve)\x20=>\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20con'+'firmButton'+'.onclick\x20='+'\x20()\x20=>\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'body.remov'+'eChild(ale'+'rtOverlay)'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20resolv'+'e(true);\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20};\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20can'+'celButton.'+'onclick\x20=\x20'+'()\x20=>\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.b'+'ody.remove'+'Child(aler'+'tOverlay);'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20resolve'+'(false);\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20};\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20ale'+'rtOverlay.'+'onclick\x20=\x20'+'(e)\x20=>\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20if\x20(e.tar'+'get\x20===\x20al'+'ertOverlay')+(')\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.b'+'ody.remove'+'Child(aler'+'tOverlay);'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20res'+'olve(false'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20}\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20};\x0a\x20\x20'+'\x20\x20}).then('+'async\x20(con'+'firmed)\x20=>'+'\x20{\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20if\x20(confi'+'rmed)\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.g'+'etElementB'+'yId(\x27limit'+'\x27).value\x20='+'\x20\x27all\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.g'+'etElementB'+'yId(\x27dns\x27)'+'.value\x20=\x20\x27'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'direct\x27).v'+'alue\x20=\x20\x27\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27cl'+'eanip\x27).va'+'lue\x20=\x20\x27\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27dom'+'ain\x27).valu'+'e\x20=\x20\x27\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.g'+'etElementB'+'yId(\x27sni\x27)'+'.value\x20=\x20\x27'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'alpn\x27).val'+'ue\x20=\x20\x27none'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'fingerprin'+'t\x27).value\x20'+'=\x20\x27none\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27ipv'+'er\x27).value'+'\x20=\x20\x27none\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27ne'+'twork\x27).va'+'lue\x20=\x20\x27non'+'e\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27tls\x27).val'+'ue\x20=\x20\x27none'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'udp\x27).valu'+'e\x20=\x20\x27none\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27f'+'ragment_en'+'abled\x27).ch'+'ecked\x20=\x20fa'+'lse;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById')+('(\x27frag_pac'+'kets\x27).val'+'ue\x20=\x20\x272-8\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27f'+'rag_length'+'\x27).value\x20='+'\x20\x27100-300\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27f'+'rag_interv'+'al\x27).value'+'\x20=\x20\x2710-30\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27f'+'rag_sleep\x27'+').value\x20=\x20'+'\x2750\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20toggleFra'+'gmentSetti'+'ngs();\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20try\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20await\x20'+'fetch(\x27/ap'+'i/settings'+'\x27,\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20metho'+'d:\x20\x27POST\x27,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20headers:\x20'+'{\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x27Con'+'tent-Type\x27'+':\x20\x27applica'+'tion/json\x27'+',\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20},\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20body:'+'\x20JSON.stri'+'ngify({})\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20});\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20show'+'Alert(\x27Set'+'tings\x20rese'+'t\x20successf'+'ully!\x27);\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20gener'+'ateSubscri'+'be();\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20}\x20'+'catch\x20(err'+'or)\x20{\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20showAler'+'t(\x27Error\x20r'+'esetting\x20s'+'ettings!\x27,'+'\x20true);\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'}\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'}\x20else\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20showAlert'+'(\x27Reset\x20ca'+'ncelled\x27,\x20'+'false);\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20}\x0a\x20\x20'+'\x20\x20});\x0a}\x0a\x0af'+'unction\x20ge'+'nerateSubs'+'cribe()\x20{\x0a'+'\x20\x20\x20\x20const\x20'+'baseUrl\x20=\x20'+'window.loc'+'ation.orig'+'in;\x0a\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27subscri'+'be_v2ray\x27)'+'.value\x20=\x20b')+('aseUrl\x20+\x20\x27'+'/api/confi'+'gs\x27;\x0a\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27subscr'+'ibe_clash\x27'+').value\x20=\x20'+'baseUrl\x20+\x20'+'\x27/api/conf'+'igs?format'+'=clash\x27;\x0a\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27su'+'bscribe_si'+'ngbox\x27).va'+'lue\x20=\x20base'+'Url\x20+\x20\x27/ap'+'i/configs?'+'format=sin'+'gbox\x27;\x0a}\x0a\x0a'+'async\x20func'+'tion\x20copyT'+'oClipboard'+'(elementId'+')\x20{\x0a\x20\x20\x20\x20tr'+'y\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20const\x20co'+'pyText\x20=\x20d'+'ocument.ge'+'tElementBy'+'Id(element'+'Id);\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20copyTex'+'t.select()'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'copyText.s'+'etSelectio'+'nRange(0,\x20'+'99999);\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20awai'+'t\x20navigato'+'r.clipboar'+'d.writeTex'+'t(copyText'+'.value);\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20sho'+'wAlert(\x27Co'+'pied\x20to\x20cl'+'ipboard!\x27)'+';\x0a\x20\x20\x20\x20}\x20ca'+'tch\x20(error'+')\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20showAler'+'t(\x27Failed\x20'+'to\x20copy!\x27,'+'\x20true);\x0a\x20\x20'+'\x20\x20}\x0a}\x0a\x0a\x20\x20\x20'+'async\x20func'+'tion\x20loadS'+'ettings()\x20'+'{\x0a\x20\x20\x20\x20try\x20'+'{\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'const\x20resp'+'onse\x20=\x20awa'+'it\x20fetch(\x27'+'/api/setti'+'ngs\x27);\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20const'+'\x20s\x20=\x20await'+'\x20response.'+'json();\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20if\x20(s'+')\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27limit\x27).v'+'alue\x20=\x20s.l'+'imit\x20||\x20\x27a'+'ll\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27dns\x27).va'+'lue\x20=\x20s.dn'+'s\x20||\x20\x27\x27;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27dire'+'ct\x27).value'+'\x20=\x20s.direc'+'t\x20||\x20\x27\x27;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27clea')+('nip\x27).valu'+'e\x20=\x20s.clea'+'nip\x20||\x20\x27\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27do'+'main\x27).val'+'ue\x20=\x20s.dom'+'ain\x20||\x20\x27\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27sn'+'i\x27).value\x20'+'=\x20s.sni\x20||'+'\x20\x27\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27alpn\x27).v'+'alue\x20=\x20s.a'+'lpn\x20||\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27fingerpr'+'int\x27).valu'+'e\x20=\x20s.fing'+'erprint\x20||'+'\x20\x27none\x27;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27ipve'+'r\x27).value\x20'+'=\x20s.ipver\x20'+'||\x20\x27none\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27ne'+'twork\x27).va'+'lue\x20=\x20s.ne'+'twork\x20||\x20\x27'+'none\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27tls\x27).'+'value\x20=\x20s.'+'tls\x20||\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27udp\x27).va'+'lue\x20=\x20s.ud'+'p\x20||\x20\x27none'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20if'+'\x20(s.fragme'+'nt)\x20{\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27fra'+'gment_enab'+'led\x27).chec'+'ked\x20=\x20s.fr'+'agment.ena'+'bled\x20||\x20fa'+'lse;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27frag'+'_packets\x27)'+'.value\x20=\x20s'+'.fragment.'+'packets\x20||'+'\x20\x272-8\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27f'+'rag_length'+'\x27).value\x20='+'\x20s.fragmen'+'t.length\x20|'+'|\x20\x27100-300'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_i'+'nterval\x27).'+'value\x20=\x20s.')+('fragment.i'+'nterval\x20||'+'\x20\x2710-30\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27frag_slee'+'p\x27).value\x20'+'=\x20s.fragme'+'nt.sleep\x20|'+'|\x20\x2750\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'}\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'}\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20t'+'oggleFragm'+'entSetting'+'s();\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20generat'+'eSubscribe'+'();\x0a\x20\x20\x20\x20}\x20'+'catch\x20(err'+'or)\x20{\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20consol'+'e.error(\x27E'+'rror\x20loadi'+'ng\x20setting'+'s:\x27,\x20error'+');\x0a\x20\x20\x20\x20}\x0a}'+'\x0a\x0adocument'+'.getElemen'+'tById(\x27fra'+'gment_enab'+'led\x27).addE'+'ventListen'+'er(\x27change'+'\x27,\x20toggleF'+'ragmentSet'+'tings);\x0awi'+'ndow.onloa'+'d\x20=\x20loadSe'+'ttings;\x0a</'+'script>\x0a</'+'body>\x0a</ht'+'ml>');}


//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
