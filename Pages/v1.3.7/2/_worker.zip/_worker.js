// ==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING

const _0xb=(function(){let a=!![];return function(b,c){const d=a?function(){if(c){const e=c['apply'](b,arguments);c=null;return e;}}:function(){};a=![];return d;};}());const _0xa=_0xb(this,function(){return _0xa['toString']()['search']('(((.+)+)+)'+'+$')['toString']()['constructo'+'r'](_0xa)['search']('(((.+)+)+)'+'+$');});_0xa();const ARISTA_TAG='ARISTA🔥';const SETTINGS_KV_KEY='settings';const CONFIG_SOURCE_URLS=['https://cd'+'n.jsdelivr'+'.net/gh/Ma'+'hsaNetConf'+'igTopic/co'+'nfig@main/'+'xray_final'+'.txt','https://cd'+'n.jsdelivr'+'.net/gh/As'+'hkan-m/v2r'+'ay@main/Su'+'b.txt','https://cd'+'n.jsdelivr'+'.net/gh/Ra'+'yan-Config'+'/C-Sub@mai'+'n/configs/'+'proxy.txt'];let ALL_CONFIGS=[];const PORT_PRIORITIES=[0x830,0x1bb,0x20fb,0x1f90];const CONFIG_LIMITS=[0x14,0x28,0x3c,0x64,'all'];function isIP(a){return/^(\d{1,3}\.){3}\d{1,3}$/['test'](a)||/^([0-9a-fA-F]*:){2,7}[0-9a-fA-F]*$/['test'](a);}function sortConfigsByPortPriority(a){return a['sort']((c,d)=>{const e=h=>{try{const i=new URL(h);const j=parseInt(i['port'])||0x1bb;const k=PORT_PRIORITIES['indexOf'](j);return k!==-0x1?k:PORT_PRIORITIES['length'];}catch{return PORT_PRIORITIES['length'];}};const f=e(c);const g=e(d);if(f!==g){return f-g;}try{const h=parseInt(new URL(c)['port'])||0x1bb;const i=parseInt(new URL(d)['port'])||0x1bb;return h-i;}catch{return 0x0;}});}function applyConfigLimit(a,b){if(b==='all')return a;const c=parseInt(b);if(isNaN(c)||c<=0x0)return a;const d=sortConfigsByPortPriority(a);const e=d['filter'](i=>{try{const j=new URL(i);const k=parseInt(j['port'])||0x1bb;return PORT_PRIORITIES['includes'](k);}catch{return![];}});const f=d['filter'](i=>{try{const j=new URL(i);const k=parseInt(j['port'])||0x1bb;return!PORT_PRIORITIES['includes'](k);}catch{return![];}});const g=Math['min'](e['length'],Math['ceil'](c*0.6));const h=Math['min'](f['length'],c-g);return[...e['slice'](0x0,g),...f['slice'](0x0,h)]['slice'](0x0,c);}async function updateConfigs(){try{let a=[];for(const b of CONFIG_SOURCE_URLS){const c=await fetch(b);if(!c['ok'])continue;const d=await c['text']();let f=d['split']('\x0a')['filter'](g=>g['startsWith']('vless://'));a=a['concat'](f);}ALL_CONFIGS=[...new Set(a)];console['log']('Updated\x20co'+'nfigs:\x20'+ALL_CONFIGS['length']+('\x20unique\x20co'+'nfiguratio'+'ns\x20loaded'));}catch(g){console['error']('Error\x20upda'+'ting\x20confi'+'gs:',g);}}async function checkConfigStatus(){try{console['log']('Config\x20Sta'+'tus:',{'configsLoaded':ALL_CONFIGS['length'],'configsSample':ALL_CONFIGS['slice'](0x0,0x3)});return!![];}catch(a){console['error']('Config\x20Sta'+'tus\x20Check\x20'+'Failed:',a);return![];}}function applyFragmentSettings(a,b){if(!b||Object['keys'](b)['length']===0x0||!b['enabled']){return a;}try{const c=new URL(a);c['searchPara'+'ms']['set']('fragment','true');if(b['packets'])c['searchPara'+'ms']['set']('fragmentPa'+'ckets',b['packets']);if(b['length'])c['searchPara'+'ms']['set']('fragmentLe'+'ngth',b['length']);if(b['interval'])c['searchPara'+'ms']['set']('fragmentIn'+'terval',b['interval']);if(b['sleep'])c['searchPara'+'ms']['set']('fragmentSl'+'eep',b['sleep']['toString']());return c['toString']();}catch(d){return a;}}function applyTag(a){try{const b=new URL(a);b['hash']=ARISTA_TAG;return b['toString']();}catch{return a;}}function applyCustomSettings(a,b){try{const c=new URL(a);const d=Object['fromEntrie'+'s'](c['searchPara'+'ms']['entries']());const f=c['hostname'];const g=d['sni']||d['host']||f;const h=(p,q)=>{if(b[p]&&b[p]!=='none'){return b[p];}return d[q]||undefined;};if(b['dns']&&b['dns']!=='none'){c['searchPara'+'ms']['set']('dns',b['dns']);}if(b['direct']&&b['direct']!=='none'){c['searchPara'+'ms']['set']('direct',b['direct']);}const i=h('cleanip','cleanip');const j=(i||'')['split'](',')['map'](p=>p['trim']())['filter'](Boolean);if(j['length']>0x0){c['hostname']=j[0x0];}const k=h('domain','domain');const l=h('domain','host')||k;if(l&&l!=='none'){c['searchPara'+'ms']['set']('host',l);c['searchPara'+'ms']['set']('domain',l);}const m=h('sni','sni');const n=(m||'')['split'](',')['map'](p=>p['trim']())['filter'](Boolean);let o=n[0x0]||k||l||g;if(j['length']>0x0&&isIP(c['hostname'])){if(!o||isIP(o)){o=g||'cloudflare'+'.com';}c['searchPara'+'ms']['set']('sni',o);}else if(m&&m!=='none'){c['searchPara'+'ms']['set']('sni',m);}else if(l&&l!=='none'){c['searchPara'+'ms']['set']('sni',l);}if(b['alpn']&&b['alpn']!=='none'){c['searchPara'+'ms']['set']('alpn',b['alpn']);}if(b['ipver']&&b['ipver']!=='none'){c['searchPara'+'ms']['set']('ipver',b['ipver']);}if(b['network']&&b['network']!=='none'){c['searchPara'+'ms']['set']('type',b['network']);}if(b['tls']&&b['tls']!=='none'){c['searchPara'+'ms']['set']('security',b['tls']==='enabled'?'tls':'none');}if(b['udp']&&b['udp']!=='none'){c['searchPara'+'ms']['set']('udp',b['udp']==='enabled'?'true':'false');}if(b['fingerprin'+'t']&&b['fingerprin'+'t']!=='none'){c['searchPara'+'ms']['set']('fp',b['fingerprin'+'t']);}return c['toString']();}catch(p){return a;}}function vlessToClashMeta(h,i,j,k){try{const l=new URL(h);const m=Object['fromEntrie'+'s'](l['searchPara'+'ms']['entries']());const n='ARISTA🔥-'+j;const o=(C,D)=>{if(k[C]&&k[C]!=='none'){return k[C];}return m[D]||undefined;};const p=(C,D)=>{if(k[C]&&k[C]!=='none'){return k[C]==='enabled';}return m[D]==='true'||undefined;};const q=o('network','type')||'tcp';const r=p('tls','security');const s=p('udp','udp')!==![];const t=o('cleanip','cleanip');const u=(t||'')['split'](',')['map'](C=>C['trim']())['filter'](Boolean);const v=o('domain','domain');const w=o('domain','host')||l['hostname'];const x=u[0x0]||v||l['hostname'];let y=v||m['host']||o('sni','sni')||l['hostname'];if(isIP(x)&&isIP(y)){y=m['host']||l['hostname']||'cloudflare'+'.com';}const z=o('fingerprin'+'t','fp')||'chrome';const A=o('alpn','alpn');const B={'name':n,'type':'vless','server':x,'port':parseInt(l['port'])||0x1bb,'uuid':l['username']['split']('@')[0x0],'network':q,'tls':r!==![],'udp':s,'skip-cert-verify':![],'tcp-fast-open':!![],'fast-open':!![],'servername':y,'flow':m['flow']||'','client-fingerprint':z,'packet-encoding':'xudp'};if(k['dns']&&k['dns']!=='none'){B['dns']=k['dns']['split'](',')['map'](C=>C['trim']());}if(k['direct']&&k['direct']!=='none'){if(B['dns']){if(!B['fallback-d'+'ns']){B['fallback-d'+'ns']=k['direct']['split'](',')['map'](C=>C['trim']());}}else{B['dns']=k['direct']['split'](',')['map'](C=>C['trim']());}}if(A&&A!=='none'){B['alpn']=A['split'](',')['map'](C=>C['trim']());}else if(r){B['alpn']=['h2','http/1.1'];}if(k['fragment']&&k['fragment']['enabled']){B['fragment']={'enabled':!![],'packets':k['fragment']['packets']||m['fragmentPa'+'ckets']||'2-5','length':k['fragment']['length']||m['fragmentLe'+'ngth']||'100-200','interval':k['fragment']['interval']||m['fragmentIn'+'terval']||'10-20','sleep':parseInt(k['fragment']['sleep']||m['fragmentSl'+'eep']||'10')};}if(q==='ws'){const C={};C['Host']=y;C['User-Agent']='Mozilla/5.'+'0\x20(Windows'+'\x20NT\x2010.0;\x20'+'Win64;\x20x64'+')\x20AppleWeb'+'Kit/537.36';B['ws-opts']={'path':m['path']||'/','headers':C,'max-early-data':parseInt(m['maxEarlyDa'+'ta'])||0x800,'early-data-header-name':m['earlyDataH'+'eaderName']||'Sec-WebSoc'+'ket-Protoc'+'ol'};}if(q==='grpc'){const D={};D['grpc-servi'+'ce-name']=v||m['serviceNam'+'e']||'GunService';D['grpc-mode']='gun';B['grpc-opts']=D;}if(q==='http'){const E={};E['Host']=y;E['User-Agent']='Mozilla/5.'+'0\x20(Windows'+'\x20NT\x2010.0;\x20'+'Win64;\x20x64'+')\x20AppleWeb'+'Kit/537.36';const F={};F['method']=m['method']||'GET';F['path']=m['path']||'/';F['headers']=E;B['http-opts']=F;}if(q==='quic'){const G={};G['security']=m['quicSecuri'+'ty']||'none';G['key']=m['key']||'';G['type']=m['headerType']||'none';B['quic-opts']=G;}if(m['security']==='reality'){const H={};H['public-key']=m['pbk']||'';H['short-id']=m['sid']||'';B['reality-op'+'ts']=H;}if(k['ipver']&&k['ipver']!=='none'){B['ipversion']=k['ipver'];}return B;}catch(I){console['error']('Error\x20in\x20v'+'lessToClas'+'hMeta:',I);return null;}}function generateSingBoxConfig(m,n){const o=[];const p=[];m['forEach']((z,A)=>{try{const B=new URL(z);if(B['username']&&B['hostname']&&B['port']){const C=vlessToSingBox(z,A+0x1,n);if(C){o['push'](C);p['push'](C['tag']);}}}catch(D){console['error']('Invalid\x20co'+'nfig\x20skipp'+'ed:',D);}});if(p['length']===0x0){const z={};z['level']='info';z['timestamp']=!![];const A={};A['type']='direct';A['tag']='direct';const B={};B['rules']=[];const C={};C['log']=z;C['inbounds']=[];C['outbounds']=[A];C['route']=B;return C;}const q={};q['level']='info';q['timestamp']=!![];const r={};r['type']='tun';r['tag']='tun-in';r['interface_'+'name']='tun0';r['mtu']=0x5dc;r['inet4_addr'+'ess']='172.19.0.1'+'/30';r['auto_route']=!![];r['strict_rou'+'te']=!![];r['stack']='system';r['sniff']=!![];const s={};s['type']='direct';s['tag']='direct';const t={};t['type']='urltest';t['tag']='auto-test';t['outbounds']=p;t['url']='http://con'+'nectivityc'+'heck.gstat'+'ic.com/gen'+'erate_204';t['interval']='5m';t['tolerance']=0x96;const u={};u['type']='selector';u['tag']='proxy';u['outbounds']=['auto-test',...p];const v={};v['inbound']='tun-in';v['outbound']='proxy';const w={};w['rules']=[v];w['auto_detec'+'t_interfac'+'e']=!![];w['final']='proxy';const x={};x['log']=q;x['inbounds']=[r];x['outbounds']=[s,t,u,...o];x['route']=w;const y=x;return y;}function vlessToSingBox(i,j,k){try{const l=new URL(i);const m=Object['fromEntrie'+'s'](l['searchPara'+'ms']['entries']());const n='ARISTA-'+(j+0x1);const o=(E,F)=>{if(k[E]&&k[E]!=='none'){return k[E];}return m[F]||undefined;};const p=o('cleanip','cleanip');const q=(p||'')['split'](',')['map'](E=>E['trim']())['filter'](Boolean);const r=o('sni','sni');const s=o('fingerprin'+'t','fp');const t=o('alpn','alpn');const u=o('network','type');const v=o('tls','security');const w=o('udp','udp');const x=o('ipver','ipver');const y=q[0x0]||l['hostname'];let z=r||m['sni']||m['host']||l['hostname'];if(isIP(y)&&(!z||isIP(z)||!z['includes']('.'))){z=l['hostname'];}const A={};A['enabled']=!![];A['fingerprin'+'t']=s||'chrome';const B={};B['enabled']=!![];B['server_nam'+'e']=z;B['insecure']=![];B['utls']=A;const C={'type':'vless','tag':n,'server':y,'server_port':parseInt(l['port'])||0x1bb,'uuid':l['username'],'packet_encoding':'xudp','tls':B};if(m['flow']){C['flow']=m['flow'];}if(t&&t!=='none'){C['tls']['alpn']=t['split'](',')['map'](E=>E['trim']());}if(w&&w!=='none'){C['udp']=w==='enabled';}if(x&&x!=='none'){C['domain_str'+'ategy']=x;}const D=u&&u!=='none'?u:m['type']||'tcp';if(D==='ws'){const E={};E['Host']=z;const F={};F['type']='ws';F['path']=m['path']||'/';F['headers']=E;C['transport']=F;}else if(D==='grpc'){const G={};G['type']='grpc';G['service_na'+'me']=m['serviceNam'+'e']||'GunService';C['transport']=G;}if(v==='disabled'){const H={};H['enabled']=![];C['tls']=H;}if(m['security']==='reality'){const I={};I['enabled']=!![];I['public_key']=m['pbk']||'';I['short_id']=m['sid']||'';C['tls']['reality']=I;}return C;}catch(J){console['error']('Error\x20conv'+'erting\x20VLE'+'SS\x20to\x20Sing'+'Box:',J);return null;}}export default{async 'scheduled'(a,b,c){if(a['cron']==='0\x20*/3\x20*\x20*\x20'+'*'){c['waitUntil'](updateConfigs());}},async 'fetch'(w,x,y){const z=new URL(w['url']);if(z['pathname']==='/'){const B={};B['content-ty'+'pe']='text/html;'+'charset=ut'+'f-8';B['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const C={};C['headers']=B;return new Response(getHTML(),C);}if(z['pathname']==='/api/setti'+'ngs'){if(w['method']==='POST'){try{const D=await w['json']();await x['KV']['put'](SETTINGS_KV_KEY,JSON['stringify'](D));const E={};E['ok']=!![];const F={};F['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';const G={};G['headers']=F;return new Response(JSON['stringify'](E),G);}catch(H){const I={};I['error']='Invalid\x20JS'+'ON';const J={};J['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';const K={};K['status']=0x190;K['headers']=J;return new Response(JSON['stringify'](I),K);}}else{try{const L=await x['KV']['get'](SETTINGS_KV_KEY);const M={};M['content-ty'+'pe']='applicatio'+'n/json';M['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const N={};N['headers']=M;return new Response(L||'{}',N);}catch(O){const P={};P['content-ty'+'pe']='applicatio'+'n/json';const Q={};Q['headers']=P;return new Response('{}',Q);}}}if(z['pathname']==='/api/confi'+'gs'){try{if(ALL_CONFIGS['length']===0x0){await updateConfigs();}let R=[...ALL_CONFIGS];if(R['length']===0x0){const a1={};a1['status']=0x194;return new Response('No\x20configu'+'rations\x20fo'+'und',a1);}const S=await x['KV']['get'](SETTINGS_KV_KEY);const T=S?JSON['parse'](S):{};const U=z['searchPara'+'ms']['get']('limit')||'all';R=applyConfigLimit(R,U);const V=(T['cleanip']||'')['split'](',')['map'](a2=>a2['trim']())['filter'](Boolean);const W=(T['sni']||'')['split'](',')['map'](a2=>a2['trim']())['filter'](Boolean);let X=[];if(V['length']>0x1){R['forEach']((a2,a3)=>{V['forEach']((a4,a5)=>{let a6=a2;const a7={...T};const a8=a7;a8['cleanip']=a4;if(W[a5]){a8['sni']=W[a5];}else if(W['length']>0x0){a8['sni']=W[W['length']-0x1];}a6=applyCustomSettings(a6,a8);if(T['fragment']&&T['fragment']['enabled']){a6=applyFragmentSettings(a6,T['fragment']);}X['push'](applyTag(a6));});});}else{X=R['map'](a2=>{let a3=a2;a3=applyCustomSettings(a3,T);if(T['fragment']&&T['fragment']['enabled']){a3=applyFragmentSettings(a3,T['fragment']);}return applyTag(a3);});}R=X;const Y=z['searchPara'+'ms']['get']('format')||'v2ray';if(Y==='clash'){const a2={};a2['geoip']=!![];a2['geoip-code']='IR';a2['ipcidr']=['0.0.0.0/8','127.0.0.0/'+'8','10.0.0.0/8','172.16.0.0'+'/12','192.168.0.'+'0/16'];const a3={'port':0x1ed2,'socks-port':0x1ed3,'mixed-port':0x1ed5,'mode':'rule','log-level':'info','dns':{'enable':!![],'listen':':53','enhanced-mode':'fake-ip','fake-ip-range':'198.18.0.1'+'/16','fake-ip-filter':['*.lan','*.local','*.localhos'+'t','*.ir','*.test'],'nameserver':T['dns']&&T['dns']!=='none'?T['dns']['split'](',')['map'](a7=>a7['trim']()):['78.157.42.'+'100','78.157.42.'+'101','10.202.10.'+'10','8.8.8.8','1.1.1.1'],'fallback':T['direct']&&T['direct']!=='none'?T['direct']['split'](',')['map'](a7=>a7['trim']()):['10.202.10.'+'11','78.157.42.'+'100','8.8.4.4'],'fallback-filter':a2},'proxies':[],'proxy-groups':[],'rules':['DOMAIN-SUF'+'FIX,google'+'.com,ARIST'+'A\x20Auto','DOMAIN-SUF'+'FIX,youtub'+'e.com,ARIS'+'TA\x20Auto','DOMAIN-SUF'+'FIX,github'+'.com,ARIST'+'A\x20Auto','DOMAIN-KEY'+'WORD,teleg'+'ram,ARISTA'+'\x20Auto','DOMAIN-SUF'+'FIX,instag'+'ram.com,AR'+'ISTA\x20Auto','DOMAIN-SUF'+'FIX,twitte'+'r.com,ARIS'+'TA\x20Auto','DOMAIN-SUF'+'FIX,whatsa'+'pp.com,ARI'+'STA\x20Auto','DOMAIN-SUF'+'FIX,cdn.ir'+',DIRECT','DOMAIN-SUF'+'FIX,aparat'+'.com,DIREC'+'T','DOMAIN-SUF'+'FIX,digika'+'la.com,DIR'+'ECT','DOMAIN-SUF'+'FIX,divar.'+'ir,DIRECT','DOMAIN-SUF'+'FIX,snapp.'+'ir,DIRECT','DOMAIN-SUF'+'FIX,torob.'+'com,DIRECT','DOMAIN-SUF'+'FIX,bamilo'+'.com,DIREC'+'T','DOMAIN-SUF'+'FIX,alibab'+'a.ir,DIREC'+'T','DOMAIN-SUF'+'FIX,ban.ir'+',DIRECT','GEOIP,IR,D'+'IRECT','MATCH,ARIS'+'TA\x20Auto']};const a4=[];R['forEach']((a7,a8)=>{const a9=vlessToClashMeta(a7,'ARISTA',a8+0x1,T);if(a9){a4['push'](a9);}});a3['proxies']=a4;if(a3['proxies']['length']>0x0){const a7=[];a7['push']({'name':'ARISTA\x20Sel'+'ect','type':'select','proxies':['ARISTA\x20Aut'+'o','ARISTA\x20Fal'+'lback','ARISTA\x20Loa'+'d\x20Balance',...a4['map'](a8=>a8['name'])],'disable-udp':![]});a7['push']({'name':'ARISTA\x20Aut'+'o','type':'url-test','proxies':a4['map'](a8=>a8['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x78,'tolerance':0x32,'lazy':!![],'disable-udp':![]});a7['push']({'name':'ARISTA\x20Fal'+'lback','type':'fallback','proxies':a4['map'](a8=>a8['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x78,'tolerance':0x64,'disable-udp':![]});a7['push']({'name':'ARISTA\x20Loa'+'d\x20Balance','type':'load-balan'+'ce','proxies':a4['map'](a8=>a8['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x12c,'strategy':'consistent'+'-hashing','disable-udp':![]});a3['proxy-grou'+'ps']=a7;}const a5={};a5['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';a5['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const a6={};a6['headers']=a5;return new Response(JSON['stringify'](a3,null,0x2),a6);}if(Y==='singbox'){const a8=generateSingBoxConfig(R,T);const a9={};a9['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';a9['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const aa={};aa['headers']=a9;return new Response(JSON['stringify'](a8,null,0x2),aa);}const Z={};Z['content-ty'+'pe']='text/plain'+';charset=u'+'tf-8';Z['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const a0={};a0['headers']=Z;return new Response(R['join']('\x0a'),a0);}catch(ab){console['error']('Error\x20in\x20/'+'api/config'+'s:',ab);const ac={};ac['status']=0x1f4;return new Response('Internal\x20S'+'erver\x20Erro'+'r',ac);}}const A={};A['status']=0x194;return new Response('Not\x20Found',A);}};function getHTML(){return'<!DOCTYPE\x20'+'html>\x0a<htm'+'l\x20lang=\x22en'+'\x22>\x0a<head>\x0a'+'<meta\x20char'+'set=\x22UTF-8'+'\x22\x20/>\x0a<meta'+'\x20name=\x22vie'+'wport\x22\x20con'+'tent=\x22widt'+'h=device-w'+'idth,\x20init'+'ial-scale='+'1.0\x22\x20/>\x0a<t'+'itle>ARIST'+'A\x20Config\x20G'+'enerator</'+'title>\x0a<st'+'yle>\x0a*\x20{\x20b'+'ox-sizing:'+'\x20border-bo'+'x;\x20margin:'+'\x200;\x20paddin'+'g:\x200;\x20}\x0abo'+'dy\x20{\x20font-'+'family:\x20\x27S'+'egoe\x20UI\x27,\x20'+'Tahoma,\x20Ge'+'neva,\x20Verd'+'ana,\x20sans-'+'serif;\x20bac'+'kground:\x20#'+'0b1c3d;\x20co'+'lor:\x20#fff;'+'\x20line-heig'+'ht:\x201.6;\x20}'+'\x0a.containe'+'r\x20{\x20max-wi'+'dth:\x20800px'+';\x20margin:\x20'+'0\x20auto;\x20pa'+'dding:\x2020p'+'x;\x20}\x0a.head'+'er\x20{\x20backg'+'round:\x20lin'+'ear-gradie'+'nt(135deg,'+'\x20#1a3b7c\x200'+'%,\x20#2c5282'+'\x20100%);\x20co'+'lor:\x20white'+';\x20padding:'+'\x2025px;\x20bor'+'der-radius'+':\x2015px;\x20ma'+'rgin-botto'+'m:\x2025px;\x20t'+'ext-align:'+'\x20center;\x20b'+'ox-shadow:'+'\x200\x204px\x2015p'+'x\x20rgba(0,0'+',0,0.2);\x20}'+'\x0ah1\x20{\x20marg'+'in:\x200;\x20fon'+'t-size:\x2028'+'px;\x20font-w'+'eight:\x20700'+';\x20}\x0a.heade'+'r\x20p\x20{\x20marg'+'in:\x2010px\x200'+'\x200;\x20opacit'+'y:\x200.9;\x20}\x0a'+'.card\x20{\x20ba'+'ckground:\x20'+'#13274f;\x20p'+'adding:\x2025'+'px;\x20border'+'-radius:\x201'+'5px;\x20margi'+'n:\x2015px\x200;'+'\x20box-shado'+'w:\x200\x204px\x201'+'0px\x20rgba(0'+',0,0,0.15)'+';\x20}\x0alabel\x20'+'{\x20display:'+'\x20block;\x20ma'+'rgin-top:\x20'+'15px;\x20font'+'-weight:\x206'+'00;\x20color:'+'\x20#e2e8f0;\x20'+'}\x0a.help-te'+'xt\x20{\x20font-'+'size:\x2013px'+';\x20color:\x20#'+'a0aec0;\x20ma'+'rgin-top:\x20'+'5px;\x20}\x0ainp'+('ut,\x20select'+',\x20textarea'+'\x20{\x20width:\x20'+'100%;\x20padd'+'ing:\x2012px;'+'\x20margin-to'+'p:\x208px;\x20bo'+'rder:\x201px\x20'+'solid\x20#2d3'+'748;\x20borde'+'r-radius:\x20'+'8px;\x20backg'+'round:\x20#0b'+'1c3d;\x20colo'+'r:\x20#fff;\x20f'+'ont-size:\x20'+'14px;\x20tran'+'sition:\x20al'+'l\x200.3s\x20eas'+'e;\x20}\x0ainput'+':focus,\x20se'+'lect:focus'+',\x20textarea'+':focus\x20{\x20o'+'utline:\x20no'+'ne;\x20border'+'-color:\x20#4'+'299e1;\x20box'+'-shadow:\x200'+'\x200\x200\x203px\x20r'+'gba(66,\x2015'+'3,\x20225,\x200.'+'2);\x20}\x0abutt'+'on\x20{\x20margi'+'n-top:\x2020p'+'x;\x20padding'+':\x2014px;\x20wi'+'dth:\x20100%;'+'\x20border:\x20n'+'one;\x20borde'+'r-radius:\x20'+'8px;\x20color'+':\x20#fff;\x20fo'+'nt-weight:'+'\x20600;\x20curs'+'or:\x20pointe'+'r;\x20transit'+'ion:\x20all\x200'+'.3s\x20ease;\x20'+'font-size:'+'\x2016px;\x20}\x0ab'+'utton:hove'+'r\x20{\x20transf'+'orm:\x20trans'+'lateY(-2px'+');\x20box-sha'+'dow:\x200\x204px'+'\x2012px\x20rgba'+'(0,0,0,0.2'+');\x20}\x0a.btn-'+'save\x20{\x20bac'+'kground:\x20l'+'inear-grad'+'ient(135de'+'g,\x20#22c55e'+'\x200%,\x20#16a3'+'4a\x20100%);\x20'+'}\x0a.btn-res'+'et\x20{\x20\x0a\x20\x20ba'+'ckground:\x20'+'linear-gra'+'dient(135d'+'eg,\x20#f9731'+'6\x2050%,\x20#ea'+'580c\x20100%)'+';\x20\x0a}\x0a.btn-'+'copy\x20{\x20bac'+'kground:\x20l'+'inear-grad'+'ient(135de'+'g,\x20#8b5cf6'+'\x200%,\x20#7c3a'+'ed\x20100%);\x20'+'}\x0a.fragmen'+'t-section\x20'+'{\x20backgrou'+'nd:\x20#1e3a8'+'a;\x20padding'+':\x2015px;\x20bo'+'rder-radiu'+'s:\x2010px;\x20m'+'argin-top:'+'\x2015px;\x20}\x0a.'+'fragment-t'+'oggle\x20{\x20di'+'splay:\x20fle'+'x;\x20align-i'+'tems:\x20cent'+'er;\x20margin'+'-bottom:\x201')+('5px;\x20}\x0a.fr'+'agment-tog'+'gle\x20label\x20'+'{\x20margin:\x20'+'0\x200\x200\x2015px'+';\x20font-wei'+'ght:\x20600;\x20'+'}\x0a.switch\x20'+'{\x20position'+':\x20relative'+';\x20display:'+'\x20inline-bl'+'ock;\x20width'+':\x2060px;\x20he'+'ight:\x2030px'+';\x20}\x0a.switc'+'h\x20input\x20{\x20'+'opacity:\x200'+';\x20width:\x200'+';\x20height:\x20'+'0;\x20}\x0a.slid'+'er\x20{\x20posit'+'ion:\x20absol'+'ute;\x20curso'+'r:\x20pointer'+';\x20top:\x200;\x20'+'left:\x200;\x20r'+'ight:\x200;\x20b'+'ottom:\x200;\x20'+'background'+'-color:\x20#4'+'a5568;\x20tra'+'nsition:\x20.'+'4s;\x20border'+'-radius:\x203'+'4px;\x20}\x0a.sl'+'ider:befor'+'e\x20{\x20positi'+'on:\x20absolu'+'te;\x20conten'+'t:\x20\x22\x22;\x20hei'+'ght:\x2022px;'+'\x20width:\x2022'+'px;\x20left:\x20'+'4px;\x20botto'+'m:\x204px;\x20ba'+'ckground-c'+'olor:\x20whit'+'e;\x20transit'+'ion:\x20.4s;\x20'+'border-rad'+'ius:\x2050%;\x20'+'}\x0ainput:ch'+'ecked\x20+\x20.s'+'lider\x20{\x20ba'+'ckground-c'+'olor:\x20#219'+'6F3;\x20}\x0ainp'+'ut:checked'+'\x20+\x20.slider'+':before\x20{\x20'+'transform:'+'\x20translate'+'X(30px);\x20}'+'\x0atextarea\x20'+'{\x20height:\x20'+'120px;\x20res'+'ize:\x20verti'+'cal;\x20}\x0afoo'+'ter\x20{\x20text'+'-align:\x20ce'+'nter;\x20marg'+'in-top:\x2030'+'px;\x20opacit'+'y:\x200.7;\x20fo'+'nt-size:\x201'+'4px;\x20}\x0a.al'+'ert\x20{\x20posi'+'tion:\x20fixe'+'d;\x20top:\x2020'+'px;\x20right:'+'\x2020px;\x20pad'+'ding:\x2015px'+'\x2025px;\x20bac'+'kground:\x20#'+'22c55e;\x20co'+'lor:\x20white'+';\x20border-r'+'adius:\x208px'+';\x20box-shad'+'ow:\x200\x204px\x20'+'15px\x20rgba('+'0,0,0,0.2)'+';\x20z-index:'+'\x201000;\x20opa'+'city:\x200;\x20t'+'ransform:\x20'+'translateY'+'(-20px);\x20t'+'ransition:')+('\x20all\x200.3s\x20'+'ease;\x20}\x0a.a'+'lert.show\x20'+'{\x20opacity:'+'\x201;\x20transf'+'orm:\x20trans'+'lateY(0);\x20'+'}\x0a.alert.e'+'rror\x20{\x20bac'+'kground:\x20#'+'ef4444;\x20}\x0a'+'.grid\x20{\x20di'+'splay:\x20gri'+'d;\x20grid-te'+'mplate-col'+'umns:\x201fr\x20'+'1fr;\x20gap:\x20'+'15px;\x20}\x0a@m'+'edia\x20(max-'+'width:\x20768'+'px)\x20{\x0a\x20\x20\x20\x20'+'.grid\x20{\x20gr'+'id-templat'+'e-columns:'+'\x201fr;\x20}\x0a\x20\x20'+'\x20\x20.contain'+'er\x20{\x20paddi'+'ng:\x2015px;\x20'+'}\x0a\x20\x20\x20\x20.hea'+'der\x20{\x20padd'+'ing:\x2020px;'+'\x20}\x0a\x20\x20\x20\x20.ca'+'rd\x20{\x20paddi'+'ng:\x2020px;\x20'+'}\x0a}\x0a</styl'+'e>\x0a</head>'+'\x0a<body>\x0a<d'+'iv\x20class=\x22'+'container\x22'+'>\x0a<div\x20cla'+'ss=\x22header'+'\x22>\x0a<h1>ARI'+'STA\x20Config'+'\x20Generator'+'</h1>\x0a<p>G'+'enerate\x20an'+'d\x20customiz'+'e\x20VLESS\x20co'+'nfiguratio'+'ns</p>\x0a</d'+'iv>\x0a<div\x20s'+'tyle=\x22\x0a\x20\x20\x20'+'\x20backgroun'+'d:\x20linear-'+'gradient(1'+'35deg,\x20rgb'+'a(138,\x2043,'+'\x20226,\x200.1)'+',\x20rgba(218'+',\x20112,\x20214'+',\x200.1));\x0a\x20'+'\x20\x20\x20backdro'+'p-filter:\x20'+'blur(10px)'+';\x0a\x20\x20\x20\x20padd'+'ing:\x2015px\x20'+'20px;\x0a\x20\x20\x20\x20'+'border-rad'+'ius:\x2012px;'+'\x0a\x20\x20\x20\x20margi'+'n:\x2020px\x20au'+'to;\x0a\x20\x20\x20\x20te'+'xt-align:\x20'+'center;\x0a\x20\x20'+'\x20\x20box-shad'+'ow:\x200\x204px\x20'+'20px\x20rgba('+'138,\x2043,\x202'+'26,\x200.2);\x0a'+'\x20\x20\x20\x20border'+':\x201px\x20soli'+'d\x20white;\x0a\x20'+'\x20\x20\x20max-wid'+'th:\x2090%;\x0a\x22'+'>\x0a\x20\x20\x20\x20<div'+'\x20style=\x22\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20dis'+'play:\x20flex'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'justify-co'+'ntent:\x20cen'+'ter;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20gap:\x2025'+'px;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20flex-wra'+'p:\x20wrap;\x0a\x20'+'\x20\x20\x20\x22>\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20<a\x20hre'+'f=\x22https:/'+'/t.me/aris')+('taproject\x22'+'\x20target=\x22_'+'blank\x22\x20sty'+'le=\x22\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20dis'+'play:\x20flex'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20align-'+'items:\x20cen'+'ter;\x20\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20ga'+'p:\x208px;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'padding:\x201'+'0px\x2020px;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20backgrou'+'nd:\x20linear'+'-gradient('+'135deg,\x20rg'+'ba(0,\x20136,'+'\x20204,\x200.2)'+',\x20rgba(0,\x20'+'119,\x20181,\x20'+'0.3));\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20c'+'olor:\x20whit'+'e;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20text-'+'decoration'+':\x20none;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'border-rad'+'ius:\x208px;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20transiti'+'on:\x20all\x200.'+'3s\x20ease;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20border:\x201'+'px\x20solid\x20r'+'gba(0,\x20136'+',\x20204,\x200.3'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20font-'+'weight:\x2060'+'0;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x22\x20onmouse'+'over=\x22this'+'.style.tra'+'nsform=\x27tr'+'anslateY(-'+'2px)\x27;this'+'.style.box'+'Shadow=\x270\x20'+'6px\x2015px\x20r'+'gba(0,136,'+'204,0.3)\x27;'+'\x22\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20onmous'+'eout=\x22this'+'.style.tra'+'nsform=\x27tr'+'anslateY(0'+')\x27;this.st'+'yle.boxSha'+'dow=\x27none\x27'+';\x22>\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20<svg'+'\x20xmlns=\x22ht'+'tp://www.w'+'3.org/2000'+'/svg\x22\x20widt'+'h=\x2218\x22\x20hei'+'ght=\x2218\x22\x20f'+'ill=\x22curre'+'ntColor\x22\x20v'+'iewBox=\x220\x20'+'0\x2016\x2016\x22>\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20<pat'+'h\x20d=\x22M16\x208'+'A8\x208\x200\x201\x201'+'\x200\x208a8\x208\x200'+'\x200\x201\x2016\x200z'+'M8.287\x205.9'+'06c-.778.3'+'24-2.334.9'+'94-4.666\x202'+'.01-.378.1'+'5-.577.298'+'-.595.442-'+'.03.243.27'+'5.339.69.4'+'7l.175.055'+'c.408.133.'+'958.288\x201.'+'243.294.26'+'.006.549-.'+'1.868-.32\x20')+('2.179-1.47'+'1\x203.304-2.'+'214\x203.374-'+'2.23.05-.0'+'12.12-.026'+'.166.016.0'+'47.041.042'+'.12.037.14'+'1-.03.129-'+'1.227\x201.24'+'1-1.846\x201.'+'817-.193.1'+'8-.33.307-'+'.358.336a8'+'.154\x208.154'+'\x200\x200\x201-.18'+'8.186c-.38'+'.366-.664.'+'64.015\x201.0'+'88.327.216'+'.589.393.8'+'5.571.284.'+'194.568.38'+'7.936.629.'+'093.06.183'+'.125.27.18'+'7.331.236.'+'63.448.997'+'.414.214-.'+'02.435-.22'+'.547-.82.2'+'65-1.417.7'+'86-4.486.9'+'06-5.751a1'+'.426\x201.426'+'\x200\x200\x200-.01'+'3-.315.337'+'.337\x200\x200\x200'+'-.114-.217'+'.526.526\x200'+'\x200\x200-.31-.'+'093c-.3.00'+'5-.763.166'+'-2.984\x201.0'+'9z\x22/>\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20</'+'svg>\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20Ari'+'sta\x20Telegr'+'am\x20Channel'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20<'+'/a>\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20<a\x20href=\x22'+'https://ar'+'ista-proxy'+'.pages.dev'+'\x22\x20target=\x22'+'_blank\x22\x20st'+'yle=\x22\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20di'+'splay:\x20fle'+'x;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20align'+'-items:\x20ce'+'nter;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20ga'+'p:\x208px;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'padding:\x201'+'0px\x2020px;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20backgrou'+'nd:\x20linear'+'-gradient('+'135deg,\x20rg'+'ba(74,\x20144'+',\x20226,\x200.2'+'),\x20rgba(66'+',\x20133,\x20214'+',\x200.3));\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20color:\x20wh'+'ite;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20tex'+'t-decorati'+'on:\x20none;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20border-r'+'adius:\x208px'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20transi'+'tion:\x20all\x20'+'0.3s\x20ease;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20border:'+'\x201px\x20solid'+'\x20rgba(74,\x20'+'144,\x20226,\x20'+'0.3);\x0a\x20\x20\x20\x20')+('\x20\x20\x20\x20\x20\x20\x20\x20fo'+'nt-weight:'+'\x20600;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x22\x20onmo'+'useover=\x22t'+'his.style.'+'transform='+'\x27translate'+'Y(-2px)\x27;t'+'his.style.'+'boxShadow='+'\x270\x206px\x2015p'+'x\x20rgba(74,'+'144,226,0.'+'3)\x27;\x22\x20\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20on'+'mouseout=\x22'+'this.style'+'.transform'+'=\x27translat'+'eY(0)\x27;thi'+'s.style.bo'+'xShadow=\x27n'+'one\x27;\x22>\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'<svg\x20xmlns'+'=\x22http://w'+'ww.w3.org/'+'2000/svg\x22\x20'+'width=\x2218\x22'+'\x20height=\x221'+'8\x22\x20fill=\x22c'+'urrentColo'+'r\x22\x20viewBox'+'=\x220\x200\x2016\x201'+'6\x22>\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'<path\x20d=\x22M'+'0\x208a8\x208\x200\x20'+'1\x201\x2016\x200A8'+'\x208\x200\x200\x201\x200'+'\x208zm7.5-6.'+'923c-.67.2'+'04-1.335.8'+'2-1.887\x201.'+'855A7.97\x207'+'.97\x200\x200\x200\x20'+'5.145\x204H7.'+'5V1.077zM4'+'.09\x204a9.26'+'7\x209.267\x200\x20'+'0\x201\x20.64-1.'+'539\x206.7\x206.'+'7\x200\x200\x201\x20.5'+'97-.933A7.'+'025\x207.025\x20'+'0\x200\x200\x202.25'+'5\x204H4.09zm'+'-.582\x203.5c'+'.03-.877.1'+'38-1.718.3'+'12-2.5H1.6'+'74a6.958\x206'+'.958\x200\x200\x200'+'-.656\x202.5h'+'2.49zM4.84'+'7\x205a12.5\x201'+'2.5\x200\x200\x200-'+'.338\x202.5H7'+'.5V5H4.847'+'zM8.5\x205v2.'+'5h2.99a12.'+'495\x2012.495'+'\x200\x200\x200-.33'+'7-2.5H8.5z'+'M4.51\x208.5a'+'12.5\x2012.5\x20'+'0\x200\x200\x20.337'+'\x202.5H7.5V8'+'.5H4.51zm3'+'.99\x200V11h2'+'.653c.187-'+'.765.306-1'+'.608.338-2'+'.5H8.5zM5.'+'145\x2012c.13'+'8.386.295.'+'744.468\x201.'+'068.552\x201.'+'035\x201.218\x20'+'1.65\x201.887'+'\x201.855V12H'+'5.145zm.18'+'2\x202.472a6.'+'696\x206.696\x20'+'0\x200\x201-.597'+'-.933A9.26'+'8\x209.268\x200\x20'+'0\x201\x204.09\x201'+'2H2.255a7.')+('024\x207.024\x20'+'0\x200\x200\x203.07'+'2\x202.472zM3'+'.82\x2011a13.'+'652\x2013.652'+'\x200\x200\x201-.31'+'2-2.5h-2.4'+'9c.062.97.'+'291\x201.87.6'+'56\x202.5H3.8'+'2zm6.853\x203'+'.472A7.024'+'\x207.024\x200\x200'+'\x200\x2013.745\x20'+'12H11.91a9'+'.27\x209.27\x200'+'\x200\x201-.64\x201'+'.539\x206.688'+'\x206.688\x200\x200'+'\x201-.597.93'+'3zM8.5\x2012v'+'2.923c.67-'+'.204\x201.335'+'-.82\x201.887'+'-1.855.173'+'-.324.33-.'+'682.468-1.'+'068H8.5zm3'+'.680-1h2.1'+'46c.365-.6'+'3.594-1.53'+'.656-2.5h-'+'2.49a13.65'+'\x2013.65\x200\x200'+'\x201-.312\x202.'+'5zm2.802-3'+'.5a6.959\x206'+'.959\x200\x200\x200'+'-.656-2.5H'+'12.18c.174'+'.782.282\x201'+'.623.312\x202'+'.5h2.49zM1'+'1.27\x202.461'+'c.247.35.4'+'62.739.64\x20'+'1.539h1.83'+'5a7.024\x207.'+'024\x200\x200\x200-'+'3.072-2.47'+'2c.218.284'+'.418.598.5'+'97.933zM10'+'.855\x204a7.9'+'66\x207.966\x200'+'\x200\x200-.468-'+'1.068C9.83'+'5\x201.897\x209.'+'17\x201.282\x208'+'.5\x201.077V4'+'h2.355z\x22/>'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20</svg>\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20Telegram'+'\x20Proxy\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20</a>\x0a'+'\x20\x20\x20\x20</div>'+'\x0a</div>\x0a<d'+'iv\x20class=\x22'+'card\x22>\x0a<di'+'v\x20class=\x22g'+'rid\x22>\x0a<div'+'>\x0a<label>C'+'onfig\x20Limi'+'t</label>\x0a'+'<select\x20id'+'=\x22limit\x22>\x0a'+'<option\x20va'+'lue=\x22all\x22>'+'All\x20Config'+'s</option>'+'\x0a<option\x20v'+'alue=\x2220\x22>'+'20\x20Configs'+'</option>\x0a'+'<option\x20va'+'lue=\x2240\x22>4'+'0\x20Configs<'+'/option>\x0a<'+'option\x20val'+'ue=\x2260\x22>60'+'\x20Configs</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22100\x22>10'+'0\x20Configs<'+'/option>\x0a<'+'/select>\x0a<'+'div\x20class=')+('\x22help-text'+'\x22>Select\x20n'+'umber\x20of\x20c'+'onfigurati'+'ons\x20to\x20gen'+'erate\x20(pri'+'ority\x20give'+'n\x20to\x20ports'+'\x202096,\x20443'+',\x208443,\x2080'+'80)</div>\x0a'+'</div>\x0a<di'+'v>\x0a<label>'+'Remote\x20DNS'+'</label>\x0a<'+'input\x20id=\x22'+'dns\x22\x20place'+'holder=\x22e.'+'g.,\x208.8.8.'+'8,1.1.1.1,'+'https://dn'+'s.google/d'+'ns-query\x22>'+'\x0a<div\x20clas'+'s=\x22help-te'+'xt\x22>Enter\x20'+'DNS\x20server'+'s\x20or\x20DoH\x20U'+'RLs\x20(comma'+'-separated'+',\x20e.g.,\x208.'+'8.8.8,1.1.'+'1.1\x20or\x20htt'+'ps://dns.g'+'oogle/dns-'+'query)</di'+'v>\x0a</div>\x0a'+'</div>\x0a\x0a<d'+'iv\x20class=\x22'+'grid\x22>\x0a<di'+'v>\x0a<label>'+'Direct\x20DNS'+'</label>\x0a<'+'input\x20id=\x22'+'direct\x22\x20pl'+'aceholder='+'\x22e.g.,\x20127'+'.0.0.1,8.8'+'.8.8\x22>\x0a<di'+'v\x20class=\x22h'+'elp-text\x22>'+'Enter\x20DNS\x20'+'servers\x20fo'+'r\x20direct\x20c'+'onnections'+'\x20(comma-se'+'parated,\x20e'+'.g.,\x20127.0'+'.0.1,8.8.8'+'.8)</div>\x0a'+'</div>\x0a<di'+'v>\x0a<label>'+'Clean\x20IP</'+'label>\x0a<in'+'put\x20id=\x22cl'+'eanip\x22\x20pla'+'ceholder=\x22'+'e.g.,\x208.21'+'9.190.62,1'+'.1.1.1\x22>\x0a<'+'div\x20class='+'\x22help-text'+'\x22>Enter\x20cl'+'ean\x20IP\x20add'+'resses\x20for'+'\x20bypass\x20(c'+'omma-separ'+'ated,\x20e.g.'+',\x208.219.19'+'0.62,1.1.1'+'.1)</div>\x0a'+'</div>\x0a</d'+'iv>\x0a\x0a<div\x20'+'class=\x22gri'+'d\x22>\x0a<div>\x0a'+'<label>Dom'+'ain</label'+'>\x0a<input\x20i'+'d=\x22domain\x22'+'\x20placehold'+'er=\x22e.g.,\x20'+'zula.ir,ex'+'ample.com\x22'+'>\x0a<div\x20cla'+'ss=\x22help-t'+'ext\x22>Enter'+'\x20domains\x20f'+'or\x20routing'+'\x20(comma-se'+'parated,\x20e')+('.g.,\x20zula.'+'ir,example'+'.com)</div'+'>\x0a</div>\x0a<'+'div>\x0a<labe'+'l>SNI</lab'+'el>\x0a<input'+'\x20id=\x22sni\x22\x20'+'placeholde'+'r=\x22e.g.,\x20e'+'xample.com'+',cloudflar'+'e.com\x22>\x0a<d'+'iv\x20class=\x22'+'help-text\x22'+'>Enter\x20Ser'+'ver\x20Name\x20I'+'ndication\x20'+'for\x20TLS\x20(c'+'omma-separ'+'ated,\x20e.g.'+',\x20example.'+'com,cloudf'+'lare.com)<'+'/div>\x0a</di'+'v>\x0a</div>\x0a'+'\x0a<div\x20clas'+'s=\x22grid\x22>\x0a'+'<div>\x0a<lab'+'el>ALPN</l'+'abel>\x0a<sel'+'ect\x20id=\x22al'+'pn\x22>\x0a<opti'+'on\x20value=\x22'+'none\x22>None'+'</option>\x0a'+'<option\x20va'+'lue=\x22h2\x22>H'+'TTP/2</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'http/1.1\x22>'+'HTTP/1.1</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22h2,http'+'/1.1\x22>HTTP'+'/2\x20+\x20HTTP/'+'1.1</optio'+'n>\x0a<option'+'\x20value=\x22h3'+'\x22>HTTP/3</'+'option>\x0a</'+'select>\x0a<d'+'iv\x20class=\x22'+'help-text\x22'+'>Applicati'+'on-Layer\x20P'+'rotocol\x20Ne'+'gotiation<'+'/div>\x0a</di'+'v>\x0a<div>\x0a<'+'label>Fing'+'erprint</l'+'abel>\x0a<sel'+'ect\x20id=\x22fi'+'ngerprint\x22'+'>\x0a<option\x20'+'value=\x22non'+'e\x22>None</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22chrome\x22>'+'Chrome</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22firefox\x22>'+'Firefox</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22safari\x22>'+'Safari</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22ios\x22>iOS<'+'/option>\x0a<'+'option\x20val'+'ue=\x22androi'+'d\x22>Android'+'</option>\x0a'+'<option\x20va'+'lue=\x22edge\x22'+'>Edge</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'360\x22>360</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22qq\x22>QQ<'+'/option>\x0a<')+('option\x20val'+'ue=\x22random'+'\x22>Random</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22randomi'+'zed\x22>Rando'+'mized</opt'+'ion>\x0a</sel'+'ect>\x0a<div\x20'+'class=\x22hel'+'p-text\x22>TL'+'S\x20client\x20f'+'ingerprint'+'</div>\x0a</d'+'iv>\x0a</div>'+'\x0a\x0a<div\x20cla'+'ss=\x22grid\x22>'+'\x0a<div>\x0a<la'+'bel>IP\x20Ver'+'sion</labe'+'l>\x0a<select'+'\x20id=\x22ipver'+'\x22>\x0a<option'+'\x20value=\x22no'+'ne\x22>None</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22ipv4\x22>I'+'Pv4</optio'+'n>\x0a<option'+'\x20value=\x22ip'+'v6\x22>IPv6</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22auto\x22>A'+'uto</optio'+'n>\x0a</selec'+'t>\x0a</div>\x0a'+'<div>\x0a<lab'+'el>Network'+'</label>\x0a<'+'select\x20id='+'\x22network\x22>'+'\x0a<option\x20v'+'alue=\x22none'+'\x22>None</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22tcp\x22>TCP<'+'/option>\x0a<'+'option\x20val'+'ue=\x22ws\x22>We'+'bSocket</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22h2\x22>HTTP'+'/2</option'+'>\x0a<option\x20'+'value=\x22grp'+'c\x22>gRPC</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22quic\x22>QU'+'IC</option'+'>\x0a<option\x20'+'value=\x22kcp'+'\x22>KCP</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'http\x22>HTTP'+'</option>\x0a'+'</select>\x0a'+'</div>\x0a</d'+'iv>\x0a\x0a<div\x20'+'class=\x22gri'+'d\x22>\x0a<div>\x0a'+'<label>TLS'+'</label>\x0a<'+'select\x20id='+'\x22tls\x22>\x0a<op'+'tion\x20value'+'=\x22none\x22>No'+'ne</option'+'>\x0a<option\x20'+'value=\x22ena'+'bled\x22>Enab'+'led</optio'+'n>\x0a<option'+'\x20value=\x22di'+'sabled\x22>Di'+'sabled</op'+'tion>\x0a</se'+'lect>\x0a</di'+'v>\x0a<div>\x0a<'+'label>UDP<'+'/label>\x0a<s'+'elect\x20id=\x22'+'udp\x22>\x0a<opt'+'ion\x20value=')+('\x22none\x22>Non'+'e</option>'+'\x0a<option\x20v'+'alue=\x22enab'+'led\x22>Enabl'+'ed</option'+'>\x0a<option\x20'+'value=\x22dis'+'abled\x22>Dis'+'abled</opt'+'ion>\x0a</sel'+'ect>\x0a</div'+'>\x0a</div>\x0a\x0a'+'<div\x20class'+'=\x22fragment'+'-section\x22>'+'\x0a<div\x20clas'+'s=\x22fragmen'+'t-toggle\x22>'+'\x0a<label\x20cl'+'ass=\x22switc'+'h\x22>\x0a<input'+'\x20type=\x22che'+'ckbox\x22\x20id='+'\x22fragment_'+'enabled\x22>\x0a'+'<span\x20clas'+'s=\x22slider\x22'+'></span>\x0a<'+'/label>\x0a<l'+'abel>Enabl'+'e\x20Fragment'+'</label>\x0a<'+'/div>\x0a\x0a<di'+'v\x20id=\x22frag'+'ment_setti'+'ngs\x22>\x0a<div'+'\x20class=\x22gr'+'id\x22>\x0a<div>'+'\x0a<label>Pa'+'ckets</lab'+'el>\x0a<input'+'\x20id=\x22frag_'+'packets\x22\x20v'+'alue=\x222-8\x22'+'>\x0a<div\x20cla'+'ss=\x22help-t'+'ext\x22>Packe'+'t\x20fragment'+'ation\x20rang'+'e</div>\x0a</'+'div>\x0a<div>'+'\x0a<label>Le'+'ngth</labe'+'l>\x0a<input\x20'+'id=\x22frag_l'+'ength\x22\x20val'+'ue=\x22100-30'+'0\x22>\x0a<div\x20c'+'lass=\x22help'+'-text\x22>Fra'+'gment\x20leng'+'th\x20range</'+'div>\x0a</div'+'>\x0a</div>\x0a\x0a'+'<div\x20class'+'=\x22grid\x22>\x0a<'+'div>\x0a<labe'+'l>Interval'+'</label>\x0a<'+'input\x20id=\x22'+'frag_inter'+'val\x22\x20value'+'=\x2210-30\x22>\x0a'+'<div\x20class'+'=\x22help-tex'+'t\x22>Fragmen'+'t\x20interval'+'\x20range</di'+'v>\x0a</div>\x0a'+'<div>\x0a<lab'+'el>Sleep</'+'label>\x0a<in'+'put\x20id=\x22fr'+'ag_sleep\x22\x20'+'value=\x2250\x22'+'>\x0a<div\x20cla'+'ss=\x22help-t'+'ext\x22>Sleep'+'\x20time\x20betw'+'een\x20fragme'+'nts\x20(ms)</'+'div>\x0a</div'+'>\x0a</div>\x0a<'+'/div>\x0a</di'+'v>\x0a\x0a<butto'+'n\x20class=\x22b'+'tn-save\x22\x20o'+'nclick=\x22sa'+'veSettings')+('()\x22>Save\x20S'+'ettings</b'+'utton>\x0a<bu'+'tton\x20class'+'=\x22btn-rese'+'t\x22\x20onclick'+'=\x22resetSet'+'tings()\x22>R'+'eset\x20Setti'+'ngs</butto'+'n>\x0a\x0a<label'+'>Subscribe'+'\x20URL\x20(V2Ra'+'y)</label>'+'\x0a<input\x20id'+'=\x22subscrib'+'e_v2ray\x22\x20r'+'eadonly>\x0a<'+'button\x20cla'+'ss=\x22btn-co'+'py\x22\x20onclic'+'k=\x22copyToC'+'lipboard(\x27'+'subscribe_'+'v2ray\x27)\x22>C'+'opy\x20V2Ray\x20'+'Subscribe<'+'/button>\x0a\x0a'+'<label>Sub'+'scribe\x20URL'+'\x20(ClashMet'+'a)</label>'+'\x0a<input\x20id'+'=\x22subscrib'+'e_clash\x22\x20r'+'eadonly>\x0a<'+'button\x20cla'+'ss=\x22btn-co'+'py\x22\x20onclic'+'k=\x22copyToC'+'lipboard(\x27'+'subscribe_'+'clash\x27)\x22>C'+'opy\x20ClashM'+'eta\x20Subscr'+'ibe</butto'+'n>\x0a\x0a<label'+'>Subscribe'+'\x20URL\x20(Sing'+'Box)</labe'+'l>\x0a<input\x20'+'id=\x22subscr'+'ibe_singbo'+'x\x22\x20readonl'+'y>\x0a<button'+'\x20class=\x22bt'+'n-copy\x22\x20on'+'click=\x22cop'+'yToClipboa'+'rd(\x27subscr'+'ibe_singbo'+'x\x27)\x22>Copy\x20'+'SingBox\x20Su'+'bscribe</b'+'utton>\x0a</d'+'iv>\x0a<foote'+'r>V\x201.3.7<'+'/footer>\x0a<'+'div\x20id=\x22al'+'ert\x22\x20class'+'=\x22alert\x22><'+'/div>\x0a</di'+'v>\x0a<script'+'>\x0afunction'+'\x20showAlert'+'(message,\x20'+'isError\x20=\x20'+'false)\x20{\x0a\x20'+'\x20\x20\x20const\x20a'+'lert\x20=\x20doc'+'ument.getE'+'lementById'+'(\x27alert\x27);'+'\x0a\x20\x20\x20\x20alert'+'.textConte'+'nt\x20=\x20messa'+'ge;\x0a\x20\x20\x20\x20al'+'ert.classN'+'ame\x20=\x20isEr'+'ror\x20?\x20\x27ale'+'rt\x20error\x27\x20'+':\x20\x27alert\x27;'+'\x0a\x20\x20\x20\x20alert'+'.classList'+'.add(\x27show'+'\x27);\x0a\x20\x20\x20\x20\x0a\x20'+'\x20\x20\x20setTime'+'out(()\x20=>\x20'+'{\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'alert.clas')+('sList.remo'+'ve(\x27show\x27)'+';\x0a\x20\x20\x20\x20},\x203'+'000);\x0a}\x0a\x0af'+'unction\x20to'+'ggleFragme'+'ntSettings'+'()\x20{\x0a\x20\x20\x20\x20c'+'onst\x20enabl'+'ed\x20=\x20docum'+'ent.getEle'+'mentById(\x27'+'fragment_e'+'nabled\x27).c'+'hecked;\x0a\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27fra'+'gment_sett'+'ings\x27).sty'+'le.display'+'\x20=\x20enabled'+'\x20?\x20\x27grid\x27\x20'+':\x20\x27none\x27;\x0a'+'}\x0a\x0aasync\x20f'+'unction\x20sa'+'veSettings'+'(){\x0a\x20\x20\x20\x20tr'+'y\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20const\x20da'+'ta\x20=\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20l'+'imit:\x20docu'+'ment.getEl'+'ementById('+'\x27limit\x27).v'+'alue,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20dn'+'s:\x20documen'+'t.getEleme'+'ntById(\x27dn'+'s\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20direct:'+'\x20document.'+'getElement'+'ById(\x27dire'+'ct\x27).value'+',\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20cleani'+'p:\x20documen'+'t.getEleme'+'ntById(\x27cl'+'eanip\x27).va'+'lue,\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20dom'+'ain:\x20docum'+'ent.getEle'+'mentById(\x27'+'domain\x27).v'+'alue,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20sn'+'i:\x20documen'+'t.getEleme'+'ntById(\x27sn'+'i\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20alpn:\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27alpn\x27)'+'.value,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'fingerprin'+'t:\x20documen'+'t.getEleme'+'ntById(\x27fi'+'ngerprint\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20ipver:\x20do'+'cument.get'+'ElementByI'+'d(\x27ipver\x27)'+'.value,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'network:\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27networ'+'k\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20tls:\x20do'+'cument.get'+'ElementByI'+'d(\x27tls\x27).v'+'alue,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20ud'+'p:\x20documen'+'t.getEleme')+('ntById(\x27ud'+'p\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20fragmen'+'t:\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20enabled:\x20'+'document.g'+'etElementB'+'yId(\x27fragm'+'ent_enable'+'d\x27).checke'+'d,\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20p'+'ackets:\x20do'+'cument.get'+'ElementByI'+'d(\x27frag_pa'+'ckets\x27).va'+'lue,\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20length:\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_l'+'ength\x27).va'+'lue,\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20interval:'+'\x20document.'+'getElement'+'ById(\x27frag'+'_interval\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20sleep'+':\x20document'+'.getElemen'+'tById(\x27fra'+'g_sleep\x27).'+'value,\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20}'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20}'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20c'+'onst\x20respo'+'nse\x20=\x20awai'+'t\x20fetch(\x27/'+'api/settin'+'gs\x27,\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20m'+'ethod:\x20\x27PO'+'ST\x27,\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20hea'+'ders:\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x27Conte'+'nt-Type\x27:\x20'+'\x27applicati'+'on/json\x27,\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20},\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20bod'+'y:\x20JSON.st'+'ringify(da'+'ta)\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20});\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20if\x20(res'+'ponse.ok)\x20'+'{\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20showAl'+'ert(\x27Setti'+'ngs\x20saved\x20'+'successful'+'ly!\x27);\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20g'+'enerateSub'+'scribe();\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20}\x20'+'else\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20s'+'howAlert(\x27'+'Error\x20savi'+'ng\x20setting'+'s!\x27,\x20true)'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'}\x0a\x20\x20\x20\x20}\x20ca'+'tch\x20(error'+')\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20showAler'+'t(\x27Error\x20s'+'aving\x20sett'+'ings!\x27,\x20tr'+'ue);\x0a\x20\x20\x20\x20}'+'\x0a}\x0a\x0aasync\x20'+'function\x20r'+'esetSettin'+'gs()\x20{\x0a\x20\x20\x20'+'\x20const\x20ale')+('rtOverlay\x20'+'=\x20document'+'.createEle'+'ment(\x27div\x27'+');\x0a\x20\x20\x20\x20ale'+'rtOverlay.'+'style.posi'+'tion\x20=\x20\x27fi'+'xed\x27;\x0a\x20\x20\x20\x20'+'alertOverl'+'ay.style.t'+'op\x20=\x20\x270\x27;\x0a'+'\x20\x20\x20\x20alertO'+'verlay.sty'+'le.left\x20=\x20'+'\x270\x27;\x0a\x20\x20\x20\x20a'+'lertOverla'+'y.style.wi'+'dth\x20=\x20\x27100'+'%\x27;\x0a\x20\x20\x20\x20al'+'ertOverlay'+'.style.hei'+'ght\x20=\x20\x27100'+'%\x27;\x0a\x20\x20\x20\x20al'+'ertOverlay'+'.style.bac'+'kgroundCol'+'or\x20=\x20\x27rgba'+'(0,\x200,\x200,\x20'+'0.7)\x27;\x0a\x20\x20\x20'+'\x20alertOver'+'lay.style.'+'display\x20=\x20'+'\x27flex\x27;\x0a\x20\x20'+'\x20\x20alertOve'+'rlay.style'+'.justifyCo'+'ntent\x20=\x20\x27c'+'enter\x27;\x0a\x20\x20'+'\x20\x20alertOve'+'rlay.style'+'.alignItem'+'s\x20=\x20\x27cente'+'r\x27;\x0a\x20\x20\x20\x20al'+'ertOverlay'+'.style.zIn'+'dex\x20=\x20\x27100'+'00\x27;\x0a\x20\x20\x20\x20\x0a'+'\x20\x20\x20\x20const\x20'+'alertBox\x20='+'\x20document.'+'createElem'+'ent(\x27div\x27)'+';\x0a\x20\x20\x20\x20aler'+'tBox.style'+'.backgroun'+'d\x20=\x20\x27linea'+'r-gradient'+'(135deg,\x20#'+'f97316\x200%,'+'\x20#ea580c\x201'+'00%)\x27;\x0a\x20\x20\x20'+'\x20alertBox.'+'style.padd'+'ing\x20=\x20\x2725p'+'x\x27;\x0a\x20\x20\x20\x20al'+'ertBox.sty'+'le.borderR'+'adius\x20=\x20\x271'+'5px\x27;\x0a\x20\x20\x20\x20'+'alertBox.s'+'tyle.boxSh'+'adow\x20=\x20\x270\x20'+'4px\x2020px\x20r'+'gba(0,\x200,\x20'+'0,\x200.3)\x27;\x0a'+'\x20\x20\x20\x20alertB'+'ox.style.c'+'olor\x20=\x20\x27wh'+'ite\x27;\x0a\x20\x20\x20\x20'+'alertBox.s'+'tyle.textA'+'lign\x20=\x20\x27ce'+'nter\x27;\x0a\x20\x20\x20'+'\x20alertBox.'+'style.maxW'+'idth\x20=\x20\x2740'+'0px\x27;\x0a\x20\x20\x20\x20'+'alertBox.s'+'tyle.width'+'\x20=\x20\x2790%\x27;\x0a'+'\x20\x20\x20\x20\x0a\x20\x20\x20\x20c'+'onst\x20messa'+'ge\x20=\x20docum'+'ent.create'+'Element(\x27p'+'\x27);\x0a\x20\x20\x20\x20me'+'ssage.text'+'Content\x20=\x20'+'\x27Are\x20you\x20s')+('ure\x20you\x20wa'+'nt\x20to\x20rese'+'t\x20all\x20sett'+'ings?\x27;\x0a\x20\x20'+'\x20\x20message.'+'style.marg'+'inBottom\x20='+'\x20\x2720px\x27;\x0a\x20'+'\x20\x20\x20message'+'.style.fon'+'tSize\x20=\x20\x271'+'6px\x27;\x0a\x20\x20\x20\x20'+'message.st'+'yle.fontWe'+'ight\x20=\x20\x2760'+'0\x27;\x0a\x20\x20\x20\x20\x0a\x20'+'\x20\x20\x20const\x20b'+'uttonConta'+'iner\x20=\x20doc'+'ument.crea'+'teElement('+'\x27div\x27);\x0a\x20\x20'+'\x20\x20buttonCo'+'ntainer.st'+'yle.displa'+'y\x20=\x20\x27flex\x27'+';\x0a\x20\x20\x20\x20butt'+'onContaine'+'r.style.ga'+'p\x20=\x20\x2715px\x27'+';\x0a\x20\x20\x20\x20butt'+'onContaine'+'r.style.ju'+'stifyConte'+'nt\x20=\x20\x27cent'+'er\x27;\x0a\x20\x20\x20\x20\x0a'+'\x20\x20\x20\x20const\x20'+'confirmBut'+'ton\x20=\x20docu'+'ment.creat'+'eElement(\x27'+'button\x27);\x0a'+'\x20\x20\x20\x20confir'+'mButton.te'+'xtContent\x20'+'=\x20\x27Yes\x27;\x0a\x20'+'\x20\x20\x20confirm'+'Button.sty'+'le.padding'+'\x20=\x20\x2710px\x202'+'0px\x27;\x0a\x20\x20\x20\x20'+'confirmBut'+'ton.style.'+'border\x20=\x20\x27'+'none\x27;\x0a\x20\x20\x20'+'\x20confirmBu'+'tton.style'+'.borderRad'+'ius\x20=\x20\x278px'+'\x27;\x0a\x20\x20\x20\x20con'+'firmButton'+'.style.bac'+'kground\x20=\x20'+'\x27linear-gr'+'adient(135'+'deg,\x20#ef44'+'44\x200%,\x20#dc'+'2626\x20100%)'+'\x27;\x0a\x20\x20\x20\x20con'+'firmButton'+'.style.col'+'or\x20=\x20\x27whit'+'e\x27;\x0a\x20\x20\x20\x20co'+'nfirmButto'+'n.style.cu'+'rsor\x20=\x20\x27po'+'inter\x27;\x0a\x20\x20'+'\x20\x20confirmB'+'utton.styl'+'e.fontWeig'+'ht\x20=\x20\x27600\x27'+';\x0a\x0a\x20\x20\x20\x20con'+'st\x20cancelB'+'utton\x20=\x20do'+'cument.cre'+'ateElement'+'(\x27button\x27)'+';\x0a\x20\x20\x20\x20canc'+'elButton.t'+'extContent'+'\x20=\x20\x27No\x27;\x0a\x20'+'\x20\x20\x20cancelB'+'utton.styl'+'e.padding\x20'+'=\x20\x2710px\x2020'+'px\x27;\x0a\x20\x20\x20\x20c'+'ancelButto'+'n.style.bo'+'rder\x20=\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20c')+('ancelButto'+'n.style.bo'+'rderRadius'+'\x20=\x20\x278px\x27;\x0a'+'\x20\x20\x20\x20cancel'+'Button.sty'+'le.backgro'+'und\x20=\x20\x27lin'+'ear-gradie'+'nt(135deg,'+'\x20#22c55e\x200'+'%,\x20#16a34a'+'\x20100%)\x27;\x0a\x20'+'\x20\x20\x20cancelB'+'utton.styl'+'e.color\x20=\x20'+'\x27white\x27;\x0a\x20'+'\x20\x20\x20cancelB'+'utton.styl'+'e.cursor\x20='+'\x20\x27pointer\x27'+';\x0a\x20\x20\x20\x20canc'+'elButton.s'+'tyle.fontW'+'eight\x20=\x20\x276'+'00\x27;\x0a\x20\x20\x20\x20\x0a'+'\x20\x20\x20\x20button'+'Container.'+'appendChil'+'d(confirmB'+'utton);\x0a\x20\x20'+'\x20\x20buttonCo'+'ntainer.ap'+'pendChild('+'cancelButt'+'on);\x0a\x20\x20\x20\x20a'+'lertBox.ap'+'pendChild('+'message);\x0a'+'\x20\x20\x20\x20alertB'+'ox.appendC'+'hild(butto'+'nContainer'+');\x0a\x20\x20\x20\x20ale'+'rtOverlay.'+'appendChil'+'d(alertBox'+');\x0a\x20\x20\x20\x20doc'+'ument.body'+'.appendChi'+'ld(alertOv'+'erlay);\x0a\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20ret'+'urn\x20new\x20Pr'+'omise((res'+'olve)\x20=>\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20c'+'onfirmButt'+'on.onclick'+'\x20=\x20()\x20=>\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.body.rem'+'oveChild(a'+'lertOverla'+'y);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20reso'+'lve(true);'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20}'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20c'+'ancelButto'+'n.onclick\x20'+'=\x20()\x20=>\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.body.remo'+'veChild(al'+'ertOverlay'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20resol'+'ve(false);'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20}'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20a'+'lertOverla'+'y.onclick\x20'+'=\x20(e)\x20=>\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20if\x20(e.t'+'arget\x20===\x20'+'alertOverl'+'ay)\x20{\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.body.remo'+'veChild(al'+'ertOverlay'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20r')+('esolve(fal'+'se);\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20}\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20};\x0a'+'\x20\x20\x20\x20}).the'+'n(async\x20(c'+'onfirmed)\x20'+'=>\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20if\x20(con'+'firmed)\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27lim'+'it\x27).value'+'\x20=\x20\x27all\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27dns'+'\x27).value\x20='+'\x20\x27\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27direct\x27)'+'.value\x20=\x20\x27'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'cleanip\x27).'+'value\x20=\x20\x27\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27d'+'omain\x27).va'+'lue\x20=\x20\x27\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27sni'+'\x27).value\x20='+'\x20\x27\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27alpn\x27).v'+'alue\x20=\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27fingerpr'+'int\x27).valu'+'e\x20=\x20\x27none\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27i'+'pver\x27).val'+'ue\x20=\x20\x27none'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'network\x27).'+'value\x20=\x20\x27n'+'one\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27tls\x27).v'+'alue\x20=\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27udp\x27).va'+'lue\x20=\x20\x27non'+'e\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27fragment_'+'enabled\x27).'+'checked\x20=\x20'+'false;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_p'+'ackets\x27).v'+'alue\x20=\x20\x272-'+'8\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27frag_leng')+('th\x27).value'+'\x20=\x20\x27100-30'+'0\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27frag_inte'+'rval\x27).val'+'ue\x20=\x20\x2710-3'+'0\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27frag_slee'+'p\x27).value\x20'+'=\x20\x2750\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20toggleF'+'ragmentSet'+'tings();\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20try\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20awai'+'t\x20fetch(\x27/'+'api/settin'+'gs\x27,\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20met'+'hod:\x20\x27POST'+'\x27,\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20headers'+':\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x27C'+'ontent-Typ'+'e\x27:\x20\x27appli'+'cation/jso'+'n\x27,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20},\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20bod'+'y:\x20JSON.st'+'ringify({}'+')\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20})'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20sh'+'owAlert(\x27S'+'ettings\x20re'+'set\x20succes'+'sfully!\x27);'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20gen'+'erateSubsc'+'ribe();\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'}\x20catch\x20(e'+'rror)\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20showAl'+'ert(\x27Error'+'\x20resetting'+'\x20settings!'+'\x27,\x20true);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20}\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20}\x20else\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20showAle'+'rt(\x27Reset\x20'+'cancelled\x27'+',\x20false);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20}\x0a'+'\x20\x20\x20\x20});\x0a}\x0a'+'\x0afunction\x20'+'generateSu'+'bscribe()\x20'+'{\x0a\x20\x20\x20\x20cons'+'t\x20baseUrl\x20'+'=\x20window.l'+'ocation.or'+'igin;\x0a\x20\x20\x20\x20'+'const\x20limi'+'t\x20=\x20docume'+'nt.getElem'+'entById(\x27l'+'imit\x27).val'+'ue;\x0a\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27subscri'+'be_v2ray\x27)'+'.value\x20=\x20b'+'aseUrl\x20+\x20\x27'+'/api/confi')+('gs?limit=\x27'+'\x20+\x20limit;\x0a'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27s'+'ubscribe_c'+'lash\x27).val'+'ue\x20=\x20baseU'+'rl\x20+\x20\x27/api'+'/configs?f'+'ormat=clas'+'h&limit=\x27\x20'+'+\x20limit;\x0a\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27su'+'bscribe_si'+'ngbox\x27).va'+'lue\x20=\x20base'+'Url\x20+\x20\x27/ap'+'i/configs?'+'format=sin'+'gbox&limit'+'=\x27\x20+\x20limit'+';\x0a}\x0a\x0aasync'+'\x20function\x20'+'copyToClip'+'board(elem'+'entId)\x20{\x0a\x20'+'\x20\x20\x20try\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20con'+'st\x20copyTex'+'t\x20=\x20docume'+'nt.getElem'+'entById(el'+'ementId);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20co'+'pyText.sel'+'ect();\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20copyT'+'ext.setSel'+'ectionRang'+'e(0,\x2099999'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20await\x20nav'+'igator.cli'+'pboard.wri'+'teText(cop'+'yText.valu'+'e);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20showAler'+'t(\x27Copied\x20'+'to\x20clipboa'+'rd!\x27);\x0a\x20\x20\x20'+'\x20}\x20catch\x20('+'error)\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20sho'+'wAlert(\x27Fa'+'iled\x20to\x20co'+'py!\x27,\x20true'+');\x0a\x20\x20\x20\x20}\x0a}'+'\x0a\x0aasync\x20fu'+'nction\x20loa'+'dSettings('+')\x20{\x0a\x20\x20\x20\x20tr'+'y\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20const\x20re'+'sponse\x20=\x20a'+'wait\x20fetch'+'(\x27/api/set'+'tings\x27);\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20con'+'st\x20s\x20=\x20awa'+'it\x20respons'+'e.json();\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20if\x20'+'(s)\x20{\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27limit\x27)'+'.value\x20=\x20s'+'.limit\x20||\x20'+'\x27all\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27dns\x27).'+'value\x20=\x20s.'+'dns\x20||\x20\x27\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27di'+'rect\x27).val'+'ue\x20=\x20s.dir'+'ect\x20||\x20\x27\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen')+('t.getEleme'+'ntById(\x27cl'+'eanip\x27).va'+'lue\x20=\x20s.cl'+'eanip\x20||\x20\x27'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'domain\x27).v'+'alue\x20=\x20s.d'+'omain\x20||\x20\x27'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'sni\x27).valu'+'e\x20=\x20s.sni\x20'+'||\x20\x27\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27alpn\x27)'+'.value\x20=\x20s'+'.alpn\x20||\x20\x27'+'none\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27finger'+'print\x27).va'+'lue\x20=\x20s.fi'+'ngerprint\x20'+'||\x20\x27none\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27ip'+'ver\x27).valu'+'e\x20=\x20s.ipve'+'r\x20||\x20\x27none'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'network\x27).'+'value\x20=\x20s.'+'network\x20||'+'\x20\x27none\x27;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27tls\x27'+').value\x20=\x20'+'s.tls\x20||\x20\x27'+'none\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27udp\x27).'+'value\x20=\x20s.'+'udp\x20||\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'if\x20(s.frag'+'ment)\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27f'+'ragment_en'+'abled\x27).ch'+'ecked\x20=\x20s.'+'fragment.e'+'nabled\x20||\x20'+'false;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27fr'+'ag_packets'+'\x27).value\x20='+'\x20s.fragmen'+'t.packets\x20'+'||\x20\x272-8\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27frag_leng'+'th\x27).value'+'\x20=\x20s.fragm'+'ent.length'+'\x20||\x20\x27100-3'+'00\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27frag')+('_interval\x27'+').value\x20=\x20'+'s.fragment'+'.interval\x20'+'||\x20\x2710-30\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27frag_sl'+'eep\x27).valu'+'e\x20=\x20s.frag'+'ment.sleep'+'\x20||\x20\x2750\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20}\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20}\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20toggleFra'+'gmentSetti'+'ngs();\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20gener'+'ateSubscri'+'be();\x0a\x20\x20\x20\x20'+'}\x20catch\x20(e'+'rror)\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20cons'+'ole.error('+'\x27Error\x20loa'+'ding\x20setti'+'ngs:\x27,\x20err'+'or);\x0a\x20\x20\x20\x20}'+'\x0a}\x0a\x0adocume'+'nt.getElem'+'entById(\x27f'+'ragment_en'+'abled\x27).ad'+'dEventList'+'ener(\x27chan'+'ge\x27,\x20toggl'+'eFragmentS'+'ettings);\x0a'+'window.onl'+'oad\x20=\x20load'+'Settings;\x0a'+'</script>\x0a'+'</body>\x0a</'+'html>');}

//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
