// ==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING

const _0x_0x418e06=(function(){let _0x1aebfe=!![];return function(_0x39b553,_0x2bc82a){const _0x1995d8=_0x1aebfe?function(){if(_0x2bc82a){const _0x476321=_0x2bc82a['apply'](_0x39b553,arguments);_0x2bc82a=null;return _0x476321;}}:function(){};_0x1aebfe=![];return _0x1995d8;};}());const _0x_0x88c44c=_0x_0x418e06(this,function(){return _0x_0x88c44c['toString']()['search']('(((.+)+)+)'+'+$')['toString']()['constructo'+'r'](_0x_0x88c44c)['search']('(((.+)+)+)'+'+$');});_0x_0x88c44c();const _0x_0x12a1b0=(function(){let _0x36a433=!![];return function(_0x14b87d,_0x4029f5){const _0x4ff728=_0x36a433?function(){if(_0x4029f5){const _0x25f11a=_0x4029f5['apply'](_0x14b87d,arguments);_0x4029f5=null;return _0x25f11a;}}:function(){};_0x36a433=![];return _0x4ff728;};}());const _0x_0x488484=_0x_0x12a1b0(this,function(){let _0x2755b5;try{const _0x580c12=Function('return\x20(fu'+'nction()\x20'+('{}.constru'+'ctor(\x22retu'+'rn\x20this\x22)('+'\x20)')+');');_0x2755b5=_0x580c12();}catch(_0x3ee329){_0x2755b5=window;}const _0x51024a=_0x2755b5['console']=_0x2755b5['console']||{};const _0x2ce79c=['log','warn','info','error','exception','table','trace'];for(let _0x42dec0=0x0;_0x42dec0<_0x2ce79c['length'];_0x42dec0++){const _0x5a5afd=_0x_0x12a1b0['constructo'+'r']['prototype']['bind'](_0x_0x12a1b0);const _0x191e89=_0x2ce79c[_0x42dec0];const _0x361e10=_0x51024a[_0x191e89]||_0x5a5afd;_0x5a5afd['__proto__']=_0x_0x12a1b0['bind'](_0x_0x12a1b0);_0x5a5afd['toString']=_0x361e10['toString']['bind'](_0x361e10);_0x51024a[_0x191e89]=_0x5a5afd;}});_0x_0x488484();const ARISTA_TAG='ARISTA🔥';const SETTINGS_KV_KEY='settings';const CONFIG_SOURCE_URLS=['https://cd'+'n.jsdelivr'+'.net/gh/Ma'+'hsaNetConf'+'igTopic/co'+'nfig@main/'+'xray_final'+'.txt','https://cd'+'n.jsdelivr'+'.net/gh/As'+'hkan-m/v2r'+'ay@main/Su'+'b.txt','https://cd'+'n.jsdelivr'+'.net/gh/Ra'+'yan-Config'+'/C-Sub@mai'+'n/configs/'+'proxy.txt'];let ALL_CONFIGS=[];const PORT_PRIORITIES=[0x830,0x1bb,0x20fb,0x1f90];const CONFIG_LIMITS=[0x14,0x28,0x3c,0x64,'all'];function isIP(_0x4fd3a8){return/^(\d{1,3}\.){3}\d{1,3}$/['test'](_0x4fd3a8)||/^([0-9a-fA-F]*:){2,7}[0-9a-fA-F]*$/['test'](_0x4fd3a8);}function sortConfigsByPortPriority(_0x1446f7){return _0x1446f7['sort']((_0x31db59,_0x191b40)=>{const _0x55d6e1=_0x20b5a9=>{try{const _0x3958b=new URL(_0x20b5a9);const _0x4e27cd=parseInt(_0x3958b['port'])||0x1bb;const _0x31f9b6=PORT_PRIORITIES['indexOf'](_0x4e27cd);return _0x31f9b6!==-0x1?_0x31f9b6:PORT_PRIORITIES['length'];}catch{return PORT_PRIORITIES['length'];}};const _0x1f0fee=_0x55d6e1(_0x31db59);const _0x29d6ff=_0x55d6e1(_0x191b40);if(_0x1f0fee!==_0x29d6ff){return _0x1f0fee-_0x29d6ff;}try{const _0x458ba7=parseInt(new URL(_0x31db59)['port'])||0x1bb;const _0x4b14e9=parseInt(new URL(_0x191b40)['port'])||0x1bb;return _0x458ba7-_0x4b14e9;}catch{return 0x0;}});}function applyConfigLimit(_0x55aa69,_0x489007){if(_0x489007==='all')return _0x55aa69;const _0x87ecf8=parseInt(_0x489007);if(isNaN(_0x87ecf8)||_0x87ecf8<=0x0)return _0x55aa69;const _0x1e344a=sortConfigsByPortPriority(_0x55aa69);const _0x5cbe72=_0x1e344a['filter'](_0x5ef87a=>{try{const _0x53c0e7=new URL(_0x5ef87a);const _0x1e9a6d=parseInt(_0x53c0e7['port'])||0x1bb;return PORT_PRIORITIES['includes'](_0x1e9a6d);}catch{return![];}});const _0xaba161=_0x1e344a['filter'](_0x52734b=>{try{const _0x5239d3=new URL(_0x52734b);const _0x1ee65f=parseInt(_0x5239d3['port'])||0x1bb;return!PORT_PRIORITIES['includes'](_0x1ee65f);}catch{return![];}});const _0x5521ae=Math['min'](_0x5cbe72['length'],Math['ceil'](_0x87ecf8*0.6));const _0x2f2807=Math['min'](_0xaba161['length'],_0x87ecf8-_0x5521ae);return[..._0x5cbe72['slice'](0x0,_0x5521ae),..._0xaba161['slice'](0x0,_0x2f2807)]['slice'](0x0,_0x87ecf8);}async function updateConfigs(){try{let _0x52c88f=[];for(const _0x3a27f6 of CONFIG_SOURCE_URLS){const _0xf6e4d7=await fetch(_0x3a27f6);if(!_0xf6e4d7['ok'])continue;const _0x31f1f0=await _0xf6e4d7['text']();let _0x199630=_0x31f1f0['split']('\x0a')['filter'](_0x41b5fc=>_0x41b5fc['startsWith']('vless://'));_0x52c88f=_0x52c88f['concat'](_0x199630);}ALL_CONFIGS=[...new Set(_0x52c88f)];console['log']('Updated\x20co'+'nfigs:\x20'+ALL_CONFIGS['length']+('\x20unique\x20co'+'nfiguratio'+'ns\x20loaded'));}catch(_0xea5180){console['error']('Error\x20upda'+'ting\x20confi'+'gs:',_0xea5180);}}async function checkConfigStatus(){try{console['log']('Config\x20Sta'+'tus:',{'configsLoaded':ALL_CONFIGS['length'],'configsSample':ALL_CONFIGS['slice'](0x0,0x3)});return!![];}catch(_0x493ff7){console['error']('Config\x20Sta'+'tus\x20Check\x20'+'Failed:',_0x493ff7);return![];}}function applyFragmentSettings(_0x13852e,_0x3c06a1){if(!_0x3c06a1||Object['keys'](_0x3c06a1)['length']===0x0||!_0x3c06a1['enabled']){return _0x13852e;}try{const _0x41587d=new URL(_0x13852e);_0x41587d['searchPara'+'ms']['set']('fragment','true');if(_0x3c06a1['packets'])_0x41587d['searchPara'+'ms']['set']('fragmentPa'+'ckets',_0x3c06a1['packets']);if(_0x3c06a1['length'])_0x41587d['searchPara'+'ms']['set']('fragmentLe'+'ngth',_0x3c06a1['length']);if(_0x3c06a1['interval'])_0x41587d['searchPara'+'ms']['set']('fragmentIn'+'terval',_0x3c06a1['interval']);if(_0x3c06a1['sleep'])_0x41587d['searchPara'+'ms']['set']('fragmentSl'+'eep',_0x3c06a1['sleep']['toString']());return _0x41587d['toString']();}catch(_0x3a5e31){return _0x13852e;}}function applyTag(_0x55cd64){try{const _0x2c4677=new URL(_0x55cd64);_0x2c4677['hash']=ARISTA_TAG;return _0x2c4677['toString']();}catch{return _0x55cd64;}}function applyCustomSettings(_0x5bbdeb,_0x50f867){try{const _0x438f0f=new URL(_0x5bbdeb);const _0x4a4aec=Object['fromEntrie'+'s'](_0x438f0f['searchPara'+'ms']['entries']());const _0x34903c=_0x438f0f['hostname'];const _0x5aaea2=_0x4a4aec['sni']||_0x4a4aec['host']||_0x34903c;const _0x5757ef=(_0xa4e7c5,_0x54df7d)=>{if(_0x50f867[_0xa4e7c5]&&_0x50f867[_0xa4e7c5]!=='none'){return _0x50f867[_0xa4e7c5];}return _0x4a4aec[_0x54df7d]||undefined;};if(_0x50f867['dns']&&_0x50f867['dns']!=='none'){_0x438f0f['searchPara'+'ms']['set']('dns',_0x50f867['dns']);}if(_0x50f867['direct']&&_0x50f867['direct']!=='none'){_0x438f0f['searchPara'+'ms']['set']('direct',_0x50f867['direct']);}const _0x124b4e=_0x5757ef('cleanip','cleanip');const _0x865271=(_0x124b4e||'')['split'](',')['map'](_0x557059=>_0x557059['trim']())['filter'](Boolean);if(_0x865271['length']>0x0){_0x438f0f['hostname']=_0x865271[0x0];}const _0x48fdbd=_0x5757ef('domain','domain');const _0x69c3e3=_0x5757ef('domain','host')||_0x48fdbd;if(_0x69c3e3&&_0x69c3e3!=='none'){_0x438f0f['searchPara'+'ms']['set']('host',_0x69c3e3);_0x438f0f['searchPara'+'ms']['set']('domain',_0x69c3e3);}const _0x33dbfb=_0x5757ef('sni','sni');const _0x44a72b=(_0x33dbfb||'')['split'](',')['map'](_0x584d65=>_0x584d65['trim']())['filter'](Boolean);let _0x16b132=_0x44a72b[0x0]||_0x48fdbd||_0x69c3e3||_0x5aaea2;if(_0x865271['length']>0x0&&isIP(_0x438f0f['hostname'])){if(!_0x16b132||isIP(_0x16b132)){_0x16b132=_0x5aaea2||'cloudflare'+'.com';}_0x438f0f['searchPara'+'ms']['set']('sni',_0x16b132);}else if(_0x33dbfb&&_0x33dbfb!=='none'){_0x438f0f['searchPara'+'ms']['set']('sni',_0x33dbfb);}else if(_0x69c3e3&&_0x69c3e3!=='none'){_0x438f0f['searchPara'+'ms']['set']('sni',_0x69c3e3);}if(_0x50f867['alpn']&&_0x50f867['alpn']!=='none'){_0x438f0f['searchPara'+'ms']['set']('alpn',_0x50f867['alpn']);}if(_0x50f867['ipver']&&_0x50f867['ipver']!=='none'){_0x438f0f['searchPara'+'ms']['set']('ipver',_0x50f867['ipver']);}if(_0x50f867['network']&&_0x50f867['network']!=='none'){_0x438f0f['searchPara'+'ms']['set']('type',_0x50f867['network']);}if(_0x50f867['tls']&&_0x50f867['tls']!=='none'){_0x438f0f['searchPara'+'ms']['set']('security',_0x50f867['tls']==='enabled'?'tls':'none');}if(_0x50f867['udp']&&_0x50f867['udp']!=='none'){_0x438f0f['searchPara'+'ms']['set']('udp',_0x50f867['udp']==='enabled'?'true':'false');}if(_0x50f867['fingerprin'+'t']&&_0x50f867['fingerprin'+'t']!=='none'){_0x438f0f['searchPara'+'ms']['set']('fp',_0x50f867['fingerprin'+'t']);}return _0x438f0f['toString']();}catch(_0x2ee35e){return _0x5bbdeb;}}function vlessToClashMeta(_0x1bc047,_0x5eadc6,_0x4ef0d6,_0x19e1fe){try{const _0x4e88e7=new URL(_0x1bc047);const _0x466047=Object['fromEntrie'+'s'](_0x4e88e7['searchPara'+'ms']['entries']());const _0x10fbee='ARISTA🔥-'+_0x4ef0d6;const _0x535992=(_0x2a2edd,_0x2be449)=>{if(_0x19e1fe[_0x2a2edd]&&_0x19e1fe[_0x2a2edd]!=='none'){return _0x19e1fe[_0x2a2edd];}return _0x466047[_0x2be449]||undefined;};const _0x2783c3=(_0x4f2012,_0x5e454a)=>{if(_0x19e1fe[_0x4f2012]&&_0x19e1fe[_0x4f2012]!=='none'){return _0x19e1fe[_0x4f2012]==='enabled';}return _0x466047[_0x5e454a]==='true'||undefined;};const _0x364beb=_0x535992('network','type')||'tcp';const _0x32f739=_0x2783c3('tls','security');const _0x39a98e=_0x2783c3('udp','udp')!==![];const _0x35a708=_0x535992('cleanip','cleanip');const _0x4455f9=(_0x35a708||'')['split'](',')['map'](_0x1d2c3b=>_0x1d2c3b['trim']())['filter'](Boolean);const _0x6b24a7=_0x535992('domain','domain');const _0x36c0eb=_0x535992('domain','host')||_0x4e88e7['hostname'];const _0x501de4=_0x4455f9[0x0]||_0x6b24a7||_0x4e88e7['hostname'];let _0x50dcea=_0x6b24a7||_0x466047['host']||_0x535992('sni','sni')||_0x4e88e7['hostname'];if(isIP(_0x501de4)&&isIP(_0x50dcea)){_0x50dcea=_0x466047['host']||_0x4e88e7['hostname']||'cloudflare'+'.com';}const _0x3dc3d2=_0x535992('fingerprin'+'t','fp')||'chrome';const _0x1e852c=_0x535992('alpn','alpn');const _0x10b8f6={'name':_0x10fbee,'type':'vless','server':_0x501de4,'port':parseInt(_0x4e88e7['port'])||0x1bb,'uuid':_0x4e88e7['username']['split']('@')[0x0],'network':_0x364beb,'tls':_0x32f739!==![],'udp':_0x39a98e,'skip-cert-verify':![],'tcp-fast-open':!![],'fast-open':!![],'servername':_0x50dcea,'flow':_0x466047['flow']||'','client-fingerprint':_0x3dc3d2,'packet-encoding':'xudp'};if(_0x19e1fe['dns']&&_0x19e1fe['dns']!=='none'){_0x10b8f6['dns']=_0x19e1fe['dns']['split'](',')['map'](_0x195efd=>_0x195efd['trim']());}if(_0x19e1fe['direct']&&_0x19e1fe['direct']!=='none'){if(_0x10b8f6['dns']){if(!_0x10b8f6['fallback-d'+'ns']){_0x10b8f6['fallback-d'+'ns']=_0x19e1fe['direct']['split'](',')['map'](_0x4f0caa=>_0x4f0caa['trim']());}}else{_0x10b8f6['dns']=_0x19e1fe['direct']['split'](',')['map'](_0x5a82ba=>_0x5a82ba['trim']());}}if(_0x1e852c&&_0x1e852c!=='none'){_0x10b8f6['alpn']=_0x1e852c['split'](',')['map'](_0x28086d=>_0x28086d['trim']());}else if(_0x32f739){_0x10b8f6['alpn']=['h2','http/1.1'];}if(_0x19e1fe['fragment']&&_0x19e1fe['fragment']['enabled']){_0x10b8f6['fragment']={'enabled':!![],'packets':_0x19e1fe['fragment']['packets']||_0x466047['fragmentPa'+'ckets']||'2-5','length':_0x19e1fe['fragment']['length']||_0x466047['fragmentLe'+'ngth']||'100-200','interval':_0x19e1fe['fragment']['interval']||_0x466047['fragmentIn'+'terval']||'10-20','sleep':parseInt(_0x19e1fe['fragment']['sleep']||_0x466047['fragmentSl'+'eep']||'10')};}if(_0x364beb==='ws'){const _0x415735={};_0x415735['Host']=_0x50dcea;_0x415735['User-Agent']='Mozilla/5.'+'0\x20(Windows'+'\x20NT\x2010.0;\x20'+'Win64;\x20x64'+')\x20AppleWeb'+'Kit/537.36';_0x10b8f6['ws-opts']={'path':_0x466047['path']||'/','headers':_0x415735,'max-early-data':parseInt(_0x466047['maxEarlyDa'+'ta'])||0x800,'early-data-header-name':_0x466047['earlyDataH'+'eaderName']||'Sec-WebSoc'+'ket-Protoc'+'ol'};}if(_0x364beb==='grpc'){const _0x15c044={};_0x15c044['grpc-servi'+'ce-name']=_0x6b24a7||_0x466047['serviceNam'+'e']||'GunService';_0x15c044['grpc-mode']='gun';_0x10b8f6['grpc-opts']=_0x15c044;}if(_0x364beb==='http'){const _0xc176dc={};_0xc176dc['Host']=_0x50dcea;_0xc176dc['User-Agent']='Mozilla/5.'+'0\x20(Windows'+'\x20NT\x2010.0;\x20'+'Win64;\x20x64'+')\x20AppleWeb'+'Kit/537.36';const _0xab4b68={};_0xab4b68['method']=_0x466047['method']||'GET';_0xab4b68['path']=_0x466047['path']||'/';_0xab4b68['headers']=_0xc176dc;_0x10b8f6['http-opts']=_0xab4b68;}if(_0x364beb==='quic'){const _0x510777={};_0x510777['security']=_0x466047['quicSecuri'+'ty']||'none';_0x510777['key']=_0x466047['key']||'';_0x510777['type']=_0x466047['headerType']||'none';_0x10b8f6['quic-opts']=_0x510777;}if(_0x466047['security']==='reality'){const _0x519b83={};_0x519b83['public-key']=_0x466047['pbk']||'';_0x519b83['short-id']=_0x466047['sid']||'';_0x10b8f6['reality-op'+'ts']=_0x519b83;}if(_0x19e1fe['ipver']&&_0x19e1fe['ipver']!=='none'){_0x10b8f6['ipversion']=_0x19e1fe['ipver'];}return _0x10b8f6;}catch(_0x56e27b){console['error']('Error\x20in\x20v'+'lessToClas'+'hMeta:',_0x56e27b);return null;}}function generateSingBoxConfig(_0x46ffc7,_0x537247){const _0x508108=[];const _0x5f42d5=[];_0x46ffc7['forEach']((_0x4051fe,_0x4ba07c)=>{try{const _0x366870=new URL(_0x4051fe);if(_0x366870['username']&&_0x366870['hostname']&&_0x366870['port']){const _0x253957=vlessToSingBox(_0x4051fe,_0x4ba07c+0x1,_0x537247);if(_0x253957){_0x508108['push'](_0x253957);_0x5f42d5['push'](_0x253957['tag']);}}}catch(_0x2ddc16){console['error']('Invalid\x20co'+'nfig\x20skipp'+'ed:',_0x2ddc16);}});if(_0x5f42d5['length']===0x0){const _0x2e1580={};_0x2e1580['level']='info';_0x2e1580['timestamp']=!![];const _0x5acf6c={};_0x5acf6c['type']='direct';_0x5acf6c['tag']='direct';const _0x3255e6={};_0x3255e6['rules']=[];const _0x519bf1={};_0x519bf1['log']=_0x2e1580;_0x519bf1['inbounds']=[];_0x519bf1['outbounds']=[_0x5acf6c];_0x519bf1['route']=_0x3255e6;return _0x519bf1;}const _0x1b02f5=['ac.ir','adliran.ir','ari.ac.ir','aui.ac.ir','aut.ac.ir','iau.ir','iau.ac.ir','iust.ac.ir','kashanu.ac'+'.ir','khu.ac.ir','modares.ac'+'.ir','sharif.edu','shirazu.ac'+'.ir','tabrizu.ac'+'.ir','tmu.ac.ir','ui.ac.ir','ut.ac.ir','.ir','digikala.c'+'om','snapp.ir','tapsi.ir','divar.ir','bamilo.com','alibaba.ir','aparat.com','filimo.com','namava.ir','takhfifan.'+'com','torob.com','esam.ir'];const _0x338f62={};_0x338f62['type']='selector';_0x338f62['tag']='🇮🇷\x20PROXY';_0x338f62['outbounds']=['🚀\x20AUTO','⚡\x20FASTEST',..._0x5f42d5,'DIRECT'];const _0x5bb3e0={};_0x5bb3e0['type']='urltest';_0x5bb3e0['tag']='🚀\x20AUTO';_0x5bb3e0['outbounds']=_0x5f42d5;_0x5bb3e0['url']='http://www'+'.gstatic.c'+'om/generat'+'e_204';_0x5bb3e0['interval']='3m';_0x5bb3e0['tolerance']=0x96;const _0x51f78c={};_0x51f78c['type']='urltest';_0x51f78c['tag']='⚡\x20FASTEST';_0x51f78c['outbounds']=_0x5f42d5;_0x51f78c['url']='http://con'+'nectivityc'+'heck.gstat'+'ic.com/gen'+'erate_204';_0x51f78c['interval']='1m';_0x51f78c['tolerance']=0x32;const _0x323003={};_0x323003['type']='selector';_0x323003['tag']='📱\x20SOCIAL';_0x323003['outbounds']=['🇮🇷\x20PROXY','🚀\x20AUTO','DIRECT'];_0x323003['default']='🇮🇷\x20PROXY';const _0x5be491={};_0x5be491['type']='selector';_0x5be491['tag']='🎬\x20STREAMIN'+'G';_0x5be491['outbounds']=['🇮🇷\x20PROXY','🚀\x20AUTO','DIRECT'];_0x5be491['default']='🇮🇷\x20PROXY';const _0x51bf46={};_0x51bf46['type']='selector';_0x51bf46['tag']='💾\x20DOWNLOAD';_0x51bf46['outbounds']=['🇮🇷\x20PROXY','🚀\x20AUTO','DIRECT'];_0x51bf46['default']='🚀\x20AUTO';const _0x2e2a2c=[_0x338f62,_0x5bb3e0,_0x51f78c,_0x323003,_0x5be491,_0x51bf46];const _0x48c8d8={};_0x48c8d8['domain_suf'+'fix']=['adsystem.c'+'om','doubleclic'+'k.net','googleadse'+'rvices.com','googlesynd'+'ication.co'+'m','google-ana'+'lytics.com'];_0x48c8d8['outbound']='REJECT';const _0x528bb6={};_0x528bb6['domain_suf'+'fix']=_0x1b02f5;_0x528bb6['outbound']='DIRECT';const _0x145ac0={};_0x145ac0['domain_suf'+'fix']=['telegram.o'+'rg','t.me','telegram.m'+'e','whatsapp.c'+'om','wa.me','twitter.co'+'m','x.com','t.co','instagram.'+'com','cdninstagr'+'am.com','facebook.c'+'om','fb.com','facebook.n'+'et','discord.co'+'m','discord.gg','discordapp'+'.com'];_0x145ac0['outbound']='📱\x20SOCIAL';const _0x15f578={};_0x15f578['domain_suf'+'fix']=['youtube.co'+'m','youtu.be','googlevide'+'o.com','netflix.co'+'m','nflxext.co'+'m','nflximg.co'+'m','spotify.co'+'m','scdn.co','twitch.tv','ttvnw.net'];_0x15f578['outbound']='🎬\x20STREAMIN'+'G';const _0x3ee977={};_0x3ee977['domain_suf'+'fix']=['github.com','githubasse'+'ts.com','github.io','gitlab.com','gitlab-sta'+'tic.net','microsoft.'+'com','windowsupd'+'ate.com','apple.com','appldnld.a'+'pple.com'];_0x3ee977['outbound']='💾\x20DOWNLOAD';const _0x9a3a07={};_0x9a3a07['ip_cidr']=['10.0.0.0/8','172.16.0.0'+'/12','192.168.0.'+'0/16','127.0.0.0/'+'8','100.64.0.0'+'/10','169.254.0.'+'0/16'];_0x9a3a07['outbound']='DIRECT';const _0x5d1e57={};_0x5d1e57['inbound']=['tun-in'];_0x5d1e57['outbound']='🇮🇷\x20PROXY';const _0x24eec4=[_0x48c8d8,_0x528bb6,_0x145ac0,_0x15f578,_0x3ee977,_0x9a3a07,_0x5d1e57];const _0x302921={};_0x302921['level']='info';_0x302921['timestamp']=!![];const _0x5514e2={};_0x5514e2['tag']='block';_0x5514e2['address']='rcode://su'+'ccess';const _0x2ce892={};_0x2ce892['domain_suf'+'fix']=_0x1b02f5;_0x2ce892['server']='local';const _0x1c6138={};_0x1c6138['domain_suf'+'fix']=['adsystem.c'+'om','doubleclic'+'k.net','googlesynd'+'ication.co'+'m'];_0x1c6138['server']='block';const _0x3153d7={};_0x3153d7['type']='tun';_0x3153d7['tag']='tun-in';_0x3153d7['interface_'+'name']='tun0';_0x3153d7['mtu']=0x5dc;_0x3153d7['inet4_addr'+'ess']='172.19.0.1'+'/30';_0x3153d7['auto_route']=!![];_0x3153d7['strict_rou'+'te']=!![];_0x3153d7['stack']='system';_0x3153d7['sniff']=!![];const _0x3214ed={};_0x3214ed['type']='direct';_0x3214ed['tag']='DIRECT';const _0x3e301a={};_0x3e301a['type']='block';_0x3e301a['tag']='REJECT';const _0x584e04={};_0x584e04['rules']=_0x24eec4;_0x584e04['auto_detec'+'t_interfac'+'e']=!![];_0x584e04['final']='🇮🇷\x20PROXY';const _0x490127={'log':_0x302921,'dns':{'servers':[{'tag':'remote','address':_0x537247['dns']&&_0x537247['dns']!=='none'?_0x537247['dns']['split'](',')[0x0]['trim']():'8.8.8.8','detour':'🇮🇷\x20PROXY'},{'tag':'local','address':_0x537247['direct']&&_0x537247['direct']!=='none'?_0x537247['direct']['split'](',')[0x0]['trim']():'10.202.10.'+'10','detour':'DIRECT'},_0x5514e2],'rules':[_0x2ce892,_0x1c6138],'strategy':'prefer_ipv'+'4'},'inbounds':[_0x3153d7],'outbounds':[_0x3214ed,_0x3e301a,..._0x2e2a2c,..._0x508108],'route':_0x584e04};return _0x490127;}function vlessToSingBox(_0x51abb6,_0x2ffa15,_0x2ff59a){try{const _0x295147=new URL(_0x51abb6);const _0x3d0e1d=Object['fromEntrie'+'s'](_0x295147['searchPara'+'ms']['entries']());const _0x363887='ARISTA-'+(_0x2ffa15+0x1);const _0x3b54c6=(_0x297e68,_0x4d7f19)=>{if(_0x2ff59a[_0x297e68]&&_0x2ff59a[_0x297e68]!=='none'){return _0x2ff59a[_0x297e68];}return _0x3d0e1d[_0x4d7f19]||undefined;};const _0x5cd29b=_0x3b54c6('cleanip','cleanip');const _0x2f9bbd=(_0x5cd29b||'')['split'](',')['map'](_0x575d02=>_0x575d02['trim']())['filter'](Boolean);const _0x32dbfb=_0x3b54c6('sni','sni');const _0x177c3e=_0x3b54c6('fingerprin'+'t','fp');const _0x17ed57=_0x3b54c6('alpn','alpn');const _0x9f83bd=_0x3b54c6('network','type');const _0xbbcd0a=_0x3b54c6('tls','security');const _0x5102bd=_0x3b54c6('udp','udp');const _0xeca84e=_0x3b54c6('ipver','ipver');const _0x1132a5=_0x2f9bbd[0x0]||_0x295147['hostname'];let _0x11cd24=_0x32dbfb||_0x3d0e1d['sni']||_0x3d0e1d['host']||_0x295147['hostname'];if(isIP(_0x1132a5)&&(!_0x11cd24||isIP(_0x11cd24)||!_0x11cd24['includes']('.'))){_0x11cd24=_0x295147['hostname'];}const _0x43e6d3={};_0x43e6d3['enabled']=!![];_0x43e6d3['fingerprin'+'t']=_0x177c3e||'chrome';const _0x5cd132={};_0x5cd132['enabled']=!![];_0x5cd132['server_nam'+'e']=_0x11cd24;_0x5cd132['insecure']=![];_0x5cd132['utls']=_0x43e6d3;const _0x1b018a={'type':'vless','tag':_0x363887,'server':_0x1132a5,'server_port':parseInt(_0x295147['port'])||0x1bb,'uuid':_0x295147['username'],'packet_encoding':'xudp','tls':_0x5cd132};if(_0x3d0e1d['flow']){_0x1b018a['flow']=_0x3d0e1d['flow'];}if(_0x17ed57&&_0x17ed57!=='none'){_0x1b018a['tls']['alpn']=_0x17ed57['split'](',')['map'](_0x249218=>_0x249218['trim']());}if(_0x5102bd&&_0x5102bd!=='none'){_0x1b018a['udp']=_0x5102bd==='enabled';}if(_0xeca84e&&_0xeca84e!=='none'){_0x1b018a['domain_str'+'ategy']=_0xeca84e;}const _0x3d516f=_0x9f83bd&&_0x9f83bd!=='none'?_0x9f83bd:_0x3d0e1d['type']||'tcp';if(_0x3d516f==='ws'){const _0x482975={};_0x482975['Host']=_0x11cd24;const _0x25020b={};_0x25020b['type']='ws';_0x25020b['path']=_0x3d0e1d['path']||'/';_0x25020b['headers']=_0x482975;_0x1b018a['transport']=_0x25020b;}else if(_0x3d516f==='grpc'){const _0x5723a2={};_0x5723a2['type']='grpc';_0x5723a2['service_na'+'me']=_0x3d0e1d['serviceNam'+'e']||'GunService';_0x1b018a['transport']=_0x5723a2;}if(_0xbbcd0a==='disabled'){const _0x43e324={};_0x43e324['enabled']=![];_0x1b018a['tls']=_0x43e324;}if(_0x3d0e1d['security']==='reality'){const _0x5239dc={};_0x5239dc['enabled']=!![];_0x5239dc['public_key']=_0x3d0e1d['pbk']||'';_0x5239dc['short_id']=_0x3d0e1d['sid']||'';_0x1b018a['tls']['reality']=_0x5239dc;}return _0x1b018a;}catch(_0x2fc330){console['error']('Error\x20conv'+'erting\x20VLE'+'SS\x20to\x20Sing'+'Box:',_0x2fc330);return null;}}export default{async 'scheduled'(_0x44814e,_0xa4b29b,_0x55b0d4){if(_0x44814e['cron']==='0\x20*/3\x20*\x20*\x20'+'*'){_0x55b0d4['waitUntil'](updateConfigs());}},async 'fetch'(_0x146dd1,_0x289aca,_0x4c3b93){const _0x2cc010=new URL(_0x146dd1['url']);if(_0x2cc010['pathname']==='/'){const _0x28cff3={};_0x28cff3['content-ty'+'pe']='text/html;'+'charset=ut'+'f-8';_0x28cff3['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x38d10a={};_0x38d10a['headers']=_0x28cff3;return new Response(getHTML(),_0x38d10a);}if(_0x2cc010['pathname']==='/api/setti'+'ngs'){if(_0x146dd1['method']==='POST'){try{const _0x3a2690=await _0x146dd1['json']();await _0x289aca['KV']['put'](SETTINGS_KV_KEY,JSON['stringify'](_0x3a2690));const _0x5bfee3={};_0x5bfee3['ok']=!![];const _0x361bff={};_0x361bff['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';const _0x34939f={};_0x34939f['headers']=_0x361bff;return new Response(JSON['stringify'](_0x5bfee3),_0x34939f);}catch(_0x1f5d1a){const _0x27b171={};_0x27b171['error']='Invalid\x20JS'+'ON';const _0x5ba219={};_0x5ba219['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';const _0x41c1ba={};_0x41c1ba['status']=0x190;_0x41c1ba['headers']=_0x5ba219;return new Response(JSON['stringify'](_0x27b171),_0x41c1ba);}}else{try{const _0x245933=await _0x289aca['KV']['get'](SETTINGS_KV_KEY);const _0x1a1525={};_0x1a1525['content-ty'+'pe']='applicatio'+'n/json';_0x1a1525['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x54b203={};_0x54b203['headers']=_0x1a1525;return new Response(_0x245933||'{}',_0x54b203);}catch(_0xad3210){const _0x27821f={};_0x27821f['content-ty'+'pe']='applicatio'+'n/json';const _0x20753c={};_0x20753c['headers']=_0x27821f;return new Response('{}',_0x20753c);}}}if(_0x2cc010['pathname']==='/api/confi'+'gs'){try{if(ALL_CONFIGS['length']===0x0){await updateConfigs();}let _0x1a3355=[...ALL_CONFIGS];if(_0x1a3355['length']===0x0){const _0x3c7b49={};_0x3c7b49['status']=0x194;return new Response('No\x20configu'+'rations\x20fo'+'und',_0x3c7b49);}const _0x46d9e5=await _0x289aca['KV']['get'](SETTINGS_KV_KEY);const _0x53cafb=_0x46d9e5?JSON['parse'](_0x46d9e5):{};const _0x5f38b9=_0x2cc010['searchPara'+'ms']['get']('limit')||'all';_0x1a3355=applyConfigLimit(_0x1a3355,_0x5f38b9);const _0x5b93cc=(_0x53cafb['cleanip']||'')['split'](',')['map'](_0x512a5b=>_0x512a5b['trim']())['filter'](Boolean);const _0x58dbc2=(_0x53cafb['sni']||'')['split'](',')['map'](_0x50e81f=>_0x50e81f['trim']())['filter'](Boolean);let _0x512a40=[];if(_0x5b93cc['length']>0x1){_0x1a3355['forEach']((_0x414583,_0x16ff52)=>{_0x5b93cc['forEach']((_0x52cc57,_0x347061)=>{let _0x4f9193=_0x414583;const _0x5643e6={..._0x53cafb};const _0x185bb8=_0x5643e6;_0x185bb8['cleanip']=_0x52cc57;if(_0x58dbc2[_0x347061]){_0x185bb8['sni']=_0x58dbc2[_0x347061];}else if(_0x58dbc2['length']>0x0){_0x185bb8['sni']=_0x58dbc2[_0x58dbc2['length']-0x1];}_0x4f9193=applyCustomSettings(_0x4f9193,_0x185bb8);if(_0x53cafb['fragment']&&_0x53cafb['fragment']['enabled']){_0x4f9193=applyFragmentSettings(_0x4f9193,_0x53cafb['fragment']);}_0x512a40['push'](applyTag(_0x4f9193));});});}else{_0x512a40=_0x1a3355['map'](_0x5435bb=>{let _0x5c0fb6=_0x5435bb;_0x5c0fb6=applyCustomSettings(_0x5c0fb6,_0x53cafb);if(_0x53cafb['fragment']&&_0x53cafb['fragment']['enabled']){_0x5c0fb6=applyFragmentSettings(_0x5c0fb6,_0x53cafb['fragment']);}return applyTag(_0x5c0fb6);});}_0x1a3355=_0x512a40;const _0x7fcbf5=_0x2cc010['searchPara'+'ms']['get']('format')||'v2ray';if(_0x7fcbf5==='clash'){const _0x307248={};_0x307248['geoip']=!![];_0x307248['geoip-code']='IR';_0x307248['ipcidr']=['0.0.0.0/8','127.0.0.0/'+'8','10.0.0.0/8','172.16.0.0'+'/12','192.168.0.'+'0/16'];const _0x2abb49={'port':0x1ed2,'socks-port':0x1ed3,'mixed-port':0x1ed5,'mode':'rule','log-level':'info','dns':{'enable':!![],'listen':':53','enhanced-mode':'fake-ip','fake-ip-range':'198.18.0.1'+'/16','fake-ip-filter':['*.lan','*.local','*.localhos'+'t','*.ir','*.test'],'nameserver':_0x53cafb['dns']&&_0x53cafb['dns']!=='none'?_0x53cafb['dns']['split'](',')['map'](_0x4a2bc4=>_0x4a2bc4['trim']()):['78.157.42.'+'100','78.157.42.'+'101','10.202.10.'+'10','8.8.8.8','1.1.1.1'],'fallback':_0x53cafb['direct']&&_0x53cafb['direct']!=='none'?_0x53cafb['direct']['split'](',')['map'](_0x3e49f5=>_0x3e49f5['trim']()):['10.202.10.'+'11','78.157.42.'+'100','8.8.4.4'],'fallback-filter':_0x307248},'proxies':[],'proxy-groups':[],'rules':['DOMAIN-SUF'+'FIX,google'+'.com,ARIST'+'A\x20Auto','DOMAIN-SUF'+'FIX,youtub'+'e.com,ARIS'+'TA\x20Auto','DOMAIN-SUF'+'FIX,github'+'.com,ARIST'+'A\x20Auto','DOMAIN-KEY'+'WORD,teleg'+'ram,ARISTA'+'\x20Auto','DOMAIN-SUF'+'FIX,instag'+'ram.com,AR'+'ISTA\x20Auto','DOMAIN-SUF'+'FIX,twitte'+'r.com,ARIS'+'TA\x20Auto','DOMAIN-SUF'+'FIX,whatsa'+'pp.com,ARI'+'STA\x20Auto','DOMAIN-SUF'+'FIX,cdn.ir'+',DIRECT','DOMAIN-SUF'+'FIX,aparat'+'.com,DIREC'+'T','DOMAIN-SUF'+'FIX,digika'+'la.com,DIR'+'ECT','DOMAIN-SUF'+'FIX,divar.'+'ir,DIRECT','DOMAIN-SUF'+'FIX,snapp.'+'ir,DIRECT','DOMAIN-SUF'+'FIX,torob.'+'com,DIRECT','DOMAIN-SUF'+'FIX,bamilo'+'.com,DIREC'+'T','DOMAIN-SUF'+'FIX,alibab'+'a.ir,DIREC'+'T','DOMAIN-SUF'+'FIX,ban.ir'+',DIRECT','GEOIP,IR,D'+'IRECT','MATCH,ARIS'+'TA\x20Auto']};const _0x3db1e6=[];_0x1a3355['forEach']((_0x754685,_0x2a8415)=>{const _0x233109=vlessToClashMeta(_0x754685,'ARISTA',_0x2a8415+0x1,_0x53cafb);if(_0x233109){_0x3db1e6['push'](_0x233109);}});_0x2abb49['proxies']=_0x3db1e6;if(_0x2abb49['proxies']['length']>0x0){const _0x203315=[];_0x203315['push']({'name':'ARISTA\x20Sel'+'ect','type':'select','proxies':['ARISTA\x20Aut'+'o','ARISTA\x20Fal'+'lback','ARISTA\x20Loa'+'d\x20Balance',..._0x3db1e6['map'](_0xc0b2d4=>_0xc0b2d4['name'])],'disable-udp':![]});_0x203315['push']({'name':'ARISTA\x20Aut'+'o','type':'url-test','proxies':_0x3db1e6['map'](_0x3c0699=>_0x3c0699['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x78,'tolerance':0x32,'lazy':!![],'disable-udp':![]});_0x203315['push']({'name':'ARISTA\x20Fal'+'lback','type':'fallback','proxies':_0x3db1e6['map'](_0x1f2cbd=>_0x1f2cbd['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x78,'tolerance':0x64,'disable-udp':![]});_0x203315['push']({'name':'ARISTA\x20Loa'+'d\x20Balance','type':'load-balan'+'ce','proxies':_0x3db1e6['map'](_0x36991b=>_0x36991b['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x12c,'strategy':'consistent'+'-hashing','disable-udp':![]});_0x2abb49['proxy-grou'+'ps']=_0x203315;}const _0x37d887={};_0x37d887['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';_0x37d887['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x147df9={};_0x147df9['headers']=_0x37d887;return new Response(JSON['stringify'](_0x2abb49,null,0x2),_0x147df9);}if(_0x7fcbf5==='singbox'){const _0x377542=generateSingBoxConfig(_0x1a3355,_0x53cafb);const _0x2ece90={};_0x2ece90['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';_0x2ece90['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x4372df={};_0x4372df['headers']=_0x2ece90;return new Response(JSON['stringify'](_0x377542,null,0x2),_0x4372df);}const _0x31be35={};_0x31be35['content-ty'+'pe']='text/plain'+';charset=u'+'tf-8';_0x31be35['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x34e135={};_0x34e135['headers']=_0x31be35;return new Response(_0x1a3355['join']('\x0a'),_0x34e135);}catch(_0x5757c7){console['error']('Error\x20in\x20/'+'api/config'+'s:',_0x5757c7);const _0x191641={};_0x191641['status']=0x1f4;return new Response('Internal\x20S'+'erver\x20Erro'+'r',_0x191641);}}const _0x3dab4f={};_0x3dab4f['status']=0x194;return new Response('Not\x20Found',_0x3dab4f);}};function getHTML(){return'<!DOCTYPE\x20'+'html>\x0a<htm'+'l\x20lang=\x22en'+'\x22>\x0a<head>\x0a'+'<meta\x20char'+'set=\x22UTF-8'+'\x22\x20/>\x0a<meta'+'\x20name=\x22vie'+'wport\x22\x20con'+'tent=\x22widt'+'h=device-w'+'idth,\x20init'+'ial-scale='+'1.0\x22\x20/>\x0a<t'+'itle>ARIST'+'A\x20Config\x20G'+'enerator</'+'title>\x0a<st'+'yle>\x0a*\x20{\x20b'+'ox-sizing:'+'\x20border-bo'+'x;\x20margin:'+'\x200;\x20paddin'+'g:\x200;\x20}\x0abo'+'dy\x20{\x20font-'+'family:\x20\x27S'+'egoe\x20UI\x27,\x20'+'Tahoma,\x20Ge'+'neva,\x20Verd'+'ana,\x20sans-'+'serif;\x20bac'+'kground:\x20#'+'0b1c3d;\x20co'+'lor:\x20#fff;'+'\x20line-heig'+'ht:\x201.6;\x20}'+'\x0a.containe'+'r\x20{\x20max-wi'+'dth:\x20800px'+';\x20margin:\x20'+'0\x20auto;\x20pa'+'dding:\x2020p'+'x;\x20}\x0a.head'+'er\x20{\x20backg'+'round:\x20lin'+'ear-gradie'+'nt(135deg,'+'\x20#1a3b7c\x200'+'%,\x20#2c5282'+'\x20100%);\x20co'+'lor:\x20white'+';\x20padding:'+'\x2025px;\x20bor'+'der-radius'+':\x2015px;\x20ma'+'rgin-botto'+'m:\x2025px;\x20t'+'ext-align:'+'\x20center;\x20b'+'ox-shadow:'+'\x200\x204px\x2015p'+'x\x20rgba(0,0'+',0,0.2);\x20}'+'\x0ah1\x20{\x20marg'+'in:\x200;\x20fon'+'t-size:\x2028'+'px;\x20font-w'+'eight:\x20700'+';\x20}\x0a.heade'+'r\x20p\x20{\x20marg'+'in:\x2010px\x200'+'\x200;\x20opacit'+'y:\x200.9;\x20}\x0a'+'.card\x20{\x20ba'+'ckground:\x20'+'#13274f;\x20p'+'adding:\x2025'+'px;\x20border'+'-radius:\x201'+'5px;\x20margi'+'n:\x2015px\x200;'+'\x20box-shado'+'w:\x200\x204px\x201'+'0px\x20rgba(0'+',0,0,0.15)'+';\x20}\x0alabel\x20'+'{\x20display:'+'\x20block;\x20ma'+'rgin-top:\x20'+'15px;\x20font'+'-weight:\x206'+'00;\x20color:'+'\x20#e2e8f0;\x20'+'}\x0a.help-te'+'xt\x20{\x20font-'+'size:\x2013px'+';\x20color:\x20#'+'a0aec0;\x20ma'+'rgin-top:\x20'+'5px;\x20}\x0ainp'+('ut,\x20select'+',\x20textarea'+'\x20{\x20width:\x20'+'100%;\x20padd'+'ing:\x2012px;'+'\x20margin-to'+'p:\x208px;\x20bo'+'rder:\x201px\x20'+'solid\x20#2d3'+'748;\x20borde'+'r-radius:\x20'+'8px;\x20backg'+'round:\x20#0b'+'1c3d;\x20colo'+'r:\x20#fff;\x20f'+'ont-size:\x20'+'14px;\x20tran'+'sition:\x20al'+'l\x200.3s\x20eas'+'e;\x20}\x0ainput'+':focus,\x20se'+'lect:focus'+',\x20textarea'+':focus\x20{\x20o'+'utline:\x20no'+'ne;\x20border'+'-color:\x20#4'+'299e1;\x20box'+'-shadow:\x200'+'\x200\x200\x203px\x20r'+'gba(66,\x2015'+'3,\x20225,\x200.'+'2);\x20}\x0abutt'+'on\x20{\x20margi'+'n-top:\x2020p'+'x;\x20padding'+':\x2014px;\x20wi'+'dth:\x20100%;'+'\x20border:\x20n'+'one;\x20borde'+'r-radius:\x20'+'8px;\x20color'+':\x20#fff;\x20fo'+'nt-weight:'+'\x20600;\x20curs'+'or:\x20pointe'+'r;\x20transit'+'ion:\x20all\x200'+'.3s\x20ease;\x20'+'font-size:'+'\x2016px;\x20}\x0ab'+'utton:hove'+'r\x20{\x20transf'+'orm:\x20trans'+'lateY(-2px'+');\x20box-sha'+'dow:\x200\x204px'+'\x2012px\x20rgba'+'(0,0,0,0.2'+');\x20}\x0a.btn-'+'save\x20{\x20bac'+'kground:\x20l'+'inear-grad'+'ient(135de'+'g,\x20#22c55e'+'\x200%,\x20#16a3'+'4a\x20100%);\x20'+'}\x0a.btn-res'+'et\x20{\x20\x0a\x20\x20ba'+'ckground:\x20'+'linear-gra'+'dient(135d'+'eg,\x20#f9731'+'6\x2050%,\x20#ea'+'580c\x20100%)'+';\x20\x0a}\x0a.btn-'+'copy\x20{\x20bac'+'kground:\x20l'+'inear-grad'+'ient(135de'+'g,\x20#8b5cf6'+'\x200%,\x20#7c3a'+'ed\x20100%);\x20'+'}\x0a.fragmen'+'t-section\x20'+'{\x20backgrou'+'nd:\x20#1e3a8'+'a;\x20padding'+':\x2015px;\x20bo'+'rder-radiu'+'s:\x2010px;\x20m'+'argin-top:'+'\x2015px;\x20}\x0a.'+'fragment-t'+'oggle\x20{\x20di'+'splay:\x20fle'+'x;\x20align-i'+'tems:\x20cent'+'er;\x20margin'+'-bottom:\x201')+('5px;\x20}\x0a.fr'+'agment-tog'+'gle\x20label\x20'+'{\x20margin:\x20'+'0\x200\x200\x2015px'+';\x20font-wei'+'ght:\x20600;\x20'+'}\x0a.switch\x20'+'{\x20position'+':\x20relative'+';\x20display:'+'\x20inline-bl'+'ock;\x20width'+':\x2060px;\x20he'+'ight:\x2030px'+';\x20}\x0a.switc'+'h\x20input\x20{\x20'+'opacity:\x200'+';\x20width:\x200'+';\x20height:\x20'+'0;\x20}\x0a.slid'+'er\x20{\x20posit'+'ion:\x20absol'+'ute;\x20curso'+'r:\x20pointer'+';\x20top:\x200;\x20'+'left:\x200;\x20r'+'ight:\x200;\x20b'+'ottom:\x200;\x20'+'background'+'-color:\x20#4'+'a5568;\x20tra'+'nsition:\x20.'+'4s;\x20border'+'-radius:\x203'+'4px;\x20}\x0a.sl'+'ider:befor'+'e\x20{\x20positi'+'on:\x20absolu'+'te;\x20conten'+'t:\x20\x22\x22;\x20hei'+'ght:\x2022px;'+'\x20width:\x2022'+'px;\x20left:\x20'+'4px;\x20botto'+'m:\x204px;\x20ba'+'ckground-c'+'olor:\x20whit'+'e;\x20transit'+'ion:\x20.4s;\x20'+'border-rad'+'ius:\x2050%;\x20'+'}\x0ainput:ch'+'ecked\x20+\x20.s'+'lider\x20{\x20ba'+'ckground-c'+'olor:\x20#219'+'6F3;\x20}\x0ainp'+'ut:checked'+'\x20+\x20.slider'+':before\x20{\x20'+'transform:'+'\x20translate'+'X(30px);\x20}'+'\x0atextarea\x20'+'{\x20height:\x20'+'120px;\x20res'+'ize:\x20verti'+'cal;\x20}\x0afoo'+'ter\x20{\x20text'+'-align:\x20ce'+'nter;\x20marg'+'in-top:\x2030'+'px;\x20opacit'+'y:\x200.7;\x20fo'+'nt-size:\x201'+'4px;\x20}\x0a.al'+'ert\x20{\x20posi'+'tion:\x20fixe'+'d;\x20top:\x2020'+'px;\x20right:'+'\x2020px;\x20pad'+'ding:\x2015px'+'\x2025px;\x20bac'+'kground:\x20#'+'22c55e;\x20co'+'lor:\x20white'+';\x20border-r'+'adius:\x208px'+';\x20box-shad'+'ow:\x200\x204px\x20'+'15px\x20rgba('+'0,0,0,0.2)'+';\x20z-index:'+'\x201000;\x20opa'+'city:\x200;\x20t'+'ransform:\x20'+'translateY'+'(-20px);\x20t'+'ransition:')+('\x20all\x200.3s\x20'+'ease;\x20}\x0a.a'+'lert.show\x20'+'{\x20opacity:'+'\x201;\x20transf'+'orm:\x20trans'+'lateY(0);\x20'+'}\x0a.alert.e'+'rror\x20{\x20bac'+'kground:\x20#'+'ef4444;\x20}\x0a'+'.grid\x20{\x20di'+'splay:\x20gri'+'d;\x20grid-te'+'mplate-col'+'umns:\x201fr\x20'+'1fr;\x20gap:\x20'+'15px;\x20}\x0a@m'+'edia\x20(max-'+'width:\x20768'+'px)\x20{\x0a\x20\x20\x20\x20'+'.grid\x20{\x20gr'+'id-templat'+'e-columns:'+'\x201fr;\x20}\x0a\x20\x20'+'\x20\x20.contain'+'er\x20{\x20paddi'+'ng:\x2015px;\x20'+'}\x0a\x20\x20\x20\x20.hea'+'der\x20{\x20padd'+'ing:\x2020px;'+'\x20}\x0a\x20\x20\x20\x20.ca'+'rd\x20{\x20paddi'+'ng:\x2020px;\x20'+'}\x0a}\x0a</styl'+'e>\x0a</head>'+'\x0a<body>\x0a<d'+'iv\x20class=\x22'+'container\x22'+'>\x0a<div\x20cla'+'ss=\x22header'+'\x22>\x0a<h1>ARI'+'STA\x20Config'+'\x20Generator'+'</h1>\x0a<p>G'+'enerate\x20an'+'d\x20customiz'+'e\x20VLESS\x20co'+'nfiguratio'+'ns</p>\x0a</d'+'iv>\x0a<div\x20s'+'tyle=\x22\x0a\x20\x20\x20'+'\x20backgroun'+'d:\x20linear-'+'gradient(1'+'35deg,\x20rgb'+'a(138,\x2043,'+'\x20226,\x200.1)'+',\x20rgba(218'+',\x20112,\x20214'+',\x200.1));\x0a\x20'+'\x20\x20\x20backdro'+'p-filter:\x20'+'blur(10px)'+';\x0a\x20\x20\x20\x20padd'+'ing:\x2015px\x20'+'20px;\x0a\x20\x20\x20\x20'+'border-rad'+'ius:\x2012px;'+'\x0a\x20\x20\x20\x20margi'+'n:\x2020px\x20au'+'to;\x0a\x20\x20\x20\x20te'+'xt-align:\x20'+'center;\x0a\x20\x20'+'\x20\x20box-shad'+'ow:\x200\x204px\x20'+'20px\x20rgba('+'138,\x2043,\x202'+'26,\x200.2);\x0a'+'\x20\x20\x20\x20border'+':\x201px\x20soli'+'d\x20white;\x0a\x20'+'\x20\x20\x20max-wid'+'th:\x2090%;\x0a\x22'+'>\x0a\x20\x20\x20\x20<div'+'\x20style=\x22\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20dis'+'play:\x20flex'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'justify-co'+'ntent:\x20cen'+'ter;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20gap:\x2025'+'px;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20flex-wra'+'p:\x20wrap;\x0a\x20'+'\x20\x20\x20\x22>\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20<a\x20hre'+'f=\x22https:/'+'/t.me/aris')+('taproject\x22'+'\x20target=\x22_'+'blank\x22\x20sty'+'le=\x22\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20dis'+'play:\x20flex'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20align-'+'items:\x20cen'+'ter;\x20\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20ga'+'p:\x208px;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'padding:\x201'+'0px\x2020px;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20backgrou'+'nd:\x20linear'+'-gradient('+'135deg,\x20rg'+'ba(0,\x20136,'+'\x20204,\x200.2)'+',\x20rgba(0,\x20'+'119,\x20181,\x20'+'0.3));\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20c'+'olor:\x20whit'+'e;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20text-'+'decoration'+':\x20none;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'border-rad'+'ius:\x208px;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20transiti'+'on:\x20all\x200.'+'3s\x20ease;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20border:\x201'+'px\x20solid\x20r'+'gba(0,\x20136'+',\x20204,\x200.3'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20font-'+'weight:\x2060'+'0;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x22\x20onmouse'+'over=\x22this'+'.style.tra'+'nsform=\x27tr'+'anslateY(-'+'2px)\x27;this'+'.style.box'+'Shadow=\x270\x20'+'6px\x2015px\x20r'+'gba(0,136,'+'204,0.3)\x27;'+'\x22\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20onmous'+'eout=\x22this'+'.style.tra'+'nsform=\x27tr'+'anslateY(0'+')\x27;this.st'+'yle.boxSha'+'dow=\x27none\x27'+';\x22>\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20<svg'+'\x20xmlns=\x22ht'+'tp://www.w'+'3.org/2000'+'/svg\x22\x20widt'+'h=\x2218\x22\x20hei'+'ght=\x2218\x22\x20f'+'ill=\x22curre'+'ntColor\x22\x20v'+'iewBox=\x220\x20'+'0\x2016\x2016\x22>\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20<pat'+'h\x20d=\x22M16\x208'+'A8\x208\x200\x201\x201'+'\x200\x208a8\x208\x200'+'\x200\x201\x2016\x200z'+'M8.287\x205.9'+'06c-.778.3'+'24-2.334.9'+'94-4.666\x202'+'.01-.378.1'+'5-.577.298'+'-.595.442-'+'.03.243.27'+'5.339.69.4'+'7l.175.055'+'c.408.133.'+'958.288\x201.'+'243.294.26'+'.006.549-.'+'1.868-.32\x20')+('2.179-1.47'+'1\x203.304-2.'+'214\x203.374-'+'2.23.05-.0'+'12.12-.026'+'.166.016.0'+'47.041.042'+'.12.037.14'+'1-.03.129-'+'1.227\x201.24'+'1-1.846\x201.'+'817-.193.1'+'8-.33.307-'+'.358.336a8'+'.154\x208.154'+'\x200\x200\x201-.18'+'8.186c-.38'+'.366-.664.'+'64.015\x201.0'+'88.327.216'+'.589.393.8'+'5.571.284.'+'194.568.38'+'7.936.629.'+'093.06.183'+'.125.27.18'+'7.331.236.'+'63.448.997'+'.414.214-.'+'02.435-.22'+'.547-.82.2'+'65-1.417.7'+'86-4.486.9'+'06-5.751a1'+'.426\x201.426'+'\x200\x200\x200-.01'+'3-.315.337'+'.337\x200\x200\x200'+'-.114-.217'+'.526.526\x200'+'\x200\x200-.31-.'+'093c-.3.00'+'5-.763.166'+'-2.984\x201.0'+'9z\x22/>\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20</'+'svg>\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20Ari'+'sta\x20Telegr'+'am\x20Channel'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20<'+'/a>\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20<a\x20href=\x22'+'https://ar'+'ista-proxy'+'.pages.dev'+'\x22\x20target=\x22'+'_blank\x22\x20st'+'yle=\x22\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20di'+'splay:\x20fle'+'x;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20align'+'-items:\x20ce'+'nter;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20ga'+'p:\x208px;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'padding:\x201'+'0px\x2020px;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20backgrou'+'nd:\x20linear'+'-gradient('+'135deg,\x20rg'+'ba(74,\x20144'+',\x20226,\x200.2'+'),\x20rgba(66'+',\x20133,\x20214'+',\x200.3));\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20color:\x20wh'+'ite;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20tex'+'t-decorati'+'on:\x20none;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20border-r'+'adius:\x208px'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20transi'+'tion:\x20all\x20'+'0.3s\x20ease;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20border:'+'\x201px\x20solid'+'\x20rgba(74,\x20'+'144,\x20226,\x20'+'0.3);\x0a\x20\x20\x20\x20')+('\x20\x20\x20\x20\x20\x20\x20\x20fo'+'nt-weight:'+'\x20600;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x22\x20onmo'+'useover=\x22t'+'his.style.'+'transform='+'\x27translate'+'Y(-2px)\x27;t'+'his.style.'+'boxShadow='+'\x270\x206px\x2015p'+'x\x20rgba(74,'+'144,226,0.'+'3)\x27;\x22\x20\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20on'+'mouseout=\x22'+'this.style'+'.transform'+'=\x27translat'+'eY(0)\x27;thi'+'s.style.bo'+'xShadow=\x27n'+'one\x27;\x22>\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'<svg\x20xmlns'+'=\x22http://w'+'ww.w3.org/'+'2000/svg\x22\x20'+'width=\x2218\x22'+'\x20height=\x221'+'8\x22\x20fill=\x22c'+'urrentColo'+'r\x22\x20viewBox'+'=\x220\x200\x2016\x201'+'6\x22>\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'<path\x20d=\x22M'+'0\x208a8\x208\x200\x20'+'1\x201\x2016\x200A8'+'\x208\x200\x200\x201\x200'+'\x208zm7.5-6.'+'923c-.67.2'+'04-1.335.8'+'2-1.887\x201.'+'855A7.97\x207'+'.97\x200\x200\x200\x20'+'5.145\x204H7.'+'5V1.077zM4'+'.09\x204a9.26'+'7\x209.267\x200\x20'+'0\x201\x20.64-1.'+'539\x206.7\x206.'+'7\x200\x200\x201\x20.5'+'97-.933A7.'+'025\x207.025\x20'+'0\x200\x200\x202.25'+'5\x204H4.09zm'+'-.582\x203.5c'+'.03-.877.1'+'38-1.718.3'+'12-2.5H1.6'+'74a6.958\x206'+'.958\x200\x200\x200'+'-.656\x202.5h'+'2.49zM4.84'+'7\x205a12.5\x201'+'2.5\x200\x200\x200-'+'.338\x202.5H7'+'.5V5H4.847'+'zM8.5\x205v2.'+'5h2.99a12.'+'495\x2012.495'+'\x200\x200\x200-.33'+'7-2.5H8.5z'+'M4.51\x208.5a'+'12.5\x2012.5\x20'+'0\x200\x200\x20.337'+'\x202.5H7.5V8'+'.5H4.51zm3'+'.99\x200V11h2'+'.653c.187-'+'.765.306-1'+'.608.338-2'+'.5H8.5zM5.'+'145\x2012c.13'+'8.386.295.'+'744.468\x201.'+'068.552\x201.'+'035\x201.218\x20'+'1.65\x201.887'+'\x201.855V12H'+'5.145zm.18'+'2\x202.472a6.'+'696\x206.696\x20'+'0\x200\x201-.597'+'-.933A9.26'+'8\x209.268\x200\x20'+'0\x201\x204.09\x201'+'2H2.255a7.')+('024\x207.024\x20'+'0\x200\x200\x203.07'+'2\x202.472zM3'+'.82\x2011a13.'+'652\x2013.652'+'\x200\x200\x201-.31'+'2-2.5h-2.4'+'9c.062.97.'+'291\x201.87.6'+'56\x202.5H3.8'+'2zm6.853\x203'+'.472A7.024'+'\x207.024\x200\x200'+'\x200\x2013.745\x20'+'12H11.91a9'+'.27\x209.27\x200'+'\x200\x201-.64\x201'+'.539\x206.688'+'\x206.688\x200\x200'+'\x201-.597.93'+'3zM8.5\x2012v'+'2.923c.67-'+'.204\x201.335'+'-.82\x201.887'+'-1.855.173'+'-.324.33-.'+'682.468-1.'+'068H8.5zm3'+'.680-1h2.1'+'46c.365-.6'+'3.594-1.53'+'.656-2.5h-'+'2.49a13.65'+'\x2013.65\x200\x200'+'\x201-.312\x202.'+'5zm2.802-3'+'.5a6.959\x206'+'.959\x200\x200\x200'+'-.656-2.5H'+'12.18c.174'+'.782.282\x201'+'.623.312\x202'+'.5h2.49zM1'+'1.27\x202.461'+'c.247.35.4'+'62.739.64\x20'+'1.539h1.83'+'5a7.024\x207.'+'024\x200\x200\x200-'+'3.072-2.47'+'2c.218.284'+'.418.598.5'+'97.933zM10'+'.855\x204a7.9'+'66\x207.966\x200'+'\x200\x200-.468-'+'1.068C9.83'+'5\x201.897\x209.'+'17\x201.282\x208'+'.5\x201.077V4'+'h2.355z\x22/>'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20</svg>\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20Telegram'+'\x20Proxy\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20</a>\x0a'+'\x20\x20\x20\x20</div>'+'\x0a</div>\x0a<d'+'iv\x20class=\x22'+'card\x22>\x0a<di'+'v\x20class=\x22g'+'rid\x22>\x0a<div'+'>\x0a<label>C'+'onfig\x20Limi'+'t</label>\x0a'+'<select\x20id'+'=\x22limit\x22>\x0a'+'<option\x20va'+'lue=\x22all\x22>'+'All\x20Config'+'s</option>'+'\x0a<option\x20v'+'alue=\x2220\x22>'+'20\x20Configs'+'</option>\x0a'+'<option\x20va'+'lue=\x2240\x22>4'+'0\x20Configs<'+'/option>\x0a<'+'option\x20val'+'ue=\x2260\x22>60'+'\x20Configs</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22100\x22>10'+'0\x20Configs<'+'/option>\x0a<'+'/select>\x0a<'+'div\x20class=')+('\x22help-text'+'\x22>Select\x20n'+'umber\x20of\x20c'+'onfigurati'+'ons\x20to\x20gen'+'erate\x20(pri'+'ority\x20give'+'n\x20to\x20ports'+'\x202096,\x20443'+',\x208443,\x2080'+'80)</div>\x0a'+'</div>\x0a<di'+'v>\x0a<label>'+'Remote\x20DNS'+'</label>\x0a<'+'input\x20id=\x22'+'dns\x22\x20place'+'holder=\x22e.'+'g.,\x208.8.8.'+'8,1.1.1.1,'+'https://dn'+'s.google/d'+'ns-query\x22>'+'\x0a<div\x20clas'+'s=\x22help-te'+'xt\x22>Enter\x20'+'DNS\x20server'+'s\x20or\x20DoH\x20U'+'RLs\x20(comma'+'-separated'+',\x20e.g.,\x208.'+'8.8.8,1.1.'+'1.1\x20or\x20htt'+'ps://dns.g'+'oogle/dns-'+'query)</di'+'v>\x0a</div>\x0a'+'</div>\x0a\x0a<d'+'iv\x20class=\x22'+'grid\x22>\x0a<di'+'v>\x0a<label>'+'Direct\x20DNS'+'</label>\x0a<'+'input\x20id=\x22'+'direct\x22\x20pl'+'aceholder='+'\x22e.g.,\x20127'+'.0.0.1,8.8'+'.8.8\x22>\x0a<di'+'v\x20class=\x22h'+'elp-text\x22>'+'Enter\x20DNS\x20'+'servers\x20fo'+'r\x20direct\x20c'+'onnections'+'\x20(comma-se'+'parated,\x20e'+'.g.,\x20127.0'+'.0.1,8.8.8'+'.8)</div>\x0a'+'</div>\x0a<di'+'v>\x0a<label>'+'Clean\x20IP</'+'label>\x0a<in'+'put\x20id=\x22cl'+'eanip\x22\x20pla'+'ceholder=\x22'+'e.g.,\x208.21'+'9.190.62,1'+'.1.1.1\x22>\x0a<'+'div\x20class='+'\x22help-text'+'\x22>Enter\x20cl'+'ean\x20IP\x20add'+'resses\x20for'+'\x20bypass\x20(c'+'omma-separ'+'ated,\x20e.g.'+',\x208.219.19'+'0.62,1.1.1'+'.1)</div>\x0a'+'</div>\x0a</d'+'iv>\x0a\x0a<div\x20'+'class=\x22gri'+'d\x22>\x0a<div>\x0a'+'<label>Dom'+'ain</label'+'>\x0a<input\x20i'+'d=\x22domain\x22'+'\x20placehold'+'er=\x22e.g.,\x20'+'zula.ir,ex'+'ample.com\x22'+'>\x0a<div\x20cla'+'ss=\x22help-t'+'ext\x22>Enter'+'\x20domains\x20f'+'or\x20routing'+'\x20(comma-se'+'parated,\x20e')+('.g.,\x20zula.'+'ir,example'+'.com)</div'+'>\x0a</div>\x0a<'+'div>\x0a<labe'+'l>SNI</lab'+'el>\x0a<input'+'\x20id=\x22sni\x22\x20'+'placeholde'+'r=\x22e.g.,\x20e'+'xample.com'+',cloudflar'+'e.com\x22>\x0a<d'+'iv\x20class=\x22'+'help-text\x22'+'>Enter\x20Ser'+'ver\x20Name\x20I'+'ndication\x20'+'for\x20TLS\x20(c'+'omma-separ'+'ated,\x20e.g.'+',\x20example.'+'com,cloudf'+'lare.com)<'+'/div>\x0a</di'+'v>\x0a</div>\x0a'+'\x0a<div\x20clas'+'s=\x22grid\x22>\x0a'+'<div>\x0a<lab'+'el>ALPN</l'+'abel>\x0a<sel'+'ect\x20id=\x22al'+'pn\x22>\x0a<opti'+'on\x20value=\x22'+'none\x22>None'+'</option>\x0a'+'<option\x20va'+'lue=\x22h2\x22>H'+'TTP/2</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'http/1.1\x22>'+'HTTP/1.1</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22h2,http'+'/1.1\x22>HTTP'+'/2\x20+\x20HTTP/'+'1.1</optio'+'n>\x0a<option'+'\x20value=\x22h3'+'\x22>HTTP/3</'+'option>\x0a</'+'select>\x0a<d'+'iv\x20class=\x22'+'help-text\x22'+'>Applicati'+'on-Layer\x20P'+'rotocol\x20Ne'+'gotiation<'+'/div>\x0a</di'+'v>\x0a<div>\x0a<'+'label>Fing'+'erprint</l'+'abel>\x0a<sel'+'ect\x20id=\x22fi'+'ngerprint\x22'+'>\x0a<option\x20'+'value=\x22non'+'e\x22>None</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22chrome\x22>'+'Chrome</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22firefox\x22>'+'Firefox</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22safari\x22>'+'Safari</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22ios\x22>iOS<'+'/option>\x0a<'+'option\x20val'+'ue=\x22androi'+'d\x22>Android'+'</option>\x0a'+'<option\x20va'+'lue=\x22edge\x22'+'>Edge</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'360\x22>360</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22qq\x22>QQ<'+'/option>\x0a<')+('option\x20val'+'ue=\x22random'+'\x22>Random</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22randomi'+'zed\x22>Rando'+'mized</opt'+'ion>\x0a</sel'+'ect>\x0a<div\x20'+'class=\x22hel'+'p-text\x22>TL'+'S\x20client\x20f'+'ingerprint'+'</div>\x0a</d'+'iv>\x0a</div>'+'\x0a\x0a<div\x20cla'+'ss=\x22grid\x22>'+'\x0a<div>\x0a<la'+'bel>IP\x20Ver'+'sion</labe'+'l>\x0a<select'+'\x20id=\x22ipver'+'\x22>\x0a<option'+'\x20value=\x22no'+'ne\x22>None</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22ipv4\x22>I'+'Pv4</optio'+'n>\x0a<option'+'\x20value=\x22ip'+'v6\x22>IPv6</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22auto\x22>A'+'uto</optio'+'n>\x0a</selec'+'t>\x0a</div>\x0a'+'<div>\x0a<lab'+'el>Network'+'</label>\x0a<'+'select\x20id='+'\x22network\x22>'+'\x0a<option\x20v'+'alue=\x22none'+'\x22>None</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22tcp\x22>TCP<'+'/option>\x0a<'+'option\x20val'+'ue=\x22ws\x22>We'+'bSocket</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22h2\x22>HTTP'+'/2</option'+'>\x0a<option\x20'+'value=\x22grp'+'c\x22>gRPC</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22quic\x22>QU'+'IC</option'+'>\x0a<option\x20'+'value=\x22kcp'+'\x22>KCP</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'http\x22>HTTP'+'</option>\x0a'+'</select>\x0a'+'</div>\x0a</d'+'iv>\x0a\x0a<div\x20'+'class=\x22gri'+'d\x22>\x0a<div>\x0a'+'<label>TLS'+'</label>\x0a<'+'select\x20id='+'\x22tls\x22>\x0a<op'+'tion\x20value'+'=\x22none\x22>No'+'ne</option'+'>\x0a<option\x20'+'value=\x22ena'+'bled\x22>Enab'+'led</optio'+'n>\x0a<option'+'\x20value=\x22di'+'sabled\x22>Di'+'sabled</op'+'tion>\x0a</se'+'lect>\x0a</di'+'v>\x0a<div>\x0a<'+'label>UDP<'+'/label>\x0a<s'+'elect\x20id=\x22'+'udp\x22>\x0a<opt'+'ion\x20value=')+('\x22none\x22>Non'+'e</option>'+'\x0a<option\x20v'+'alue=\x22enab'+'led\x22>Enabl'+'ed</option'+'>\x0a<option\x20'+'value=\x22dis'+'abled\x22>Dis'+'abled</opt'+'ion>\x0a</sel'+'ect>\x0a</div'+'>\x0a</div>\x0a\x0a'+'<div\x20class'+'=\x22fragment'+'-section\x22>'+'\x0a<div\x20clas'+'s=\x22fragmen'+'t-toggle\x22>'+'\x0a<label\x20cl'+'ass=\x22switc'+'h\x22>\x0a<input'+'\x20type=\x22che'+'ckbox\x22\x20id='+'\x22fragment_'+'enabled\x22>\x0a'+'<span\x20clas'+'s=\x22slider\x22'+'></span>\x0a<'+'/label>\x0a<l'+'abel>Enabl'+'e\x20Fragment'+'</label>\x0a<'+'/div>\x0a\x0a<di'+'v\x20id=\x22frag'+'ment_setti'+'ngs\x22>\x0a<div'+'\x20class=\x22gr'+'id\x22>\x0a<div>'+'\x0a<label>Pa'+'ckets</lab'+'el>\x0a<input'+'\x20id=\x22frag_'+'packets\x22\x20v'+'alue=\x222-8\x22'+'>\x0a<div\x20cla'+'ss=\x22help-t'+'ext\x22>Packe'+'t\x20fragment'+'ation\x20rang'+'e</div>\x0a</'+'div>\x0a<div>'+'\x0a<label>Le'+'ngth</labe'+'l>\x0a<input\x20'+'id=\x22frag_l'+'ength\x22\x20val'+'ue=\x22100-30'+'0\x22>\x0a<div\x20c'+'lass=\x22help'+'-text\x22>Fra'+'gment\x20leng'+'th\x20range</'+'div>\x0a</div'+'>\x0a</div>\x0a\x0a'+'<div\x20class'+'=\x22grid\x22>\x0a<'+'div>\x0a<labe'+'l>Interval'+'</label>\x0a<'+'input\x20id=\x22'+'frag_inter'+'val\x22\x20value'+'=\x2210-30\x22>\x0a'+'<div\x20class'+'=\x22help-tex'+'t\x22>Fragmen'+'t\x20interval'+'\x20range</di'+'v>\x0a</div>\x0a'+'<div>\x0a<lab'+'el>Sleep</'+'label>\x0a<in'+'put\x20id=\x22fr'+'ag_sleep\x22\x20'+'value=\x2250\x22'+'>\x0a<div\x20cla'+'ss=\x22help-t'+'ext\x22>Sleep'+'\x20time\x20betw'+'een\x20fragme'+'nts\x20(ms)</'+'div>\x0a</div'+'>\x0a</div>\x0a<'+'/div>\x0a</di'+'v>\x0a\x0a<butto'+'n\x20class=\x22b'+'tn-save\x22\x20o'+'nclick=\x22sa'+'veSettings')+('()\x22>Save\x20S'+'ettings</b'+'utton>\x0a<bu'+'tton\x20class'+'=\x22btn-rese'+'t\x22\x20onclick'+'=\x22resetSet'+'tings()\x22>R'+'eset\x20Setti'+'ngs</butto'+'n>\x0a\x0a<label'+'>Subscribe'+'\x20URL\x20(V2Ra'+'y)</label>'+'\x0a<input\x20id'+'=\x22subscrib'+'e_v2ray\x22\x20r'+'eadonly>\x0a<'+'button\x20cla'+'ss=\x22btn-co'+'py\x22\x20onclic'+'k=\x22copyToC'+'lipboard(\x27'+'subscribe_'+'v2ray\x27)\x22>C'+'opy\x20V2Ray\x20'+'Subscribe<'+'/button>\x0a\x0a'+'<label>Sub'+'scribe\x20URL'+'\x20(ClashMet'+'a)</label>'+'\x0a<input\x20id'+'=\x22subscrib'+'e_clash\x22\x20r'+'eadonly>\x0a<'+'button\x20cla'+'ss=\x22btn-co'+'py\x22\x20onclic'+'k=\x22copyToC'+'lipboard(\x27'+'subscribe_'+'clash\x27)\x22>C'+'opy\x20ClashM'+'eta\x20Subscr'+'ibe</butto'+'n>\x0a\x0a<label'+'>Subscribe'+'\x20URL\x20(Sing'+'Box)</labe'+'l>\x0a<input\x20'+'id=\x22subscr'+'ibe_singbo'+'x\x22\x20readonl'+'y>\x0a<button'+'\x20class=\x22bt'+'n-copy\x22\x20on'+'click=\x22cop'+'yToClipboa'+'rd(\x27subscr'+'ibe_singbo'+'x\x27)\x22>Copy\x20'+'SingBox\x20Su'+'bscribe</b'+'utton>\x0a</d'+'iv>\x0a<foote'+'r>V\x201.3.7<'+'/footer>\x0a<'+'div\x20id=\x22al'+'ert\x22\x20class'+'=\x22alert\x22><'+'/div>\x0a</di'+'v>\x0a<script'+'>\x0afunction'+'\x20showAlert'+'(message,\x20'+'isError\x20=\x20'+'false)\x20{\x0a\x20'+'\x20\x20\x20const\x20a'+'lert\x20=\x20doc'+'ument.getE'+'lementById'+'(\x27alert\x27);'+'\x0a\x20\x20\x20\x20alert'+'.textConte'+'nt\x20=\x20messa'+'ge;\x0a\x20\x20\x20\x20al'+'ert.classN'+'ame\x20=\x20isEr'+'ror\x20?\x20\x27ale'+'rt\x20error\x27\x20'+':\x20\x27alert\x27;'+'\x0a\x20\x20\x20\x20alert'+'.classList'+'.add(\x27show'+'\x27);\x0a\x20\x20\x20\x20\x0a\x20'+'\x20\x20\x20setTime'+'out(()\x20=>\x20'+'{\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'alert.clas')+('sList.remo'+'ve(\x27show\x27)'+';\x0a\x20\x20\x20\x20},\x203'+'000);\x0a}\x0a\x0af'+'unction\x20to'+'ggleFragme'+'ntSettings'+'()\x20{\x0a\x20\x20\x20\x20c'+'onst\x20enabl'+'ed\x20=\x20docum'+'ent.getEle'+'mentById(\x27'+'fragment_e'+'nabled\x27).c'+'hecked;\x0a\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27fra'+'gment_sett'+'ings\x27).sty'+'le.display'+'\x20=\x20enabled'+'\x20?\x20\x27grid\x27\x20'+':\x20\x27none\x27;\x0a'+'}\x0a\x0aasync\x20f'+'unction\x20sa'+'veSettings'+'(){\x0a\x20\x20\x20\x20tr'+'y\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20const\x20da'+'ta\x20=\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20l'+'imit:\x20docu'+'ment.getEl'+'ementById('+'\x27limit\x27).v'+'alue,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20dn'+'s:\x20documen'+'t.getEleme'+'ntById(\x27dn'+'s\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20direct:'+'\x20document.'+'getElement'+'ById(\x27dire'+'ct\x27).value'+',\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20cleani'+'p:\x20documen'+'t.getEleme'+'ntById(\x27cl'+'eanip\x27).va'+'lue,\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20dom'+'ain:\x20docum'+'ent.getEle'+'mentById(\x27'+'domain\x27).v'+'alue,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20sn'+'i:\x20documen'+'t.getEleme'+'ntById(\x27sn'+'i\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20alpn:\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27alpn\x27)'+'.value,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'fingerprin'+'t:\x20documen'+'t.getEleme'+'ntById(\x27fi'+'ngerprint\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20ipver:\x20do'+'cument.get'+'ElementByI'+'d(\x27ipver\x27)'+'.value,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'network:\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27networ'+'k\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20tls:\x20do'+'cument.get'+'ElementByI'+'d(\x27tls\x27).v'+'alue,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20ud'+'p:\x20documen'+'t.getEleme')+('ntById(\x27ud'+'p\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20fragmen'+'t:\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20enabled:\x20'+'document.g'+'etElementB'+'yId(\x27fragm'+'ent_enable'+'d\x27).checke'+'d,\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20p'+'ackets:\x20do'+'cument.get'+'ElementByI'+'d(\x27frag_pa'+'ckets\x27).va'+'lue,\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20length:\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_l'+'ength\x27).va'+'lue,\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20interval:'+'\x20document.'+'getElement'+'ById(\x27frag'+'_interval\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20sleep'+':\x20document'+'.getElemen'+'tById(\x27fra'+'g_sleep\x27).'+'value,\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20}'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20}'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20c'+'onst\x20respo'+'nse\x20=\x20awai'+'t\x20fetch(\x27/'+'api/settin'+'gs\x27,\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20m'+'ethod:\x20\x27PO'+'ST\x27,\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20hea'+'ders:\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x27Conte'+'nt-Type\x27:\x20'+'\x27applicati'+'on/json\x27,\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20},\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20bod'+'y:\x20JSON.st'+'ringify(da'+'ta)\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20});\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20if\x20(res'+'ponse.ok)\x20'+'{\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20showAl'+'ert(\x27Setti'+'ngs\x20saved\x20'+'successful'+'ly!\x27);\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20g'+'enerateSub'+'scribe();\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20}\x20'+'else\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20s'+'howAlert(\x27'+'Error\x20savi'+'ng\x20setting'+'s!\x27,\x20true)'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'}\x0a\x20\x20\x20\x20}\x20ca'+'tch\x20(error'+')\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20showAler'+'t(\x27Error\x20s'+'aving\x20sett'+'ings!\x27,\x20tr'+'ue);\x0a\x20\x20\x20\x20}'+'\x0a}\x0a\x0aasync\x20'+'function\x20r'+'esetSettin'+'gs()\x20{\x0a\x20\x20\x20'+'\x20const\x20ale')+('rtOverlay\x20'+'=\x20document'+'.createEle'+'ment(\x27div\x27'+');\x0a\x20\x20\x20\x20ale'+'rtOverlay.'+'style.posi'+'tion\x20=\x20\x27fi'+'xed\x27;\x0a\x20\x20\x20\x20'+'alertOverl'+'ay.style.t'+'op\x20=\x20\x270\x27;\x0a'+'\x20\x20\x20\x20alertO'+'verlay.sty'+'le.left\x20=\x20'+'\x270\x27;\x0a\x20\x20\x20\x20a'+'lertOverla'+'y.style.wi'+'dth\x20=\x20\x27100'+'%\x27;\x0a\x20\x20\x20\x20al'+'ertOverlay'+'.style.hei'+'ght\x20=\x20\x27100'+'%\x27;\x0a\x20\x20\x20\x20al'+'ertOverlay'+'.style.bac'+'kgroundCol'+'or\x20=\x20\x27rgba'+'(0,\x200,\x200,\x20'+'0.7)\x27;\x0a\x20\x20\x20'+'\x20alertOver'+'lay.style.'+'display\x20=\x20'+'\x27flex\x27;\x0a\x20\x20'+'\x20\x20alertOve'+'rlay.style'+'.justifyCo'+'ntent\x20=\x20\x27c'+'enter\x27;\x0a\x20\x20'+'\x20\x20alertOve'+'rlay.style'+'.alignItem'+'s\x20=\x20\x27cente'+'r\x27;\x0a\x20\x20\x20\x20al'+'ertOverlay'+'.style.zIn'+'dex\x20=\x20\x27100'+'00\x27;\x0a\x20\x20\x20\x20\x0a'+'\x20\x20\x20\x20const\x20'+'alertBox\x20='+'\x20document.'+'createElem'+'ent(\x27div\x27)'+';\x0a\x20\x20\x20\x20aler'+'tBox.style'+'.backgroun'+'d\x20=\x20\x27linea'+'r-gradient'+'(135deg,\x20#'+'f97316\x200%,'+'\x20#ea580c\x201'+'00%)\x27;\x0a\x20\x20\x20'+'\x20alertBox.'+'style.padd'+'ing\x20=\x20\x2725p'+'x\x27;\x0a\x20\x20\x20\x20al'+'ertBox.sty'+'le.borderR'+'adius\x20=\x20\x271'+'5px\x27;\x0a\x20\x20\x20\x20'+'alertBox.s'+'tyle.boxSh'+'adow\x20=\x20\x270\x20'+'4px\x2020px\x20r'+'gba(0,\x200,\x20'+'0,\x200.3)\x27;\x0a'+'\x20\x20\x20\x20alertB'+'ox.style.c'+'olor\x20=\x20\x27wh'+'ite\x27;\x0a\x20\x20\x20\x20'+'alertBox.s'+'tyle.textA'+'lign\x20=\x20\x27ce'+'nter\x27;\x0a\x20\x20\x20'+'\x20alertBox.'+'style.maxW'+'idth\x20=\x20\x2740'+'0px\x27;\x0a\x20\x20\x20\x20'+'alertBox.s'+'tyle.width'+'\x20=\x20\x2790%\x27;\x0a'+'\x20\x20\x20\x20\x0a\x20\x20\x20\x20c'+'onst\x20messa'+'ge\x20=\x20docum'+'ent.create'+'Element(\x27p'+'\x27);\x0a\x20\x20\x20\x20me'+'ssage.text'+'Content\x20=\x20'+'\x27Are\x20you\x20s')+('ure\x20you\x20wa'+'nt\x20to\x20rese'+'t\x20all\x20sett'+'ings?\x27;\x0a\x20\x20'+'\x20\x20message.'+'style.marg'+'inBottom\x20='+'\x20\x2720px\x27;\x0a\x20'+'\x20\x20\x20message'+'.style.fon'+'tSize\x20=\x20\x271'+'6px\x27;\x0a\x20\x20\x20\x20'+'message.st'+'yle.fontWe'+'ight\x20=\x20\x2760'+'0\x27;\x0a\x20\x20\x20\x20\x0a\x20'+'\x20\x20\x20const\x20b'+'uttonConta'+'iner\x20=\x20doc'+'ument.crea'+'teElement('+'\x27div\x27);\x0a\x20\x20'+'\x20\x20buttonCo'+'ntainer.st'+'yle.displa'+'y\x20=\x20\x27flex\x27'+';\x0a\x20\x20\x20\x20butt'+'onContaine'+'r.style.ga'+'p\x20=\x20\x2715px\x27'+';\x0a\x20\x20\x20\x20butt'+'onContaine'+'r.style.ju'+'stifyConte'+'nt\x20=\x20\x27cent'+'er\x27;\x0a\x20\x20\x20\x20\x0a'+'\x20\x20\x20\x20const\x20'+'confirmBut'+'ton\x20=\x20docu'+'ment.creat'+'eElement(\x27'+'button\x27);\x0a'+'\x20\x20\x20\x20confir'+'mButton.te'+'xtContent\x20'+'=\x20\x27Yes\x27;\x0a\x20'+'\x20\x20\x20confirm'+'Button.sty'+'le.padding'+'\x20=\x20\x2710px\x202'+'0px\x27;\x0a\x20\x20\x20\x20'+'confirmBut'+'ton.style.'+'border\x20=\x20\x27'+'none\x27;\x0a\x20\x20\x20'+'\x20confirmBu'+'tton.style'+'.borderRad'+'ius\x20=\x20\x278px'+'\x27;\x0a\x20\x20\x20\x20con'+'firmButton'+'.style.bac'+'kground\x20=\x20'+'\x27linear-gr'+'adient(135'+'deg,\x20#ef44'+'44\x200%,\x20#dc'+'2626\x20100%)'+'\x27;\x0a\x20\x20\x20\x20con'+'firmButton'+'.style.col'+'or\x20=\x20\x27whit'+'e\x27;\x0a\x20\x20\x20\x20co'+'nfirmButto'+'n.style.cu'+'rsor\x20=\x20\x27po'+'inter\x27;\x0a\x20\x20'+'\x20\x20confirmB'+'utton.styl'+'e.fontWeig'+'ht\x20=\x20\x27600\x27'+';\x0a\x0a\x20\x20\x20\x20con'+'st\x20cancelB'+'utton\x20=\x20do'+'cument.cre'+'ateElement'+'(\x27button\x27)'+';\x0a\x20\x20\x20\x20canc'+'elButton.t'+'extContent'+'\x20=\x20\x27No\x27;\x0a\x20'+'\x20\x20\x20cancelB'+'utton.styl'+'e.padding\x20'+'=\x20\x2710px\x2020'+'px\x27;\x0a\x20\x20\x20\x20c'+'ancelButto'+'n.style.bo'+'rder\x20=\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20c')+('ancelButto'+'n.style.bo'+'rderRadius'+'\x20=\x20\x278px\x27;\x0a'+'\x20\x20\x20\x20cancel'+'Button.sty'+'le.backgro'+'und\x20=\x20\x27lin'+'ear-gradie'+'nt(135deg,'+'\x20#22c55e\x200'+'%,\x20#16a34a'+'\x20100%)\x27;\x0a\x20'+'\x20\x20\x20cancelB'+'utton.styl'+'e.color\x20=\x20'+'\x27white\x27;\x0a\x20'+'\x20\x20\x20cancelB'+'utton.styl'+'e.cursor\x20='+'\x20\x27pointer\x27'+';\x0a\x20\x20\x20\x20canc'+'elButton.s'+'tyle.fontW'+'eight\x20=\x20\x276'+'00\x27;\x0a\x20\x20\x20\x20\x0a'+'\x20\x20\x20\x20button'+'Container.'+'appendChil'+'d(confirmB'+'utton);\x0a\x20\x20'+'\x20\x20buttonCo'+'ntainer.ap'+'pendChild('+'cancelButt'+'on);\x0a\x20\x20\x20\x20a'+'lertBox.ap'+'pendChild('+'message);\x0a'+'\x20\x20\x20\x20alertB'+'ox.appendC'+'hild(butto'+'nContainer'+');\x0a\x20\x20\x20\x20ale'+'rtOverlay.'+'appendChil'+'d(alertBox'+');\x0a\x20\x20\x20\x20doc'+'ument.body'+'.appendChi'+'ld(alertOv'+'erlay);\x0a\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20ret'+'urn\x20new\x20Pr'+'omise((res'+'olve)\x20=>\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20c'+'onfirmButt'+'on.onclick'+'\x20=\x20()\x20=>\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.body.rem'+'oveChild(a'+'lertOverla'+'y);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20reso'+'lve(true);'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20}'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20c'+'ancelButto'+'n.onclick\x20'+'=\x20()\x20=>\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.body.remo'+'veChild(al'+'ertOverlay'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20resol'+'ve(false);'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20}'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20a'+'lertOverla'+'y.onclick\x20'+'=\x20(e)\x20=>\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20if\x20(e.t'+'arget\x20===\x20'+'alertOverl'+'ay)\x20{\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.body.remo'+'veChild(al'+'ertOverlay'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20r')+('esolve(fal'+'se);\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20}\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20};\x0a'+'\x20\x20\x20\x20}).the'+'n(async\x20(c'+'onfirmed)\x20'+'=>\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20if\x20(con'+'firmed)\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27lim'+'it\x27).value'+'\x20=\x20\x27all\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27dns'+'\x27).value\x20='+'\x20\x27\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27direct\x27)'+'.value\x20=\x20\x27'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'cleanip\x27).'+'value\x20=\x20\x27\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27d'+'omain\x27).va'+'lue\x20=\x20\x27\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27sni'+'\x27).value\x20='+'\x20\x27\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27alpn\x27).v'+'alue\x20=\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27fingerpr'+'int\x27).valu'+'e\x20=\x20\x27none\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27i'+'pver\x27).val'+'ue\x20=\x20\x27none'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'network\x27).'+'value\x20=\x20\x27n'+'one\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27tls\x27).v'+'alue\x20=\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27udp\x27).va'+'lue\x20=\x20\x27non'+'e\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27fragment_'+'enabled\x27).'+'checked\x20=\x20'+'false;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_p'+'ackets\x27).v'+'alue\x20=\x20\x272-'+'8\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27frag_leng')+('th\x27).value'+'\x20=\x20\x27100-30'+'0\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27frag_inte'+'rval\x27).val'+'ue\x20=\x20\x2710-3'+'0\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27frag_slee'+'p\x27).value\x20'+'=\x20\x2750\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20toggleF'+'ragmentSet'+'tings();\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20try\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20awai'+'t\x20fetch(\x27/'+'api/settin'+'gs\x27,\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20met'+'hod:\x20\x27POST'+'\x27,\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20headers'+':\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x27C'+'ontent-Typ'+'e\x27:\x20\x27appli'+'cation/jso'+'n\x27,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20},\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20bod'+'y:\x20JSON.st'+'ringify({}'+')\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20})'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20sh'+'owAlert(\x27S'+'ettings\x20re'+'set\x20succes'+'sfully!\x27);'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20gen'+'erateSubsc'+'ribe();\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'}\x20catch\x20(e'+'rror)\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20showAl'+'ert(\x27Error'+'\x20resetting'+'\x20settings!'+'\x27,\x20true);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20}\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20}\x20else\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20showAle'+'rt(\x27Reset\x20'+'cancelled\x27'+',\x20false);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20}\x0a'+'\x20\x20\x20\x20});\x0a}\x0a'+'\x0afunction\x20'+'generateSu'+'bscribe()\x20'+'{\x0a\x20\x20\x20\x20cons'+'t\x20baseUrl\x20'+'=\x20window.l'+'ocation.or'+'igin;\x0a\x20\x20\x20\x20'+'const\x20limi'+'t\x20=\x20docume'+'nt.getElem'+'entById(\x27l'+'imit\x27).val'+'ue;\x0a\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27subscri'+'be_v2ray\x27)'+'.value\x20=\x20b'+'aseUrl\x20+\x20\x27'+'/api/confi')+('gs?limit=\x27'+'\x20+\x20limit;\x0a'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27s'+'ubscribe_c'+'lash\x27).val'+'ue\x20=\x20baseU'+'rl\x20+\x20\x27/api'+'/configs?f'+'ormat=clas'+'h&limit=\x27\x20'+'+\x20limit;\x0a\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27su'+'bscribe_si'+'ngbox\x27).va'+'lue\x20=\x20base'+'Url\x20+\x20\x27/ap'+'i/configs?'+'format=sin'+'gbox&limit'+'=\x27\x20+\x20limit'+';\x0a}\x0a\x0aasync'+'\x20function\x20'+'copyToClip'+'board(elem'+'entId)\x20{\x0a\x20'+'\x20\x20\x20try\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20con'+'st\x20copyTex'+'t\x20=\x20docume'+'nt.getElem'+'entById(el'+'ementId);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20co'+'pyText.sel'+'ect();\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20copyT'+'ext.setSel'+'ectionRang'+'e(0,\x2099999'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20await\x20nav'+'igator.cli'+'pboard.wri'+'teText(cop'+'yText.valu'+'e);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20showAler'+'t(\x27Copied\x20'+'to\x20clipboa'+'rd!\x27);\x0a\x20\x20\x20'+'\x20}\x20catch\x20('+'error)\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20sho'+'wAlert(\x27Fa'+'iled\x20to\x20co'+'py!\x27,\x20true'+');\x0a\x20\x20\x20\x20}\x0a}'+'\x0a\x0aasync\x20fu'+'nction\x20loa'+'dSettings('+')\x20{\x0a\x20\x20\x20\x20tr'+'y\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20const\x20re'+'sponse\x20=\x20a'+'wait\x20fetch'+'(\x27/api/set'+'tings\x27);\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20con'+'st\x20s\x20=\x20awa'+'it\x20respons'+'e.json();\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20if\x20'+'(s)\x20{\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27limit\x27)'+'.value\x20=\x20s'+'.limit\x20||\x20'+'\x27all\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27dns\x27).'+'value\x20=\x20s.'+'dns\x20||\x20\x27\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27di'+'rect\x27).val'+'ue\x20=\x20s.dir'+'ect\x20||\x20\x27\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen')+('t.getEleme'+'ntById(\x27cl'+'eanip\x27).va'+'lue\x20=\x20s.cl'+'eanip\x20||\x20\x27'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'domain\x27).v'+'alue\x20=\x20s.d'+'omain\x20||\x20\x27'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'sni\x27).valu'+'e\x20=\x20s.sni\x20'+'||\x20\x27\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27alpn\x27)'+'.value\x20=\x20s'+'.alpn\x20||\x20\x27'+'none\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27finger'+'print\x27).va'+'lue\x20=\x20s.fi'+'ngerprint\x20'+'||\x20\x27none\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27ip'+'ver\x27).valu'+'e\x20=\x20s.ipve'+'r\x20||\x20\x27none'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'network\x27).'+'value\x20=\x20s.'+'network\x20||'+'\x20\x27none\x27;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27tls\x27'+').value\x20=\x20'+'s.tls\x20||\x20\x27'+'none\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27udp\x27).'+'value\x20=\x20s.'+'udp\x20||\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'if\x20(s.frag'+'ment)\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27f'+'ragment_en'+'abled\x27).ch'+'ecked\x20=\x20s.'+'fragment.e'+'nabled\x20||\x20'+'false;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27fr'+'ag_packets'+'\x27).value\x20='+'\x20s.fragmen'+'t.packets\x20'+'||\x20\x272-8\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27frag_leng'+'th\x27).value'+'\x20=\x20s.fragm'+'ent.length'+'\x20||\x20\x27100-3'+'00\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27frag')+('_interval\x27'+').value\x20=\x20'+'s.fragment'+'.interval\x20'+'||\x20\x2710-30\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27frag_sl'+'eep\x27).valu'+'e\x20=\x20s.frag'+'ment.sleep'+'\x20||\x20\x2750\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20}\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20}\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20toggleFra'+'gmentSetti'+'ngs();\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20gener'+'ateSubscri'+'be();\x0a\x20\x20\x20\x20'+'}\x20catch\x20(e'+'rror)\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20cons'+'ole.error('+'\x27Error\x20loa'+'ding\x20setti'+'ngs:\x27,\x20err'+'or);\x0a\x20\x20\x20\x20}'+'\x0a}\x0a\x0adocume'+'nt.getElem'+'entById(\x27f'+'ragment_en'+'abled\x27).ad'+'dEventList'+'ener(\x27chan'+'ge\x27,\x20toggl'+'eFragmentS'+'ettings);\x0a'+'window.onl'+'oad\x20=\x20load'+'Settings;\x0a'+'</script>\x0a'+'</body>\x0a</'+'html>');}

//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
