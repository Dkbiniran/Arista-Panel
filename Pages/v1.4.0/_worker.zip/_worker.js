// ==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------


const _0x_0x3db54c=(function(){let _0x4584fd=!![];return function(_0x4b614d,_0x35215b){const _0x17dc53=_0x4584fd?function(){if(_0x35215b){const _0x1dd88f=_0x35215b['apply'](_0x4b614d,arguments);_0x35215b=null;return _0x1dd88f;}}:function(){};_0x4584fd=![];return _0x17dc53;};}());const _0x_0x5c35fc=_0x_0x3db54c(this,function(){return _0x_0x5c35fc['toString']()['search']('(((.+)+)+)'+'+$')['toString']()['constructo'+'r'](_0x_0x5c35fc)['search']('(((.+)+)+)'+'+$');});_0x_0x5c35fc();const _0x_0x25116f=(function(){let _0x5c0df0=!![];return function(_0x294640,_0x120c5b){const _0x270421=_0x5c0df0?function(){if(_0x120c5b){const _0x2f04b1=_0x120c5b['apply'](_0x294640,arguments);_0x120c5b=null;return _0x2f04b1;}}:function(){};_0x5c0df0=![];return _0x270421;};}());const _0x_0x46caee=_0x_0x25116f(this,function(){const _0x2473e0=function(){let _0x450125;try{_0x450125=Function('return\x20(fu'+'nction()\x20'+('{}.constru'+'ctor(\x22retu'+'rn\x20this\x22)('+'\x20)')+');')();}catch(_0xc88a91){_0x450125=window;}return _0x450125;};const _0x2f1079=_0x2473e0();const _0x151a15=_0x2f1079['console']=_0x2f1079['console']||{};const _0xd795a0=['log','warn','info','error','exception','table','trace'];for(let _0x367fb9=0x0;_0x367fb9<_0xd795a0['length'];_0x367fb9++){const _0x51b7bd=_0x_0x25116f['constructo'+'r']['prototype']['bind'](_0x_0x25116f);const _0x4e0e5a=_0xd795a0[_0x367fb9];const _0x109c32=_0x151a15[_0x4e0e5a]||_0x51b7bd;_0x51b7bd['__proto__']=_0x_0x25116f['bind'](_0x_0x25116f);_0x51b7bd['toString']=_0x109c32['toString']['bind'](_0x109c32);_0x151a15[_0x4e0e5a]=_0x51b7bd;}});_0x_0x46caee();const ARISTA_TAG='ARISTA🔥';const SETTINGS_KV_KEY='settings';const CONFIG_SOURCE_URLS=['https://cd'+'n.jsdelivr'+'.net/gh/Ma'+'hsaNetConf'+'igTopic/co'+'nfig@main/'+'xray_final'+'.txt','https://cd'+'n.jsdelivr'+'.net/gh/As'+'hkan-m/v2r'+'ay@main/Su'+'b.txt','https://cd'+'n.jsdelivr'+'.net/gh/Ra'+'yan-Config'+'/C-Sub@mai'+'n/configs/'+'proxy.txt'];const ARISTA_URL='https://ra'+'w.githubus'+'ercontent.'+'com/hamedp'+'-71/Arista'+'_HP/refs/h'+'eads/main/'+'Arista.txt';const CLASH_ARISTA_URL='https://ra'+'w.githubus'+'ercontent.'+'com/hamedp'+'-71/Vless-'+'Trojan_cla'+'sh/refs/he'+'ads/main/h'+'p.yaml';let ALL_CONFIGS=[];const PORT_PRIORITIES=[0x830,0x1bb,0x20fb,0x1f90];const CONFIG_LIMITS=[0x5,0xa,0x14,0x1e,0x28,0x32,0x3c,0x64,'all'];function isIP(_0x5c7e3a){return/^(\d{1,3}\.){3}\d{1,3}$/['test'](_0x5c7e3a)||/^([0-9a-fA-F]*:){2,7}[0-9a-fA-F]*$/['test'](_0x5c7e3a);}function sortConfigsByPortPriority(_0xf65966){return _0xf65966['sort']((_0x23c40d,_0x19a4a0)=>{const _0x279d04=_0x9cbae0=>{try{const _0x228eed=new URL(_0x9cbae0);const _0x4faec6=parseInt(_0x228eed['port'])||0x1bb;const _0x2d86c2=PORT_PRIORITIES['indexOf'](_0x4faec6);return _0x2d86c2!==-0x1?_0x2d86c2:PORT_PRIORITIES['length'];}catch{return PORT_PRIORITIES['length'];}};const _0x292464=_0x279d04(_0x23c40d);const _0x1ad0a5=_0x279d04(_0x19a4a0);if(_0x292464!==_0x1ad0a5){return _0x292464-_0x1ad0a5;}try{const _0x261cec=parseInt(new URL(_0x23c40d)['port'])||0x1bb;const _0x273b7a=parseInt(new URL(_0x19a4a0)['port'])||0x1bb;return _0x261cec-_0x273b7a;}catch{return 0x0;}});}function applyConfigLimit(_0x1e06ea,_0x5576b2){if(_0x5576b2==='all')return _0x1e06ea;const _0x563f4f=parseInt(_0x5576b2);if(isNaN(_0x563f4f)||_0x563f4f<=0x0)return _0x1e06ea;const _0x2610e7=sortConfigsByPortPriority(_0x1e06ea);const _0x5728d2=_0x2610e7['filter'](_0x5b5a1a=>{try{const _0x27aef1=new URL(_0x5b5a1a);const _0x3b6819=parseInt(_0x27aef1['port'])||0x1bb;return PORT_PRIORITIES['includes'](_0x3b6819);}catch{return![];}});const _0x54d990=_0x2610e7['filter'](_0xe46e0e=>{try{const _0x29ad1f=new URL(_0xe46e0e);const _0x5d9ff8=parseInt(_0x29ad1f['port'])||0x1bb;return!PORT_PRIORITIES['includes'](_0x5d9ff8);}catch{return![];}});const _0x2d4c1a=Math['min'](_0x5728d2['length'],Math['ceil'](_0x563f4f*0.6));const _0x4340f0=Math['min'](_0x54d990['length'],_0x563f4f-_0x2d4c1a);return[..._0x5728d2['slice'](0x0,_0x2d4c1a),..._0x54d990['slice'](0x0,_0x4340f0)]['slice'](0x0,_0x563f4f);}async function updateConfigs(){try{let _0x34602d=[];for(const _0x5c0200 of CONFIG_SOURCE_URLS){const _0x29f38f=await fetch(_0x5c0200);if(!_0x29f38f['ok'])continue;const _0x3a35a8=await _0x29f38f['text']();let _0x3b340b=_0x3a35a8['split']('\x0a')['filter'](_0x40a16a=>_0x40a16a['startsWith']('vless://'));_0x34602d=_0x34602d['concat'](_0x3b340b);}ALL_CONFIGS=[...new Set(_0x34602d)];console['log']('Updated\x20co'+'nfigs:\x20'+ALL_CONFIGS['length']+('\x20unique\x20co'+'nfiguratio'+'ns\x20loaded'));}catch(_0x441991){console['error']('Error\x20upda'+'ting\x20confi'+'gs:',_0x441991);}}async function checkConfigStatus(){try{console['log']('Config\x20Sta'+'tus:',{'configsLoaded':ALL_CONFIGS['length'],'configsSample':ALL_CONFIGS['slice'](0x0,0x3)});return!![];}catch(_0x23191d){console['error']('Config\x20Sta'+'tus\x20Check\x20'+'Failed:',_0x23191d);return![];}}function applyFragmentSettings(_0x2698bc,_0x57f8b4){if(!_0x57f8b4||Object['keys'](_0x57f8b4)['length']===0x0||!_0x57f8b4['enabled']){return _0x2698bc;}try{const _0x40833b=new URL(_0x2698bc);_0x40833b['searchPara'+'ms']['set']('fragment','true');if(_0x57f8b4['packets'])_0x40833b['searchPara'+'ms']['set']('fragmentPa'+'ckets',_0x57f8b4['packets']);if(_0x57f8b4['length'])_0x40833b['searchPara'+'ms']['set']('fragmentLe'+'ngth',_0x57f8b4['length']);if(_0x57f8b4['interval'])_0x40833b['searchPara'+'ms']['set']('fragmentIn'+'terval',_0x57f8b4['interval']);if(_0x57f8b4['sleep'])_0x40833b['searchPara'+'ms']['set']('fragmentSl'+'eep',_0x57f8b4['sleep']['toString']());return _0x40833b['toString']();}catch(_0x336bbe){return _0x2698bc;}}function applyTag(_0x354ee9){try{const _0x35ab5a=new URL(_0x354ee9);_0x35ab5a['hash']=ARISTA_TAG;return _0x35ab5a['toString']();}catch{return _0x354ee9;}}function applyCustomSettings(_0x39737d,_0x1a878f){try{const _0x5ce294=new URL(_0x39737d);const _0x266272=Object['fromEntrie'+'s'](_0x5ce294['searchPara'+'ms']['entries']());const _0x51fbd9=_0x5ce294['hostname'];const _0x512964=_0x266272['sni']||_0x266272['host']||_0x51fbd9;const _0x457940=(_0x1aa832,_0x4ddb44)=>{if(_0x1a878f[_0x1aa832]&&_0x1a878f[_0x1aa832]!=='none'){return _0x1a878f[_0x1aa832];}return _0x266272[_0x4ddb44]||undefined;};if(_0x1a878f['dns']&&_0x1a878f['dns']!=='none'){_0x5ce294['searchPara'+'ms']['set']('dns',_0x1a878f['dns']);}if(_0x1a878f['direct']&&_0x1a878f['direct']!=='none'){_0x5ce294['searchPara'+'ms']['set']('direct',_0x1a878f['direct']);}const _0xc558a=_0x457940('cleanip','cleanip');const _0x4ddd9b=(_0xc558a||'')['split'](',')['map'](_0x14fda9=>_0x14fda9['trim']())['filter'](Boolean);if(_0x4ddd9b['length']>0x0){_0x5ce294['hostname']=_0x4ddd9b[0x0];}const _0x1e5357=_0x457940('domain','domain');const _0x43feb0=_0x457940('domain','host')||_0x1e5357;if(_0x43feb0&&_0x43feb0!=='none'){_0x5ce294['searchPara'+'ms']['set']('host',_0x43feb0);_0x5ce294['searchPara'+'ms']['set']('domain',_0x43feb0);}const _0x5eb28d=_0x457940('sni','sni');const _0x386e84=(_0x5eb28d||'')['split'](',')['map'](_0x5134de=>_0x5134de['trim']())['filter'](Boolean);let _0x5a05f0=_0x386e84[0x0]||_0x1e5357||_0x43feb0||_0x512964;if(_0x4ddd9b['length']>0x0&&isIP(_0x5ce294['hostname'])){if(!_0x5a05f0||isIP(_0x5a05f0)){_0x5a05f0=_0x512964||'cloudflare'+'.com';}_0x5ce294['searchPara'+'ms']['set']('sni',_0x5a05f0);}else if(_0x5eb28d&&_0x5eb28d!=='none'){_0x5ce294['searchPara'+'ms']['set']('sni',_0x5eb28d);}else if(_0x43feb0&&_0x43feb0!=='none'){_0x5ce294['searchPara'+'ms']['set']('sni',_0x43feb0);}if(_0x1a878f['alpn']&&_0x1a878f['alpn']!=='none'){_0x5ce294['searchPara'+'ms']['set']('alpn',_0x1a878f['alpn']);}if(_0x1a878f['ipver']&&_0x1a878f['ipver']!=='none'){_0x5ce294['searchPara'+'ms']['set']('ipver',_0x1a878f['ipver']);}if(_0x1a878f['network']&&_0x1a878f['network']!=='none'){_0x5ce294['searchPara'+'ms']['set']('type',_0x1a878f['network']);}if(_0x1a878f['tls']&&_0x1a878f['tls']!=='none'){_0x5ce294['searchPara'+'ms']['set']('security',_0x1a878f['tls']==='enabled'?'tls':'none');}if(_0x1a878f['udp']&&_0x1a878f['udp']!=='none'){_0x5ce294['searchPara'+'ms']['set']('udp',_0x1a878f['udp']==='enabled'?'true':'false');}if(_0x1a878f['fingerprin'+'t']&&_0x1a878f['fingerprin'+'t']!=='none'){_0x5ce294['searchPara'+'ms']['set']('fp',_0x1a878f['fingerprin'+'t']);}return _0x5ce294['toString']();}catch(_0x36fe3d){return _0x39737d;}}function vlessToClashMeta(_0x5c67c5,_0x4d045f,_0x2e88bc,_0x5a1220){try{const _0x4c21ec=new URL(_0x5c67c5);const _0x40c3df=Object['fromEntrie'+'s'](_0x4c21ec['searchPara'+'ms']['entries']());const _0x2a24df='ARISTA🔥-'+_0x2e88bc;const _0x397699=(_0x391405,_0x114bb2)=>{if(_0x5a1220[_0x391405]&&_0x5a1220[_0x391405]!=='none'){return _0x5a1220[_0x391405];}return _0x40c3df[_0x114bb2]||undefined;};const _0x517534=(_0x47fe9f,_0x27c24c)=>{if(_0x5a1220[_0x47fe9f]&&_0x5a1220[_0x47fe9f]!=='none'){return _0x5a1220[_0x47fe9f]==='enabled';}return _0x40c3df[_0x27c24c]==='true'||undefined;};const _0x42a6b0=_0x397699('network','type')||'tcp';const _0x52e671=_0x517534('tls','security');const _0x3fa5dd=_0x517534('udp','udp')!==![];const _0x5debe0=_0x397699('cleanip','cleanip');const _0x19be98=(_0x5debe0||'')['split'](',')['map'](_0x576ffb=>_0x576ffb['trim']())['filter'](Boolean);const _0x520bc1=_0x397699('domain','domain');const _0x501f10=_0x397699('domain','host')||_0x520bc1;const _0x45f31c=isIP(_0x4c21ec['hostname'])?_0x4c21ec['hostname']:_0x19be98[0x0]||_0x520bc1||_0x4c21ec['hostname'];let _0xec833e=_0x520bc1||_0x40c3df['host']||_0x397699('sni','sni')||_0x4c21ec['hostname'];if(isIP(_0x45f31c)&&isIP(_0xec833e)){_0xec833e=_0x40c3df['host']||_0x4c21ec['hostname']||'cloudflare'+'.com';}const _0x38b892=_0x397699('fingerprin'+'t','fp')||'chrome';const _0x18ee81=_0x397699('alpn','alpn');const _0x49a543={'name':_0x2a24df,'type':'vless','server':_0x45f31c,'port':parseInt(_0x4c21ec['port'])||0x1bb,'uuid':_0x4c21ec['username']['split']('@')[0x0],'network':_0x42a6b0,'tls':_0x52e671!==![],'udp':_0x3fa5dd,'skip-cert-verify':![],'tcp-fast-open':!![],'fast-open':!![],'servername':_0xec833e,'flow':_0x40c3df['flow']||'','client-fingerprint':_0x38b892,'packet-encoding':'xudp'};if(_0x5a1220['dns']&&_0x5a1220['dns']!=='none'){_0x49a543['dns']=_0x5a1220['dns']['split'](',')['map'](_0x3d0525=>_0x3d0525['trim']());}if(_0x5a1220['direct']&&_0x5a1220['direct']!=='none'){if(_0x49a543['dns']){if(!_0x49a543['fallback-d'+'ns']){_0x49a543['fallback-d'+'ns']=_0x5a1220['direct']['split'](',')['map'](_0x5cdaf2=>_0x5cdaf2['trim']());}}else{_0x49a543['dns']=_0x5a1220['direct']['split'](',')['map'](_0x3bc363=>_0x3bc363['trim']());}}if(_0x18ee81&&_0x18ee81!=='none'){_0x49a543['alpn']=_0x18ee81['split'](',')['map'](_0x1d782c=>_0x1d782c['trim']());}else if(_0x52e671){_0x49a543['alpn']=['h2','http/1.1'];}if(_0x5a1220['fragment']&&_0x5a1220['fragment']['enabled']){_0x49a543['fragment']={'enabled':!![],'packets':_0x5a1220['fragment']['packets']||_0x40c3df['fragmentPa'+'ckets']||'2-5','length':_0x5a1220['fragment']['length']||_0x40c3df['fragmentLe'+'ngth']||'100-200','interval':_0x5a1220['fragment']['interval']||_0x40c3df['fragmentIn'+'terval']||'10-20','sleep':parseInt(_0x5a1220['fragment']['sleep']||_0x40c3df['fragmentSl'+'eep']||'10')};}if(_0x42a6b0==='ws'){const _0x244651={};_0x244651['Host']=_0xec833e;_0x244651['User-Agent']='Mozilla/5.'+'0\x20(Windows'+'\x20NT\x2010.0;\x20'+'Win64;\x20x64'+')\x20AppleWeb'+'Kit/537.36';_0x49a543['ws-opts']={'path':_0x40c3df['path']||'/','headers':_0x244651,'max-early-data':parseInt(_0x40c3df['maxEarlyDa'+'ta'])||0x800,'early-data-header-name':_0x40c3df['earlyDataH'+'eaderName']||'Sec-WebSoc'+'ket-Protoc'+'ol'};}if(_0x42a6b0==='grpc'){const _0x30c705={};_0x30c705['grpc-servi'+'ce-name']=_0x520bc1||_0x40c3df['serviceNam'+'e']||'GunService';_0x30c705['grpc-mode']='gun';_0x49a543['grpc-opts']=_0x30c705;}if(_0x42a6b0==='http'){const _0x69a1bb={};_0x69a1bb['Host']=_0xec833e;_0x69a1bb['User-Agent']='Mozilla/5.'+'0\x20(Windows'+'\x20NT\x2010.0;\x20'+'Win64;\x20x64'+')\x20AppleWeb'+'Kit/537.36';const _0x910beb={};_0x910beb['method']=_0x40c3df['method']||'GET';_0x910beb['path']=_0x40c3df['path']||'/';_0x910beb['headers']=_0x69a1bb;_0x49a543['http-opts']=_0x910beb;}if(_0x42a6b0==='quic'){const _0xdb75a1={};_0xdb75a1['security']=_0x40c3df['quicSecuri'+'ty']||'none';_0xdb75a1['key']=_0x40c3df['key']||'';_0xdb75a1['type']=_0x40c3df['headerType']||'none';_0x49a543['quic-opts']=_0xdb75a1;}if(_0x40c3df['security']==='reality'){const _0x46bb24={};_0x46bb24['public-key']=_0x40c3df['pbk']||'';_0x46bb24['short-id']=_0x40c3df['sid']||'';_0x49a543['reality-op'+'ts']=_0x46bb24;}if(_0x5a1220['ipver']&&_0x5a1220['ipver']!=='none'){_0x49a543['ipversion']=_0x5a1220['ipver'];}return _0x49a543;}catch(_0x306f7b){console['error']('Error\x20in\x20v'+'lessToClas'+'hMeta:',_0x306f7b);return null;}}function generateSingBoxConfig(_0xf90f60,_0x5e4a57){const _0x4be5e2=[];const _0x1f4877=[];_0xf90f60['forEach']((_0x2b722e,_0x3176a5)=>{try{const _0x257890=new URL(_0x2b722e);if(_0x257890['username']&&_0x257890['hostname']&&_0x257890['port']){const _0x363480=vlessToSingBox(_0x2b722e,_0x3176a5+0x1,_0x5e4a57);if(_0x363480){_0x4be5e2['push'](_0x363480);_0x1f4877['push'](_0x363480['tag']);}}}catch(_0x14e769){console['error']('Invalid\x20co'+'nfig\x20skipp'+'ed:',_0x14e769);}});if(_0x1f4877['length']===0x0){const _0x3722f8={};_0x3722f8['level']='info';_0x3722f8['timestamp']=!![];const _0x44e747={};_0x44e747['type']='direct';_0x44e747['tag']='direct';const _0x2d8fd1={};_0x2d8fd1['rules']=[];const _0x57f26d={};_0x57f26d['log']=_0x3722f8;_0x57f26d['inbounds']=[];_0x57f26d['outbounds']=[_0x44e747];_0x57f26d['route']=_0x2d8fd1;return _0x57f26d;}const _0x3937ad={};_0x3937ad['type']='selector';_0x3937ad['tag']='select';_0x3937ad['outbounds']=['auto','direct',..._0x1f4877];_0x3937ad['default']='auto';const _0xbedd4c={};_0xbedd4c['type']='urltest';_0xbedd4c['tag']='auto';_0xbedd4c['outbounds']=[..._0x1f4877];_0xbedd4c['url']='http://www'+'.gstatic.c'+'om/generat'+'e_204';_0xbedd4c['interval']='10m0s';_0xbedd4c['tolerance']=0x32;const _0x402f69=[_0x3937ad,_0xbedd4c];function _0x49ef78(_0x4a0ffd,_0x15b2c6=null,_0x4f2b7f=undefined){_0x4a0ffd=(_0x4a0ffd||'')['toString']()['trim']();if(!_0x4a0ffd)return null;if(_0x4a0ffd==='local'||_0x4a0ffd==='local-dns'){const _0x9b60fe={};_0x9b60fe['type']='local';_0x9b60fe['tag']=_0x15b2c6;_0x9b60fe['detour']=_0x4f2b7f;return _0x9b60fe;}if(_0x4a0ffd==='fakeip'){const _0x45fa1b={};_0x45fa1b['type']='fakeip';_0x45fa1b['tag']=_0x15b2c6;_0x45fa1b['inet4_rang'+'e']='198.18.0.0'+'/15';_0x45fa1b['inet6_rang'+'e']='fc00::/18';_0x45fa1b['detour']=_0x4f2b7f;return _0x45fa1b;}if(_0x4a0ffd['startsWith']('dhcp://')){const _0x1345f8=_0x4a0ffd['split']('://')[0x1]||'';const _0x83566a=_0x1345f8==='auto'?undefined:_0x1345f8;const _0x476a72={};_0x476a72['type']='dhcp';_0x476a72['tag']=_0x15b2c6;_0x476a72['detour']=_0x4f2b7f;const _0x55e776=_0x476a72;if(_0x83566a)_0x55e776['interface']=_0x83566a;return _0x55e776;}const _0x4dedfe=_0x4a0ffd['toLowerCas'+'e']();const _0x3809fb=_0x4dedfe['match'](/^([a-z0-9+.-]+):\/\/(.+)$/);if(_0x3809fb){const _0x5b13b9=_0x3809fb[0x1];const _0x3fed45=_0x4a0ffd['substring'](_0x5b13b9['length']+0x3);let _0xb6e11c=_0x3fed45['split']('/')[0x0];_0xb6e11c=_0xb6e11c['trim']();switch(_0x5b13b9){case'udp':case'tcp':case'tls':case'quic':case'h3':case'https':case'http3':const _0x922738={};_0x922738['type']=_0x5b13b9==='http3'?'h3':_0x5b13b9;_0x922738['server']=_0xb6e11c;_0x922738['tag']=_0x15b2c6;_0x922738['detour']=_0x4f2b7f;return _0x922738;default:const _0x3c60a4={};_0x3c60a4['type']='udp';_0x3c60a4['server']=_0x4a0ffd;_0x3c60a4['tag']=_0x15b2c6;_0x3c60a4['detour']=_0x4f2b7f;return _0x3c60a4;}}const _0x543cb0={};_0x543cb0['type']='udp';_0x543cb0['server']=_0x4a0ffd;_0x543cb0['tag']=_0x15b2c6;_0x543cb0['detour']=_0x4f2b7f;return _0x543cb0;}function _0x495274(_0x76f37b,_0x41c7c9='dns'){if(!_0x76f37b)return[];const _0x12cf00=Array['isArray'](_0x76f37b)?_0x76f37b:_0x76f37b['toString']()['split'](',');const _0x1ec9fd=[];for(let _0x24e035=0x0;_0x24e035<_0x12cf00['length'];_0x24e035++){const _0xe60003=_0x12cf00[_0x24e035]['trim']();if(!_0xe60003)continue;const _0x329aaa=''+_0x41c7c9+(_0x24e035===0x0?'':'-'+(_0x24e035+0x1));const _0x36e2fd=_0x49ef78(_0xe60003,_0x329aaa);if(_0x36e2fd)_0x1ec9fd['push'](_0x36e2fd);}return _0x1ec9fd;}const _0x37144f=_0x495274(_0x5e4a57['direct']&&_0x5e4a57['direct']!=='none'?_0x5e4a57['direct']:'8.8.8.8','direct-dns');const _0x1781c9=_0x495274(_0x5e4a57['dns']&&_0x5e4a57['dns']!=='none'?_0x5e4a57['dns']:'8.8.8.8','proxy-dns');const _0x27f663={};_0x27f663['type']='udp';_0x27f663['server']='8.8.8.8';_0x27f663['tag']='direct-dns';if(_0x37144f['length']===0x0)_0x37144f['push'](_0x27f663);const _0x3d2990={};_0x3d2990['type']='udp';_0x3d2990['server']='8.8.8.8';_0x3d2990['tag']='proxy-dns';if(_0x1781c9['length']===0x0)_0x1781c9['push'](_0x3d2990);const _0x38acab={};_0x38acab['level']='info';_0x38acab['timestamp']=!![];const _0x515b89={};_0x515b89['type']='local';_0x515b89['tag']='local-dns';_0x515b89['detour']='direct';const _0x2dfc3c={};_0x2dfc3c['clash_mode']='Global';_0x2dfc3c['server']='proxy-dns';const _0x42d7e8={};_0x42d7e8['source_ip_'+'cidr']=[_0x5e4a57['tun_ipv4_c'+'idr']||'172.19.0.0'+'/30',_0x5e4a57['tun_ipv6_c'+'idr']||'fdfe:dcba:'+'9876::1/12'+'6'];_0x42d7e8['server']='direct-dns';const _0x3843bf={};_0x3843bf['clash_mode']='Direct';_0x3843bf['server']='direct-dns';const _0x2f686b={};_0x2f686b['rule_set']=['geosite-ir','geoip-ir'];_0x2f686b['server']='direct-dns';const _0x13bf66={};_0x13bf66['domain_suf'+'fix']='.ir';_0x13bf66['server']='direct-dns';const _0x5ad981={};_0x5ad981['type']='tun';_0x5ad981['tag']='tun-in';_0x5ad981['interface_'+'name']='tun0';_0x5ad981['mtu']=0x5dc;_0x5ad981['address']=[_0x5e4a57['tun_inet4']||'172.19.0.1'+'/30',_0x5e4a57['tun_inet6']||'fdfe:dcba:'+'9876::1/12'+'6'];_0x5ad981['auto_route']=!![];_0x5ad981['strict_rou'+'te']=![];_0x5ad981['stack']='mixed';_0x5ad981['sniff']=!![];const _0x449de1={};_0x449de1['type']='direct';_0x449de1['tag']='direct';const _0x49748b={};_0x49748b['type']='block';_0x49748b['tag']='block';const _0x4e40fa={};_0x4e40fa['action']='sniff';const _0xf9017a={};_0xf9017a['clash_mode']='Direct';_0xf9017a['outbound']='direct';const _0x158d05={};_0x158d05['clash_mode']='Global';_0x158d05['outbound']='select';const _0x704272={};_0x704272['protocol']='dns';_0x704272['action']='hijack-dns';const _0x2ecb38={};_0x2ecb38['rule_set']=['geoip-priv'+'ate','geosite-pr'+'ivate','geosite-ir','geoip-ir'];_0x2ecb38['outbound']='direct';const _0x4ae464={};_0x4ae464['rule_set']='geosite-ad'+'s';_0x4ae464['action']='reject';const _0x4928d5={};_0x4928d5['type']='remote';_0x4928d5['tag']='geosite-ad'+'s';_0x4928d5['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'osite/cate'+'gory-ads-a'+'ll.srs';_0x4928d5['download_d'+'etour']='direct';const _0x427479={};_0x427479['type']='remote';_0x427479['tag']='geosite-pr'+'ivate';_0x427479['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'osite/priv'+'ate.srs';_0x427479['download_d'+'etour']='direct';const _0x35a994={};_0x35a994['type']='remote';_0x35a994['tag']='geosite-ir';_0x35a994['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'osite/cate'+'gory-ir.sr'+'s';_0x35a994['download_d'+'etour']='direct';const _0x3ecc83={};_0x3ecc83['type']='remote';_0x3ecc83['tag']='geoip-priv'+'ate';_0x3ecc83['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'oip/privat'+'e.srs';_0x3ecc83['download_d'+'etour']='direct';const _0x49c0d1={};_0x49c0d1['type']='remote';_0x49c0d1['tag']='geoip-ir';_0x49c0d1['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'oip/ir.srs';_0x49c0d1['download_d'+'etour']='direct';const _0x31e8d4={};_0x31e8d4['rules']=[_0x4e40fa,_0xf9017a,_0x158d05,_0x704272,_0x2ecb38,_0x4ae464];_0x31e8d4['rule_set']=[_0x4928d5,_0x427479,_0x35a994,_0x3ecc83,_0x49c0d1];_0x31e8d4['final']='select';_0x31e8d4['auto_detec'+'t_interfac'+'e']=!![];_0x31e8d4['default_do'+'main_resol'+'ver']='local-dns';const _0x5762af={'log':_0x38acab,'dns':{'servers':[..._0x37144f['map']((_0xa6f64c,_0x1ca871)=>{if(!_0xa6f64c['tag'])_0xa6f64c['tag']='direct-dns'+(_0x1ca871===0x0?'':'-'+(_0x1ca871+0x1));if(_0xa6f64c['tag']&&_0xa6f64c['tag']['startsWith']('proxy-dns')){_0xa6f64c['detour']='select';}if(['https','tls','h3','quic']['includes'](_0xa6f64c['type'])){_0xa6f64c['domain_res'+'olver']='local-dns';}return _0xa6f64c;}),..._0x1781c9['map']((_0x5b3c10,_0x1e93d7)=>{if(!_0x5b3c10['tag'])_0x5b3c10['tag']='proxy-dns'+(_0x1e93d7===0x0?'':'-'+(_0x1e93d7+0x1));if(_0x5b3c10['tag']&&_0x5b3c10['tag']['startsWith']('proxy-dns'))_0x5b3c10['detour']='select';if(['https','tls','h3','quic']['includes'](_0x5b3c10['type'])){_0x5b3c10['domain_res'+'olver']='local-dns';}return _0x5b3c10;}),_0x515b89],'rules':[_0x2dfc3c,_0x42d7e8,_0x3843bf,_0x2f686b,_0x13bf66],'final':'local-dns','strategy':'prefer_ipv'+'4','independent_cache':!![]},'inbounds':[_0x5ad981],'outbounds':[_0x449de1,_0x49748b,..._0x402f69,..._0x4be5e2],'route':_0x31e8d4};return _0x5762af;}function vlessToSingBox(_0x8623ec,_0x6a7063,_0xb0626b){try{const _0x200573=new URL(_0x8623ec);const _0x3f8e9e=Object['fromEntrie'+'s'](_0x200573['searchPara'+'ms']['entries']());const _0xf40742='ARISTA-'+(_0x6a7063+0x1);const _0x22a321=(_0x207702,_0x271e47)=>{if(_0xb0626b[_0x207702]&&_0xb0626b[_0x207702]!=='none'){return _0xb0626b[_0x207702];}return _0x3f8e9e[_0x271e47]||undefined;};const _0x4f7a98=_0x22a321('cleanip','cleanip');const _0x4982d4=(_0x4f7a98||'')['split'](',')['map'](_0x3f78d8=>_0x3f78d8['trim']())['filter'](Boolean);const _0x7f2e2a=_0x22a321('domain','domain');const _0x2cbed8=_0x22a321('domain','host')||_0x7f2e2a;const _0x2ca237=_0x22a321('sni','sni');const _0x3609e6=_0x22a321('fingerprin'+'t','fp');const _0x5ce610=_0x22a321('alpn','alpn');const _0x22d30a=_0x22a321('network','type');const _0x16bc87=_0x22a321('tls','security');const _0x35c87b=_0x22a321('udp','udp');const _0x242ee7=_0x22a321('ipver','ipver');const _0x2ab4d4=isIP(_0x200573['hostname'])?_0x200573['hostname']:_0x4982d4[0x0]||_0x200573['hostname'];let _0x1c8fb2=_0x2ca237||_0x7f2e2a||_0x2cbed8||_0x3f8e9e['sni']||_0x3f8e9e['host']||_0x200573['hostname'];if(isIP(_0x2ab4d4)&&(!_0x1c8fb2||isIP(_0x1c8fb2)||!_0x1c8fb2['includes']('.'))){_0x1c8fb2=_0x7f2e2a||_0x2cbed8||_0x3f8e9e['host']||_0x200573['hostname']||'cloudflare'+'.com';}const _0x556cb5={};_0x556cb5['enabled']=!![];_0x556cb5['fingerprin'+'t']=_0x3609e6||'chrome';const _0x2f27e8={};_0x2f27e8['enabled']=!![];_0x2f27e8['server_nam'+'e']=_0x1c8fb2;_0x2f27e8['insecure']=![];_0x2f27e8['utls']=_0x556cb5;const _0x3a6bee={'type':'vless','tag':_0xf40742,'server':_0x2ab4d4,'server_port':parseInt(_0x200573['port'])||0x1bb,'uuid':_0x200573['username'],'packet_encoding':'xudp','tls':_0x2f27e8};if(_0x3f8e9e['flow']){_0x3a6bee['flow']=_0x3f8e9e['flow'];}if(_0x5ce610&&_0x5ce610!=='none'){_0x3a6bee['tls']['alpn']=_0x5ce610['split'](',')['map'](_0xc64421=>_0xc64421['trim']());}if(_0x35c87b&&_0x35c87b!=='none'){_0x3a6bee['udp']=_0x35c87b==='enabled';}if(_0x242ee7&&_0x242ee7!=='none'){_0x3a6bee['domain_str'+'ategy']=_0x242ee7;}const _0x45982e=_0x22d30a&&_0x22d30a!=='none'?_0x22d30a:_0x3f8e9e['type']||'tcp';if(_0x45982e==='ws'){const _0x1640a1={};_0x1640a1['Host']=_0x1c8fb2;const _0x3396f6={};_0x3396f6['type']='ws';_0x3396f6['path']=_0x3f8e9e['path']||'/';_0x3396f6['headers']=_0x1640a1;_0x3a6bee['transport']=_0x3396f6;}else if(_0x45982e==='grpc'){const _0x2246c4={};_0x2246c4['type']='grpc';_0x2246c4['service_na'+'me']=_0x7f2e2a||_0x3f8e9e['serviceNam'+'e']||'GunService';_0x3a6bee['transport']=_0x2246c4;}else if(_0x45982e==='http'){const _0x20830b={};_0x20830b['type']='http';_0x20830b['host']=[_0x1c8fb2];_0x20830b['path']=_0x3f8e9e['path']||'/';_0x3a6bee['transport']=_0x20830b;}if(_0x16bc87==='disabled'){const _0xcddaec={};_0xcddaec['enabled']=![];_0x3a6bee['tls']=_0xcddaec;}if(_0x3f8e9e['security']==='reality'){const _0x2cae14={};_0x2cae14['enabled']=!![];_0x2cae14['public_key']=_0x3f8e9e['pbk']||'';_0x2cae14['short_id']=_0x3f8e9e['sid']||'';_0x3a6bee['tls']['reality']=_0x2cae14;}return _0x3a6bee;}catch(_0x4dd3af){console['error']('Error\x20conv'+'erting\x20VLE'+'SS\x20to\x20Sing'+'Box:',_0x4dd3af);return null;}}export default{async 'scheduled'(_0x290149,_0x22d144,_0x24e855){if(_0x290149['cron']==='0\x20*/3\x20*\x20*\x20'+'*'){_0x24e855['waitUntil'](updateConfigs());}},async 'fetch'(_0x340953,_0x1cdc0d,_0x5072f5){const _0x36eca5=new URL(_0x340953['url']);if(_0x36eca5['pathname']==='/'){const _0x19bdb9={};_0x19bdb9['content-ty'+'pe']='text/html;'+'charset=ut'+'f-8';_0x19bdb9['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x69380={};_0x69380['headers']=_0x19bdb9;return new Response(getHTML(),_0x69380);}if(_0x36eca5['pathname']==='/api/setti'+'ngs'){if(_0x340953['method']==='POST'){try{const _0x172de6=await _0x340953['json']();await _0x1cdc0d['KV']['put'](SETTINGS_KV_KEY,JSON['stringify'](_0x172de6));const _0x5b4ae5={};_0x5b4ae5['ok']=!![];const _0x391fa2={};_0x391fa2['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';const _0x5c09e5={};_0x5c09e5['headers']=_0x391fa2;return new Response(JSON['stringify'](_0x5b4ae5),_0x5c09e5);}catch(_0x1c64e8){const _0x3faea4={};_0x3faea4['error']='Invalid\x20JS'+'ON';const _0x19f1f3={};_0x19f1f3['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';const _0x49cd4c={};_0x49cd4c['status']=0x190;_0x49cd4c['headers']=_0x19f1f3;return new Response(JSON['stringify'](_0x3faea4),_0x49cd4c);}}else{try{const _0x48b591=await _0x1cdc0d['KV']['get'](SETTINGS_KV_KEY);const _0x4a5cfe={};_0x4a5cfe['content-ty'+'pe']='applicatio'+'n/json';_0x4a5cfe['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x2daf99={};_0x2daf99['headers']=_0x4a5cfe;return new Response(_0x48b591||'{}',_0x2daf99);}catch(_0x3aba3d){const _0x321c3e={};_0x321c3e['content-ty'+'pe']='applicatio'+'n/json';const _0x1660f6={};_0x1660f6['headers']=_0x321c3e;return new Response('{}',_0x1660f6);}}}if(_0x36eca5['pathname']==='/api/confi'+'gs'){try{if(ALL_CONFIGS['length']===0x0){await updateConfigs();}let _0x11e516=[...ALL_CONFIGS];if(_0x11e516['length']===0x0){const _0x1c44e6={};_0x1c44e6['status']=0x194;return new Response('No\x20configu'+'rations\x20fo'+'und',_0x1c44e6);}const _0x1a008e=await _0x1cdc0d['KV']['get'](SETTINGS_KV_KEY);const _0x263b82=_0x1a008e?JSON['parse'](_0x1a008e):{};const _0x1b36c8=_0x263b82['limit']||'all';_0x11e516=applyConfigLimit(_0x11e516,_0x1b36c8);const _0x45e989=(_0x263b82['cleanip']||'')['split'](',')['map'](_0x7b6f58=>_0x7b6f58['trim']())['filter'](Boolean);const _0x508726=(_0x263b82['sni']||'')['split'](',')['map'](_0x5a8d59=>_0x5a8d59['trim']())['filter'](Boolean);let _0x4b179c=[];if(_0x45e989['length']>0x1){_0x11e516['forEach']((_0x1190d7,_0x41f45c)=>{_0x45e989['forEach']((_0x2565f1,_0x170f4f)=>{let _0x45a73c=_0x1190d7;const _0x109341={..._0x263b82};const _0x5ef0ad=_0x109341;_0x5ef0ad['cleanip']=_0x2565f1;if(_0x508726[_0x170f4f]){_0x5ef0ad['sni']=_0x508726[_0x170f4f];}else if(_0x508726['length']>0x0){_0x5ef0ad['sni']=_0x508726[_0x508726['length']-0x1];}_0x45a73c=applyCustomSettings(_0x45a73c,_0x5ef0ad);if(_0x263b82['fragment']&&_0x263b82['fragment']['enabled']){_0x45a73c=applyFragmentSettings(_0x45a73c,_0x263b82['fragment']);}_0x4b179c['push'](applyTag(_0x45a73c));});});}else{_0x4b179c=_0x11e516['map'](_0x4ea10a=>{let _0x2ca9eb=_0x4ea10a;_0x2ca9eb=applyCustomSettings(_0x2ca9eb,_0x263b82);if(_0x263b82['fragment']&&_0x263b82['fragment']['enabled']){_0x2ca9eb=applyFragmentSettings(_0x2ca9eb,_0x263b82['fragment']);}return applyTag(_0x2ca9eb);});}_0x11e516=_0x4b179c;const _0x48c533=_0x36eca5['searchPara'+'ms']['get']('format')||'v2ray';if(_0x48c533==='clash'){const _0x5cf93d={};_0x5cf93d['geoip']=!![];_0x5cf93d['geoip-code']='IR';_0x5cf93d['ipcidr']=['0.0.0.0/8','127.0.0.0/'+'8','10.0.0.0/8','172.16.0.0'+'/12','192.168.0.'+'0/16'];const _0x5a34ee={'port':0x1ed2,'socks-port':0x1ed3,'mixed-port':0x1ed5,'mode':'rule','log-level':'info','dns':{'enable':!![],'listen':':53','enhanced-mode':'fake-ip','fake-ip-range':'198.18.0.1'+'/16','fake-ip-filter':['*.lan','*.local','*.localhos'+'t','*.ir','*.test'],'nameserver':_0x263b82['dns']&&_0x263b82['dns']!=='none'?_0x263b82['dns']['split'](',')['map'](_0x626331=>_0x626331['trim']()):['78.157.42.'+'100','78.157.42.'+'101','10.202.10.'+'10','8.8.8.8','1.1.1.1'],'fallback':_0x263b82['direct']&&_0x263b82['direct']!=='none'?_0x263b82['direct']['split'](',')['map'](_0x334d0a=>_0x334d0a['trim']()):['10.202.10.'+'11','78.157.42.'+'100','8.8.4.4'],'fallback-filter':_0x5cf93d},'proxies':[],'proxy-groups':[],'rules':['DOMAIN-SUF'+'FIX,google'+'.com,ARIST'+'A\x20Auto','DOMAIN-SUF'+'FIX,youtub'+'e.com,ARIS'+'TA\x20Auto','DOMAIN-SUF'+'FIX,github'+'.com,ARIST'+'A\x20Auto','DOMAIN-KEY'+'WORD,teleg'+'ram,ARISTA'+'\x20Auto','DOMAIN-SUF'+'FIX,instag'+'ram.com,AR'+'ISTA\x20Auto','DOMAIN-SUF'+'FIX,twitte'+'r.com,ARIS'+'TA\x20Auto','DOMAIN-SUF'+'FIX,whatsa'+'pp.com,ARI'+'STA\x20Auto','DOMAIN-SUF'+'FIX,cdn.ir'+',DIRECT','DOMAIN-SUF'+'FIX,aparat'+'.com,DIREC'+'T','DOMAIN-SUF'+'FIX,digika'+'la.com,DIR'+'ECT','DOMAIN-SUF'+'FIX,divar.'+'ir,DIRECT','DOMAIN-SUF'+'FIX,snapp.'+'ir,DIRECT','DOMAIN-SUF'+'FIX,torob.'+'com,DIRECT','DOMAIN-SUF'+'FIX,bamilo'+'.com,DIREC'+'T','DOMAIN-SUF'+'FIX,alibab'+'a.ir,DIREC'+'T','DOMAIN-SUF'+'FIX,ban.ir'+',DIRECT','GEOIP,IR,D'+'IRECT','MATCH,ARIS'+'TA\x20Auto']};const _0x148dde=[];_0x11e516['forEach']((_0x37787e,_0x363e51)=>{const _0x38c98e=vlessToClashMeta(_0x37787e,'ARISTA',_0x363e51+0x1,_0x263b82);if(_0x38c98e){_0x148dde['push'](_0x38c98e);}});_0x5a34ee['proxies']=_0x148dde;if(_0x5a34ee['proxies']['length']>0x0){const _0x2f597f=[];_0x2f597f['push']({'name':'ARISTA\x20Sel'+'ect','type':'select','proxies':['ARISTA\x20Aut'+'o','ARISTA\x20Fal'+'lback','ARISTA\x20Loa'+'d\x20Balance',..._0x148dde['map'](_0x291bad=>_0x291bad['name'])],'disable-udp':![]});_0x2f597f['push']({'name':'ARISTA\x20Aut'+'o','type':'url-test','proxies':_0x148dde['map'](_0x26539b=>_0x26539b['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x78,'tolerance':0x32,'lazy':!![],'disable-udp':![]});_0x2f597f['push']({'name':'ARISTA\x20Fal'+'lback','type':'fallback','proxies':_0x148dde['map'](_0x610e4e=>_0x610e4e['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x78,'tolerance':0x64,'disable-udp':![]});_0x2f597f['push']({'name':'ARISTA\x20Loa'+'d\x20Balance','type':'load-balan'+'ce','proxies':_0x148dde['map'](_0x12f0f7=>_0x12f0f7['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x12c,'strategy':'consistent'+'-hashing','disable-udp':![]});_0x5a34ee['proxy-grou'+'ps']=_0x2f597f;}const _0x35b39c={};_0x35b39c['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';_0x35b39c['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x5b745b={};_0x5b745b['headers']=_0x35b39c;return new Response(JSON['stringify'](_0x5a34ee,null,0x2),_0x5b745b);}if(_0x48c533==='singbox'){const _0x991e45=generateSingBoxConfig(_0x11e516,_0x263b82);const _0x4c4171={};_0x4c4171['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';_0x4c4171['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x2a3bc6={};_0x2a3bc6['headers']=_0x4c4171;return new Response(JSON['stringify'](_0x991e45,null,0x2),_0x2a3bc6);}const _0x232149={};_0x232149['content-ty'+'pe']='text/plain'+';charset=u'+'tf-8';_0x232149['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x31590b={};_0x31590b['headers']=_0x232149;return new Response(_0x11e516['join']('\x0a'),_0x31590b);}catch(_0x58b0f6){console['error']('Error\x20in\x20/'+'api/config'+'s:',_0x58b0f6);const _0x53fe65={};_0x53fe65['status']=0x1f4;return new Response('Internal\x20S'+'erver\x20Erro'+'r',_0x53fe65);}}const _0x275472={};_0x275472['status']=0x194;return new Response('Not\x20Found',_0x275472);}};function getHTML(){return'<!DOCTYPE\x20'+'html>\x0a<htm'+'l\x20lang=\x22en'+'\x22>\x0a<head>\x0a'+'<meta\x20char'+'set=\x22UTF-8'+'\x22\x20/>\x0a<meta'+'\x20name=\x22vie'+'wport\x22\x20con'+'tent=\x22widt'+'h=device-w'+'idth,\x20init'+'ial-scale='+'1.0\x22\x20/>\x0a<t'+'itle>ARIST'+'A\x20Config\x20G'+'enerator</'+'title>\x0a<st'+'yle>\x0a*\x20{\x20b'+'ox-sizing:'+'\x20border-bo'+'x;\x20margin:'+'\x200;\x20paddin'+'g:\x200;\x20}\x0abo'+'dy\x20{\x20font-'+'family:\x20\x27S'+'egoe\x20UI\x27,\x20'+'Tahoma,\x20Ge'+'neva,\x20Verd'+'ana,\x20sans-'+'serif;\x20bac'+'kground:\x20#'+'0b1c3d;\x20co'+'lor:\x20#fff;'+'\x20line-heig'+'ht:\x201.6;\x20}'+'\x0a.containe'+'r\x20{\x20max-wi'+'dth:\x20800px'+';\x20margin:\x20'+'0\x20auto;\x20pa'+'dding:\x2020p'+'x;\x20}\x0a.head'+'er\x20{\x20backg'+'round:\x20lin'+'ear-gradie'+'nt(135deg,'+'\x20#1a3b7c\x200'+'%,\x20#2c5282'+'\x20100%);\x20co'+'lor:\x20white'+';\x20padding:'+'\x2025px;\x20bor'+'der-radius'+':\x2015px;\x20ma'+'rgin-botto'+'m:\x2025px;\x20t'+'ext-align:'+'\x20center;\x20b'+'ox-shadow:'+'\x200\x204px\x2015p'+'x\x20rgba(0,0'+',0,0.2);\x20}'+'\x0ah1\x20{\x20marg'+'in:\x200;\x20fon'+'t-size:\x2028'+'px;\x20font-w'+'eight:\x20700'+';\x20}\x0a.heade'+'r\x20p\x20{\x20marg'+'in:\x2010px\x200'+'\x200;\x20opacit'+'y:\x200.9;\x20}\x0a'+'.card\x20{\x20ba'+'ckground:\x20'+'#13274f;\x20p'+'adding:\x2025'+'px;\x20border'+'-radius:\x201'+'5px;\x20margi'+'n:\x2015px\x200;'+'\x20box-shado'+'w:\x200\x204px\x201'+'0px\x20rgba(0'+',0,0,0.15)'+';\x20}\x0a.arist'+'a-subscrib'+'e-card\x20{\x20\x0a'+'\x20\x20\x20\x20backgr'+'ound:\x20line'+'ar-gradien'+'t(135deg,\x20'+'rgba(138,\x20'+'43,\x20226,\x200'+'.2),\x20rgba('+'218,\x20112,\x20'+'214,\x200.2))'+';\x0a\x20\x20\x20\x20back'+'drop-filte'+'r:\x20blur(10'+('px);\x0a\x20\x20\x20\x20p'+'adding:\x2020'+'px;\x0a\x20\x20\x20\x20bo'+'rder-radiu'+'s:\x2012px;\x0a\x20'+'\x20\x20\x20margin:'+'\x2020px\x20auto'+';\x0a\x20\x20\x20\x20text'+'-align:\x20ce'+'nter;\x0a\x20\x20\x20\x20'+'box-shadow'+':\x200\x204px\x2020'+'px\x20rgba(13'+'8,\x2043,\x20226'+',\x200.3);\x0a\x20\x20'+'\x20\x20border:\x20'+'1px\x20solid\x20'+'rgba(255,\x20'+'255,\x20255,\x20'+'0.1);\x0a}\x0a.a'+'rista-subs'+'cribe-card'+':hover\x20{\x0a}'+'\x0a.arista-s'+'ubscribe-c'+'ard\x20h3\x20{\x0a\x20'+'\x20\x20\x20color:\x20'+'#fff;\x0a\x20\x20\x20\x20'+'margin-bot'+'tom:\x2010px;'+'\x0a\x20\x20\x20\x20font-'+'size:\x2018px'+';\x0a\x20\x20\x20\x20font'+'-weight:\x206'+'00;\x0a}\x0a.ari'+'sta-subscr'+'ibe-card\x20p'+'\x20{\x0a\x20\x20\x20\x20col'+'or:\x20#e2e8f'+'0;\x0a\x20\x20\x20\x20fon'+'t-size:\x2014'+'px;\x0a\x20\x20\x20\x20ma'+'rgin-botto'+'m:\x2015px;\x0a}'+'\x0a.arista-s'+'ubscribe-c'+'ard\x20.copy-'+'btn\x20{\x0a\x20\x20\x20\x20'+'background'+':\x20linear-g'+'radient(13'+'5deg,\x20#8b5'+'cf6\x200%,\x20#7'+'c3aed\x20100%'+');\x0a\x20\x20\x20\x20col'+'or:\x20white;'+'\x0a\x20\x20\x20\x20borde'+'r:\x20none;\x0a\x20'+'\x20\x20\x20padding'+':\x2010px\x2020p'+'x;\x0a\x20\x20\x20\x20bor'+'der-radius'+':\x208px;\x0a\x20\x20\x20'+'\x20cursor:\x20p'+'ointer;\x0a\x20\x20'+'\x20\x20font-wei'+'ght:\x20600;\x0a'+'\x20\x20\x20\x20transi'+'tion:\x20all\x20'+'0.3s\x20ease;'+'\x0a}\x0a.arista'+'-subscribe'+'-card\x20.cop'+'y-btn:hove'+'r\x20{\x0a\x20\x20\x20\x20tr'+'ansform:\x20s'+'cale(1.05)'+';\x0a\x20\x20\x20\x20box-'+'shadow:\x200\x20'+'4px\x2015px\x20r'+'gba(139,\x209'+'2,\x20246,\x200.'+'4);\x0a}\x0alabe'+'l\x20{\x20displa'+'y:\x20block;\x20'+'margin-top'+':\x2015px;\x20fo'+'nt-weight:'+'\x20600;\x20colo'+'r:\x20#e2e8f0'+';\x20}\x0a.help-'+'text\x20{\x20fon'+'t-size:\x2013'+'px;\x20color:'+'\x20#a0aec0;\x20'+'margin-top'+':\x205px;\x20}\x0ai'+'nput,\x20sele'+'ct,\x20textar'+'ea\x20{\x20width')+(':\x20100%;\x20pa'+'dding:\x2012p'+'x;\x20margin-'+'top:\x208px;\x20'+'border:\x201p'+'x\x20solid\x20#2'+'d3748;\x20bor'+'der-radius'+':\x208px;\x20bac'+'kground:\x20#'+'0b1c3d;\x20co'+'lor:\x20#fff;'+'\x20font-size'+':\x2014px;\x20tr'+'ansition:\x20'+'all\x200.3s\x20e'+'ase;\x20}\x0ainp'+'ut:focus,\x20'+'select:foc'+'us,\x20textar'+'ea:focus\x20{'+'\x20outline:\x20'+'none;\x20bord'+'er-color:\x20'+'#4299e1;\x20b'+'ox-shadow:'+'\x200\x200\x200\x203px'+'\x20rgba(66,\x20'+'153,\x20225,\x20'+'0.2);\x20}\x0abu'+'tton\x20{\x20mar'+'gin-top:\x202'+'0px;\x20paddi'+'ng:\x2014px;\x20'+'width:\x20100'+'%;\x20border:'+'\x20none;\x20bor'+'der-radius'+':\x208px;\x20col'+'or:\x20#fff;\x20'+'font-weigh'+'t:\x20600;\x20cu'+'rsor:\x20poin'+'ter;\x20trans'+'ition:\x20all'+'\x200.3s\x20ease'+';\x20font-siz'+'e:\x2016px;\x20}'+'\x0abutton:ho'+'ver\x20{\x20tran'+'sform:\x20tra'+'nslateY(-2'+'px);\x20box-s'+'hadow:\x200\x204'+'px\x2012px\x20rg'+'ba(0,0,0,0'+'.2);\x20}\x0a.bt'+'n-save\x20{\x20b'+'ackground:'+'\x20linear-gr'+'adient(135'+'deg,\x20#22c5'+'5e\x200%,\x20#16'+'a34a\x20100%)'+';\x20}\x0a.btn-r'+'eset\x20{\x20\x0a\x20\x20'+'background'+':\x20linear-g'+'radient(13'+'5deg,\x20#f97'+'316\x2050%,\x20#'+'ea580c\x20100'+'%);\x20\x0a}\x0a.bt'+'n-copy\x20{\x20b'+'ackground:'+'\x20linear-gr'+'adient(135'+'deg,\x20#8b5c'+'f6\x200%,\x20#7c'+'3aed\x20100%)'+';\x20}\x0a.fragm'+'ent-sectio'+'n\x20{\x20backgr'+'ound:\x20#1e3'+'a8a;\x20paddi'+'ng:\x2015px;\x20'+'border-rad'+'ius:\x2010px;'+'\x20margin-to'+'p:\x2015px;\x20}'+'\x0a.fragment'+'-toggle\x20{\x20'+'display:\x20f'+'lex;\x20align'+'-items:\x20ce'+'nter;\x20marg'+'in-bottom:'+'\x2015px;\x20}\x0a.'+'fragment-t'+'oggle\x20labe')+('l\x20{\x20margin'+':\x200\x200\x200\x2015'+'px;\x20font-w'+'eight:\x20600'+';\x20}\x0a.switc'+'h\x20{\x20positi'+'on:\x20relati'+'ve;\x20displa'+'y:\x20inline-'+'block;\x20wid'+'th:\x2060px;\x20'+'height:\x2030'+'px;\x20}\x0a.swi'+'tch\x20input\x20'+'{\x20opacity:'+'\x200;\x20width:'+'\x200;\x20height'+':\x200;\x20}\x0a.sl'+'ider\x20{\x20pos'+'ition:\x20abs'+'olute;\x20cur'+'sor:\x20point'+'er;\x20top:\x200'+';\x20left:\x200;'+'\x20right:\x200;'+'\x20bottom:\x200'+';\x20backgrou'+'nd-color:\x20'+'#4a5568;\x20t'+'ransition:'+'\x20.4s;\x20bord'+'er-radius:'+'\x2034px;\x20}\x0a.'+'slider:bef'+'ore\x20{\x20posi'+'tion:\x20abso'+'lute;\x20cont'+'ent:\x20\x22\x22;\x20h'+'eight:\x2022p'+'x;\x20width:\x20'+'22px;\x20left'+':\x204px;\x20bot'+'tom:\x204px;\x20'+'background'+'-color:\x20wh'+'ite;\x20trans'+'ition:\x20.4s'+';\x20border-r'+'adius:\x2050%'+';\x20}\x0ainput:'+'checked\x20+\x20'+'.slider\x20{\x20'+'background'+'-color:\x20#2'+'196F3;\x20}\x0ai'+'nput:check'+'ed\x20+\x20.slid'+'er:before\x20'+'{\x20transfor'+'m:\x20transla'+'teX(30px);'+'\x20}\x0a.limit-'+'section\x20{\x20'+'\x0a\x20\x20\x20\x20backg'+'round:\x20rgb'+'a(220,\x2038,'+'\x2038,\x200.1);'+'\x20\x0a\x20\x20\x20\x20padd'+'ing:\x2020px;'+'\x20\x0a\x20\x20\x20\x20bord'+'er-radius:'+'\x2010px;\x20\x0a\x20\x20'+'\x20\x20margin:\x20'+'20px\x200;\x20\x0a\x20'+'\x20\x20\x20border:'+'\x202px\x20solid'+'\x20#ef4444;\x20'+'\x0a\x20\x20\x20\x20anima'+'tion:\x20blin'+'k-border\x202'+'s\x20infinite'+';\x0a\x20\x20\x20\x20posi'+'tion:\x20rela'+'tive;\x0a}\x0a@k'+'eyframes\x20b'+'link-borde'+'r\x20{\x0a\x20\x20\x20\x200%'+',\x20100%\x20{\x20b'+'order-colo'+'r:\x20#ef4444'+';\x20}\x0a\x20\x20\x20\x2050'+'%\x20{\x20border'+'-color:\x20#f'+'ca5a5;\x20}\x0a}'+'\x0a.limit-se'+'ction\x20{\x20\x0a\x20'+'\x20\x20\x20backgro'+'und:\x20rgba('+'220,\x2038,\x203'+'8,\x200.1);\x20\x0a')+('\x20\x20\x20\x20paddin'+'g:\x2020px;\x20\x0a'+'\x20\x20\x20\x20border'+'-radius:\x201'+'2px;\x20\x0a\x20\x20\x20\x20'+'margin:\x2020'+'px\x20auto;\x0a\x20'+'\x20\x20\x20border:'+'\x202px\x20solid'+'\x20#ef4444;\x20'+'\x0a\x20\x20\x20\x20anima'+'tion:\x20blin'+'k-border\x202'+'s\x20infinite'+';\x0a\x20\x20\x20\x20posi'+'tion:\x20rela'+'tive;\x0a\x20\x20\x20\x20'+'max-width:'+'\x20400px;\x0a\x20\x20'+'\x20\x20text-ali'+'gn:\x20center'+';\x0a\x20\x20\x20\x20widt'+'h:\x20100%;\x0a}'+'\x0a@keyframe'+'s\x20blink-bo'+'rder\x20{\x0a\x20\x20\x20'+'\x200%,\x20100%\x20'+'{\x20border-c'+'olor:\x20#ef4'+'444;\x20box-s'+'hadow:\x200\x200'+'\x2010px\x20rgba'+'(239,\x2068,\x20'+'68,\x200.3);\x20'+'}\x0a\x20\x20\x20\x2050%\x20'+'{\x20border-c'+'olor:\x20#fca'+'5a5;\x20box-s'+'hadow:\x200\x200'+'\x2015px\x20rgba'+'(239,\x2068,\x20'+'68,\x200.5);\x20'+'}\x0a}\x0a.limit'+'-section::'+'before\x20{\x0a\x20'+'\x20\x20\x20content'+':\x20\x22⚠️\x20IMPOR'+'TANT\x20SETTI'+'NG\x22;\x0a\x20\x20\x20\x20p'+'osition:\x20a'+'bsolute;\x0a\x20'+'\x20\x20\x20top:\x20-1'+'2px;\x0a\x20\x20\x20\x20l'+'eft:\x2050%;\x0a'+'\x20\x20\x20\x20transf'+'orm:\x20trans'+'lateX(-50%'+');\x0a\x20\x20\x20\x20bac'+'kground:\x20l'+'inear-grad'+'ient(135de'+'g,\x20#ef4444'+'\x200%,\x20#dc26'+'26\x20100%);\x0a'+'\x20\x20\x20\x20color:'+'\x20white;\x0a\x20\x20'+'\x20\x20padding:'+'\x206px\x2016px;'+'\x0a\x20\x20\x20\x20borde'+'r-radius:\x20'+'8px;\x0a\x20\x20\x20\x20f'+'ont-size:\x20'+'12px;\x0a\x20\x20\x20\x20'+'font-weigh'+'t:\x20700;\x0a\x20\x20'+'\x20\x20animatio'+'n:\x20blink-t'+'ext\x202s\x20inf'+'inite;\x0a\x20\x20\x20'+'\x20white-spa'+'ce:\x20nowrap'+';\x0a\x20\x20\x20\x20box-'+'shadow:\x200\x20'+'2px\x208px\x20rg'+'ba(239,\x2068'+',\x2068,\x200.3)'+';\x0a}\x0a@keyfr'+'ames\x20blink'+'-text\x20{\x0a\x20\x20'+'\x20\x200%,\x20100%'+'\x20{\x20opacity'+':\x201;\x20trans'+'form:\x20tran'+'slateX(-50'+'%)\x20scale(1'+');\x20}\x0a\x20\x20\x20\x205'+'0%\x20{\x20opaci'+'ty:\x200.8;\x20t'+'ransform:\x20'+'translateX')+('(-50%)\x20sca'+'le(1.02);\x20'+'}\x0a}\x0a\x0a.limi'+'t-section\x20'+'.grid\x20{\x0a\x20\x20'+'\x20\x20display:'+'\x20flex;\x0a\x20\x20\x20'+'\x20justify-c'+'ontent:\x20ce'+'nter;\x0a\x20\x20\x20\x20'+'gap:\x2015px;'+'\x0a}\x0a\x0a.limit'+'-section\x20.'+'grid\x20>\x20div'+'\x20{\x0a\x20\x20\x20\x20fle'+'x:\x201;\x0a\x20\x20\x20\x20'+'max-width:'+'\x20300px;\x0a}\x0a'+'\x0a.limit-se'+'ction\x20sele'+'ct\x20{\x0a\x20\x20\x20\x20b'+'ackground:'+'\x20rgba(11,\x20'+'28,\x2061,\x200.'+'8);\x0a\x20\x20\x20\x20bo'+'rder:\x201px\x20'+'solid\x20#ef4'+'444;\x0a\x20\x20\x20\x20c'+'olor:\x20whit'+'e;\x0a\x20\x20\x20\x20tex'+'t-align:\x20c'+'enter;\x0a\x20\x20\x20'+'\x20font-weig'+'ht:\x20600;\x0a}'+'\x0a\x0a.limit-s'+'ection\x20.he'+'lp-text\x20{\x0a'+'\x20\x20\x20\x20color:'+'\x20#fecaca;\x0a'+'\x20\x20\x20\x20font-s'+'ize:\x2012px;'+'\x0a\x20\x20\x20\x20margi'+'n-top:\x208px'+';\x0a}\x0atextar'+'ea\x20{\x20heigh'+'t:\x20120px;\x20'+'resize:\x20ve'+'rtical;\x20}\x0a'+'footer\x20{\x20t'+'ext-align:'+'\x20center;\x20m'+'argin-top:'+'\x2030px;\x20opa'+'city:\x200.7;'+'\x20font-size'+':\x2014px;\x20}\x0a'+'.alert\x20{\x20p'+'osition:\x20f'+'ixed;\x20top:'+'\x2020px;\x20rig'+'ht:\x2020px;\x20'+'padding:\x201'+'5px\x2025px;\x20'+'background'+':\x20#22c55e;'+'\x20color:\x20wh'+'ite;\x20borde'+'r-radius:\x20'+'8px;\x20box-s'+'hadow:\x200\x204'+'px\x2015px\x20rg'+'ba(0,0,0,0'+'.2);\x20z-ind'+'ex:\x201000;\x20'+'opacity:\x200'+';\x20transfor'+'m:\x20transla'+'teY(-20px)'+';\x20transiti'+'on:\x20all\x200.'+'3s\x20ease;\x20}'+'\x0a.alert.sh'+'ow\x20{\x20opaci'+'ty:\x201;\x20tra'+'nsform:\x20tr'+'anslateY(0'+');\x20}\x0a.aler'+'t.error\x20{\x20'+'background'+':\x20#ef4444;'+'\x20}\x0a.grid\x20{'+'\x20display:\x20'+'grid;\x20grid'+'-template-'+'columns:\x201'+'fr\x201fr;\x20ga'+'p:\x2015px;\x20}'+'\x0a@media\x20(m'+'ax-width:\x20'+'768px)\x20{\x0a\x20')+('\x20\x20\x20.grid\x20{'+'\x20grid-temp'+'late-colum'+'ns:\x201fr;\x20}'+'\x0a\x20\x20\x20\x20.cont'+'ainer\x20{\x20pa'+'dding:\x2015p'+'x;\x20}\x0a\x20\x20\x20\x20.'+'header\x20{\x20p'+'adding:\x2020'+'px;\x20}\x0a\x20\x20\x20\x20'+'.card\x20{\x20pa'+'dding:\x2020p'+'x;\x20}\x0a\x20\x20\x20\x20.'+'limit-sect'+'ion\x20{\x20padd'+'ing:\x2015px;'+'\x20}\x0a\x20\x20\x20\x20.ar'+'ista-subsc'+'ribe-card\x20'+'{\x20padding:'+'\x2015px;\x20}\x0a}'+'\x0a@keyframe'+'s\x20blink-bo'+'rder\x20{\x0a\x20\x20\x20'+'\x200%,\x20100%\x20'+'{\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20border-co'+'lor:\x20#3b82'+'f6;\x20\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20box-sha'+'dow:\x200\x204px'+'\x2020px\x20rgba'+'(59,\x20130,\x20'+'246,\x200.3);'+'\x0a\x20\x20\x20\x20}\x0a\x20\x20\x20'+'\x2050%\x20{\x20\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20bord'+'er-color:\x20'+'#93c5fd;\x20\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20bo'+'x-shadow:\x20'+'0\x204px\x2025px'+'\x20rgba(59,\x20'+'130,\x20246,\x20'+'0.5);\x0a\x20\x20\x20\x20'+'}\x0a}\x0a\x0a@keyf'+'rames\x20blin'+'k-text\x20{\x0a\x20'+'\x20\x20\x200%,\x20100'+'%\x20{\x20\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20opacity'+':\x201;\x20\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20transf'+'orm:\x20trans'+'lateX(-50%'+')\x20scale(1)'+';\x0a\x20\x20\x20\x20}\x0a\x20\x20'+'\x20\x2050%\x20{\x20\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20opa'+'city:\x200.9;'+'\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'transform:'+'\x20translate'+'X(-50%)\x20sc'+'ale(1.02);'+'\x0a\x20\x20\x20\x20}\x0a}\x0a<'+'/style>\x0a</'+'head>\x0a<bod'+'y>\x0a<div\x20cl'+'ass=\x22conta'+'iner\x22>\x0a<di'+'v\x20class=\x22h'+'eader\x22>\x0a<h'+'1>ARISTA\x20C'+'onfig\x20Gene'+'rator</h1>'+'\x0a<p>Genera'+'te\x20and\x20cus'+'tomize\x20VLE'+'SS\x20configu'+'rations</p'+'>\x0a</div>\x0a<'+'div\x20style='+'\x22\x0a\x20\x20\x20\x20back'+'ground:\x20li'+'near-gradi'+'ent(135deg'+',\x20rgba(138'+',\x2043,\x20226,'+'\x200.1),\x20rgb'+'a(218,\x20112'+',\x20214,\x200.1'+'));\x0a\x20\x20\x20\x20ba'+'ckdrop-fil'+'ter:\x20blur('+'10px);\x0a\x20\x20\x20'+'\x20padding:\x20'+'15px\x2020px;'+'\x0a\x20\x20\x20\x20borde')+('r-radius:\x20'+'12px;\x0a\x20\x20\x20\x20'+'margin:\x2020'+'px\x20auto;\x0a\x20'+'\x20\x20\x20text-al'+'ign:\x20cente'+'r;\x0a\x20\x20\x20\x20box'+'-shadow:\x200'+'\x204px\x2020px\x20'+'rgba(138,\x20'+'43,\x20226,\x200'+'.2);\x0a\x20\x20\x20\x20b'+'order:\x201px'+'\x20solid\x20whi'+'te;\x0a\x20\x20\x20\x20ma'+'x-width:\x209'+'0%;\x0a\x22>\x0a\x20\x20\x20'+'\x20<div\x20styl'+'e=\x22\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20display:'+'\x20flex;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20justi'+'fy-content'+':\x20center;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20ga'+'p:\x2025px;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20fle'+'x-wrap:\x20wr'+'ap;\x0a\x20\x20\x20\x20\x22>'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20<'+'a\x20href=\x22ht'+'tps://t.me'+'/aristapro'+'ject\x22\x20targ'+'et=\x22_blank'+'\x22\x20style=\x22\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20display:'+'\x20flex;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20a'+'lign-items'+':\x20center;\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20gap:\x208p'+'x;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20paddi'+'ng:\x2010px\x202'+'0px;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20bac'+'kground:\x20l'+'inear-grad'+'ient(135de'+'g,\x20rgba(0,'+'\x20136,\x20204,'+'\x200.2),\x20rgb'+'a(0,\x20119,\x20'+'181,\x200.3))'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20color:'+'\x20white;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'text-decor'+'ation:\x20non'+'e;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20borde'+'r-radius:\x20'+'8px;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20tra'+'nsition:\x20a'+'ll\x200.3s\x20ea'+'se;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20bord'+'er:\x201px\x20so'+'lid\x20rgba(0'+',\x20136,\x20204'+',\x200.3);\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'font-weigh'+'t:\x20600;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x22\x20on'+'mouseover='+'\x22this.styl'+'e.transfor'+'m=\x27transla'+'teY(-2px)\x27'+';this.styl'+'e.boxShado'+'w=\x270\x206px\x201'+'5px\x20rgba(0'+',136,204,0'+'.3)\x27;\x22\x20\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20o'+'nmouseout='+'\x22this.styl'+'e.transfor'+'m=\x27transla'+'teY(0)\x27;th'+'is.style.b'+'oxShadow=\x27'+'none\x27;\x22>\x0a\x20')+('\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20<svg\x20xmln'+'s=\x22http://'+'www.w3.org'+'/2000/svg\x22'+'\x20width=\x2218'+'\x22\x20height=\x22'+'18\x22\x20fill=\x22'+'currentCol'+'or\x22\x20viewBo'+'x=\x220\x200\x2016\x20'+'16\x22>\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20<path\x20d=\x22'+'M16\x208A8\x208\x20'+'0\x201\x201\x200\x208a'+'8\x208\x200\x200\x201\x20'+'16\x200zM8.28'+'7\x205.906c-.'+'778.324-2.'+'334.994-4.'+'666\x202.01-.'+'378.15-.57'+'7.298-.595'+'.442-.03.2'+'43.275.339'+'.69.47l.17'+'5.055c.408'+'.133.958.2'+'88\x201.243.2'+'94.26.006.'+'549-.1.868'+'-.32\x202.179'+'-1.471\x203.3'+'04-2.214\x203'+'.374-2.23.'+'05-.012.12'+'-.026.166.'+'016.047.04'+'1.042.12.0'+'37.141-.03'+'.129-1.227'+'\x201.241-1.8'+'46\x201.817-.'+'193.18-.33'+'.307-.358.'+'336a8.154\x20'+'8.154\x200\x200\x20'+'1-.188.186'+'c-.38.366-'+'.664.64.01'+'5\x201.088.32'+'7.216.589.'+'393.85.571'+'.284.194.5'+'68.387.936'+'.629.093.0'+'6.183.125.'+'27.187.331'+'.236.63.44'+'8.997.414.'+'214-.02.43'+'5-.22.547-'+'.82.265-1.'+'417.786-4.'+'486.906-5.'+'751a1.426\x20'+'1.426\x200\x200\x20'+'0-.013-.31'+'5.337.337\x20'+'0\x200\x200-.114'+'-.217.526.'+'526\x200\x200\x200-'+'.31-.093c-'+'.3.005-.76'+'3.166-2.98'+'4\x201.09z\x22/>'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20</svg>\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20Arista\x20T'+'elegram\x20Ch'+'annel\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20</a>\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20<a\x20h'+'ref=\x22https'+'://arista-'+'proxy.page'+'s.dev\x22\x20tar'+'get=\x22_blan'+'k\x22\x20style=\x22'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20display'+':\x20flex;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'align-item'+'s:\x20center;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20gap:\x208p')+('x;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20paddi'+'ng:\x2010px\x202'+'0px;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20bac'+'kground:\x20l'+'inear-grad'+'ient(135de'+'g,\x20rgba(74'+',\x20144,\x20226'+',\x200.2),\x20rg'+'ba(66,\x20133'+',\x20214,\x200.3'+'));\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20colo'+'r:\x20white;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20text-dec'+'oration:\x20n'+'one;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20bor'+'der-radius'+':\x208px;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20t'+'ransition:'+'\x20all\x200.3s\x20'+'ease;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20bo'+'rder:\x201px\x20'+'solid\x20rgba'+'(74,\x20144,\x20'+'226,\x200.3);'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20font-we'+'ight:\x20600;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x22'+'\x20onmouseov'+'er=\x22this.s'+'tyle.trans'+'form=\x27tran'+'slateY(-2p'+'x)\x27;this.s'+'tyle.boxSh'+'adow=\x270\x206p'+'x\x2015px\x20rgb'+'a(74,144,2'+'26,0.3)\x27;\x22'+'\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20onmouse'+'out=\x22this.'+'style.tran'+'sform=\x27tra'+'nslateY(0)'+'\x27;this.sty'+'le.boxShad'+'ow=\x27none\x27;'+'\x22>\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20<svg\x20'+'xmlns=\x22htt'+'p://www.w3'+'.org/2000/'+'svg\x22\x20width'+'=\x2218\x22\x20heig'+'ht=\x2218\x22\x20fi'+'ll=\x22curren'+'tColor\x22\x20vi'+'ewBox=\x220\x200'+'\x2016\x2016\x22>\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20<path'+'\x20d=\x22M0\x208a8'+'\x208\x200\x201\x201\x201'+'6\x200A8\x208\x200\x20'+'0\x201\x200\x208zm7'+'.5-6.923c-'+'.67.204-1.'+'335.82-1.8'+'87\x201.855A7'+'.97\x207.97\x200'+'\x200\x200\x205.145'+'\x204H7.5V1.0'+'77zM4.09\x204'+'a9.267\x209.2'+'67\x200\x200\x201\x20.'+'64-1.539\x206'+'.7\x206.7\x200\x200'+'\x201\x20.597-.9'+'33A7.025\x207'+'.025\x200\x200\x200'+'\x202.255\x204H4'+'.09zm-.582'+'\x203.5c.03-.'+'877.138-1.'+'718.312-2.'+'5H1.674a6.'+'958\x206.958\x20'+'0\x200\x200-.656'+'\x202.5h2.49z'+'M4.847\x205a1'+'2.5\x2012.5\x200')+('\x200\x200-.338\x20'+'2.5H7.5V5H'+'4.847zM8.5'+'\x205v2.5h2.9'+'9a12.495\x201'+'2.495\x200\x200\x20'+'0-.337-2.5'+'H8.5zM4.51'+'\x208.5a12.5\x20'+'12.5\x200\x200\x200'+'\x20.337\x202.5H'+'7.5V8.5H4.'+'51zm3.99\x200'+'V11h2.653c'+'.187-.765.'+'306-1.608.'+'338-2.5H8.'+'5zM5.145\x201'+'2c.138.386'+'.295.744.4'+'68\x201.068.5'+'52\x201.035\x201'+'.218\x201.65\x20'+'1.887\x201.85'+'5V12H5.145'+'zm.182\x202.4'+'72a6.696\x206'+'.696\x200\x200\x201'+'-.597-.933'+'A9.268\x209.2'+'68\x200\x200\x201\x204'+'.09\x2012H2.2'+'55a7.024\x207'+'.024\x200\x200\x200'+'\x203.072\x202.4'+'72zM3.82\x201'+'1a13.652\x201'+'3.652\x200\x200\x20'+'1-.312-2.5'+'h-2.49c.06'+'2.97.291\x201'+'.87.656\x202.'+'5H3.82zm6.'+'853\x203.472A'+'7.024\x207.02'+'4\x200\x200\x200\x2013'+'.745\x2012H11'+'.91a9.27\x209'+'.27\x200\x200\x201-'+'.64\x201.539\x20'+'6.688\x206.68'+'8\x200\x200\x201-.5'+'97.933zM8.'+'5\x2012v2.923'+'c.67-.204\x20'+'1.335-.82\x20'+'1.887-1.85'+'5.173-.324'+'.33-.682.4'+'68-1.068H8'+'.5zm3.680-'+'1h2.146c.3'+'65-.63.594'+'-1.53.656-'+'2.5h-2.49a'+'13.65\x2013.6'+'5\x200\x200\x201-.3'+'12\x202.5zm2.'+'802-3.5a6.'+'959\x206.959\x20'+'0\x200\x200-.656'+'-2.5H12.18'+'c.174.782.'+'282\x201.623.'+'312\x202.5h2.'+'49zM11.27\x20'+'2.461c.247'+'.35.462.73'+'9.64\x201.539'+'h1.835a7.0'+'24\x207.024\x200'+'\x200\x200-3.072'+'-2.472c.21'+'8.284.418.'+'598.597.93'+'3zM10.855\x20'+'4a7.966\x207.'+'966\x200\x200\x200-'+'.468-1.068'+'C9.835\x201.8'+'97\x209.17\x201.'+'282\x208.5\x201.'+'077V4h2.35'+'5z\x22/>\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20</'+'svg>\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20Tel'+'egram\x20Prox'+'y\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'</a>\x0a\x20\x20\x20\x20<')+('/div>\x0a</di'+'v>\x0a<div\x20st'+'yle=\x22\x0a\x20\x20\x20\x20'+'background'+':\x20linear-g'+'radient(13'+'5deg,\x20rgba'+'(59,\x20130,\x20'+'246,\x200.1),'+'\x20rgba(37,\x20'+'99,\x20235,\x200'+'.2));\x0a\x20\x20\x20\x20'+'backdrop-f'+'ilter:\x20blu'+'r(10px);\x0a\x20'+'\x20\x20\x20padding'+':\x2020px;\x0a\x20\x20'+'\x20\x20border-r'+'adius:\x2012p'+'x;\x0a\x20\x20\x20\x20mar'+'gin:\x2020px\x20'+'auto;\x0a\x20\x20\x20\x20'+'text-align'+':\x20center;\x0a'+'\x20\x20\x20\x20box-sh'+'adow:\x200\x204p'+'x\x2020px\x20rgb'+'a(59,\x20130,'+'\x20246,\x200.3)'+';\x0a\x20\x20\x20\x20bord'+'er:\x202px\x20so'+'lid\x20#3b82f'+'6;\x0a\x20\x20\x20\x20ani'+'mation:\x20bl'+'ink-border'+'\x202s\x20infini'+'te;\x0a\x20\x20\x20\x20po'+'sition:\x20re'+'lative;\x0a\x20\x20'+'\x20\x20max-widt'+'h:\x2090%;\x0a\x22>'+'\x0a\x20\x20\x20\x20<div\x20'+'style=\x22\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20posi'+'tion:\x20abso'+'lute;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20top:\x20-'+'12px;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20left:\x20'+'50%;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20transfo'+'rm:\x20transl'+'ateX(-50%)'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'background'+':\x20linear-g'+'radient(13'+'5deg,\x20#3b8'+'2f6\x200%,\x20#2'+'563eb\x20100%'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20color:\x20wh'+'ite;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20padding'+':\x206px\x2016px'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'border-rad'+'ius:\x208px;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20fo'+'nt-size:\x201'+'2px;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20font-we'+'ight:\x20700;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20a'+'nimation:\x20'+'blink-text'+'\x202s\x20infini'+'te;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20white-sp'+'ace:\x20nowra'+'p;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20box-shado'+'w:\x200\x202px\x208'+'px\x20rgba(59'+',\x20130,\x20246'+',\x200.3);\x0a\x20\x20'+'\x20\x20\x22>\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20🚀\x20IMPOR'+'TANT\x20LINKS'+'\x0a\x20\x20\x20\x20</div'+'>\x0a\x20\x20\x20\x20\x0a\x20\x20\x20'+'\x20<div\x20styl'+'e=\x22\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20display:'+'\x20flex;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20justi'+'fy-content'+':\x20center;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20ga'+'p:\x2025px;\x0a\x20')+('\x20\x20\x20\x20\x20\x20\x20fle'+'x-wrap:\x20wr'+'ap;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20margin-t'+'op:\x2010px;\x0a'+'\x20\x20\x20\x20\x22>\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20<a\x20hr'+'ef=\x22https:'+'//ip.16474'+'6.xyz/\x22\x20ta'+'rget=\x22_bla'+'nk\x22\x20style='+'\x22\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20displa'+'y:\x20flex;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20align-ite'+'ms:\x20center'+';\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20gap:\x20'+'8px;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20pad'+'ding:\x2012px'+'\x2020px;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20b'+'ackground:'+'\x20linear-gr'+'adient(135'+'deg,\x20rgba('+'59,\x20130,\x202'+'46,\x200.2),\x20'+'rgba(37,\x209'+'9,\x20235,\x200.'+'3));\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20col'+'or:\x20white;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20text-de'+'coration:\x20'+'none;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20bo'+'rder-radiu'+'s:\x208px;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'transition'+':\x20all\x200.3s'+'\x20ease;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20b'+'order:\x201px'+'\x20solid\x20rgb'+'a(59,\x20130,'+'\x20246,\x200.3)'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20font-w'+'eight:\x20600'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20min-wi'+'dth:\x20200px'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x22\x20onmouseo'+'ver=\x22this.'+'style.tran'+'sform=\x27tra'+'nslateY(-2'+'px)\x27;this.'+'style.boxS'+'hadow=\x270\x206'+'px\x2015px\x20rg'+'ba(59,130,'+'246,0.3)\x27;'+'\x22\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20onmous'+'eout=\x22this'+'.style.tra'+'nsform=\x27tr'+'anslateY(0'+')\x27;this.st'+'yle.boxSha'+'dow=\x27none\x27'+';\x22>\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20<svg'+'\x20xmlns=\x22ht'+'tp://www.w'+'3.org/2000'+'/svg\x22\x20widt'+'h=\x2218\x22\x20hei'+'ght=\x2218\x22\x20f'+'ill=\x22curre'+'ntColor\x22\x20v'+'iewBox=\x220\x20'+'0\x2016\x2016\x22>\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20<pat'+'h\x20d=\x22M8\x200a'+'8\x208\x200\x201\x200\x20'+'0\x2016A8\x208\x200'+'\x200\x200\x208\x200zM'+'4.5\x207.5a.5'+'.5\x200\x200\x201\x200'+'-1h5a.5.5\x20')+('0\x200\x201\x200\x201h'+'-5z\x22/>\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20<'+'/svg>\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20Cl'+'ean\x20IP\x20Sou'+'rce\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20</a>\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20<a\x20hre'+'f=\x22https:/'+'/github.co'+'m/arista-p'+'roject/Ari'+'sta-Panel/'+'blob/main/'+'Data.md\x22\x20t'+'arget=\x22_bl'+'ank\x22\x20style'+'=\x22\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20displ'+'ay:\x20flex;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20align-it'+'ems:\x20cente'+'r;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20gap:\x20'+'8px;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20pad'+'ding:\x2012px'+'\x2020px;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20b'+'ackground:'+'\x20linear-gr'+'adient(135'+'deg,\x20rgba('+'59,\x20130,\x202'+'46,\x200.2),\x20'+'rgba(37,\x209'+'9,\x20235,\x200.'+'3));\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20col'+'or:\x20white;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20text-de'+'coration:\x20'+'none;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20bo'+'rder-radiu'+'s:\x208px;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'transition'+':\x20all\x200.3s'+'\x20ease;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20b'+'order:\x201px'+'\x20solid\x20rgb'+'a(59,\x20130,'+'\x20246,\x200.3)'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20font-w'+'eight:\x20600'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20min-wi'+'dth:\x20200px'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x22\x20onmouseo'+'ver=\x22this.'+'style.tran'+'sform=\x27tra'+'nslateY(-2'+'px)\x27;this.'+'style.boxS'+'hadow=\x270\x206'+'px\x2015px\x20rg'+'ba(59,130,'+'246,0.3)\x27;'+'\x22\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20onmous'+'eout=\x22this'+'.style.tra'+'nsform=\x27tr'+'anslateY(0'+')\x27;this.st'+'yle.boxSha'+'dow=\x27none\x27'+';\x22>\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20<svg'+'\x20xmlns=\x22ht'+'tp://www.w'+'3.org/2000'+'/svg\x22\x20widt'+'h=\x2218\x22\x20hei'+'ght=\x2218\x22\x20f'+'ill=\x22curre'+'ntColor\x22\x20v'+'iewBox=\x220\x20'+'0\x2016\x2016\x22>\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20<pat')+('h\x20d=\x22M8\x200C'+'3.58\x200\x200\x203'+'.58\x200\x208c0\x20'+'3.54\x202.29\x20'+'6.53\x205.47\x20'+'7.59.4.07.'+'55-.17.55-'+'.38\x200-.19-'+'.01-.82-.0'+'1-1.49-2.0'+'1.37-2.53-'+'.49-2.69-.'+'94-.09-.23'+'-.48-.94-.'+'82-1.13-.2'+'8-.15-.68-'+'.52-.01-.5'+'3.63-.01\x201'+'.08.58\x201.2'+'3.82.72\x201.'+'21\x201.87.87'+'\x202.33.66.0'+'7-.52.28-.'+'87.51-1.07'+'-1.78-.2-3'+'.64-.89-3.'+'64-3.95\x200-'+'.87.31-1.5'+'9.82-2.15-'+'.08-.2-.36'+'-1.02.08-2'+'.12\x200\x200\x20.6'+'7-.21\x202.2.'+'82.64-.18\x20'+'1.32-.27\x202'+'-.27.68\x200\x20'+'1.36.09\x202\x20'+'.27\x201.53-1'+'.04\x202.2-.8'+'2\x202.2-.82.'+'44\x201.1.16\x20'+'1.92.08\x202.'+'12.51.56.8'+'2\x201.27.82\x20'+'2.15\x200\x203.0'+'7-1.87\x203.7'+'5-3.65\x203.9'+'5.29.25.54'+'.73.54\x201.4'+'8\x200\x201.07-.'+'01\x201.93-.0'+'1\x202.2\x200\x20.2'+'1.15.46.55'+'.38A8.012\x20'+'8.012\x200\x200\x20'+'0\x2016\x208c0-4'+'.42-3.58-8'+'-8-8z\x22/>\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20</svg>\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'DNS\x20Source'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20<'+'/a>\x0a\x20\x20\x20\x20</'+'div>\x0a</div'+'>\x0a<div\x20cla'+'ss=\x22arista'+'-subscribe'+'-card\x22>\x0a\x20\x20'+'\x20\x20<h3>ARIS'+'TA\x20Exclusi'+'ve\x20Subscri'+'be\x20for\x20v2r'+'ay</h3>\x0a\x20\x20'+'\x20\x20<p>Click'+'\x20to\x20copy\x20A'+'RISTA\x20v2ra'+'y\x20subscrip'+'tion\x20link<'+'/p>\x0a\x20\x20\x20\x20<b'+'utton\x20clas'+'s=\x22copy-bt'+'n\x22\x20onclick'+'=\x22copyAris'+'taSubscrib'+'e(\x27v2ray\x27)'+'\x22>Copy\x20v2r'+'ay\x20Subscri'+'be</button'+'>\x0a</div>\x0a\x0a'+'<div\x20class'+'=\x22arista-s'+'ubscribe-c'+'ard\x22>\x0a\x20\x20\x20\x20'+'<h3>ARISTA'+'\x20Exclusive'+'\x20Subscribe'+'\x20for\x20Clash'+'Meta</h3>\x0a'+'\x20\x20\x20\x20<p>Cli')+('ck\x20to\x20copy'+'\x20ARISTA\x20Cl'+'ashMeta\x20su'+'bscription'+'\x20link</p>\x0a'+'\x20\x20\x20\x20<butto'+'n\x20class=\x22c'+'opy-btn\x22\x20o'+'nclick=\x22co'+'pyAristaSu'+'bscribe(\x27c'+'lash\x27)\x22>Co'+'py\x20ClashMe'+'ta\x20Subscri'+'be</button'+'>\x0a</div>\x0a\x0a'+'<div\x20class'+'=\x22card\x22>\x0a\x0a'+'<div\x20class'+'=\x22grid\x22>\x0a<'+'div>\x0a<labe'+'l>Remote\x20D'+'NS</label>'+'\x0a<input\x20id'+'=\x22dns\x22\x20pla'+'ceholder=\x22'+'e.g.,\x208.8.'+'8.8,1.1.1.'+'1,https://'+'dns.google'+'/dns-query'+'\x22>\x0a<div\x20cl'+'ass=\x22help-'+'text\x22>Ente'+'r\x20DNS\x20serv'+'ers\x20or\x20DoH'+'\x20URLs\x20(com'+'ma-separat'+'ed,\x20e.g.,\x20'+'8.8.8.8,1.'+'1.1.1\x20or\x20h'+'ttps://dns'+'.google/dn'+'s-query)</'+'div>\x0a</div'+'>\x0a<div>\x0a<l'+'abel>Direc'+'t\x20DNS</lab'+'el>\x0a<input'+'\x20id=\x22direc'+'t\x22\x20placeho'+'lder=\x22e.g.'+',\x20127.0.0.'+'1,8.8.8.8\x22'+'>\x0a<div\x20cla'+'ss=\x22help-t'+'ext\x22>Enter'+'\x20DNS\x20serve'+'rs\x20for\x20dir'+'ect\x20connec'+'tions\x20(com'+'ma-separat'+'ed,\x20e.g.,\x20'+'127.0.0.1,'+'8.8.8.8)</'+'div>\x0a</div'+'>\x0a</div>\x0a\x0a'+'<div\x20class'+'=\x22grid\x22>\x0a<'+'div>\x0a<labe'+'l>Clean\x20IP'+'</label>\x0a<'+'input\x20id=\x22'+'cleanip\x22\x20p'+'laceholder'+'=\x22e.g.,\x208.'+'219.190.62'+',1.1.1.1\x22>'+'\x0a<div\x20clas'+'s=\x22help-te'+'xt\x22>Enter\x20'+'clean\x20IP\x20a'+'ddresses\x20f'+'or\x20bypass\x20'+'(comma-sep'+'arated,\x20e.'+'g.,\x208.219.'+'190.62,1.1'+'.1.1)</div'+'>\x0a</div>\x0a<'+'div>\x0a<labe'+'l>Domain</'+'label>\x0a<in'+'put\x20id=\x22do'+'main\x22\x20plac'+'eholder=\x22e'+'.g.,\x20zula.'+'ir,example'+'.com\x22>\x0a<di'+'v\x20class=\x22h')+('elp-text\x22>'+'Enter\x20doma'+'ins\x20for\x20ro'+'uting\x20(com'+'ma-separat'+'ed,\x20e.g.,\x20'+'zula.ir,ex'+'ample.com)'+'</div>\x0a</d'+'iv>\x0a</div>'+'\x0a\x0a<div\x20cla'+'ss=\x22grid\x22>'+'\x0a<div>\x0a<la'+'bel>SNI</l'+'abel>\x0a<inp'+'ut\x20id=\x22sni'+'\x22\x20placehol'+'der=\x22e.g.,'+'\x20example.c'+'om,cloudfl'+'are.com\x22>\x0a'+'<div\x20class'+'=\x22help-tex'+'t\x22>Enter\x20S'+'erver\x20Name'+'\x20Indicatio'+'n\x20for\x20TLS\x20'+'(comma-sep'+'arated,\x20e.'+'g.,\x20exampl'+'e.com,clou'+'dflare.com'+')</div>\x0a</'+'div>\x0a<div>'+'\x0a<label>AL'+'PN</label>'+'\x0a<select\x20i'+'d=\x22alpn\x22>\x0a'+'<option\x20va'+'lue=\x22none\x22'+'>None</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'h2\x22>HTTP/2'+'</option>\x0a'+'<option\x20va'+'lue=\x22http/'+'1.1\x22>HTTP/'+'1.1</optio'+'n>\x0a<option'+'\x20value=\x22h2'+',http/1.1\x22'+'>HTTP/2\x20+\x20'+'HTTP/1.1</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22h3\x22>HTT'+'P/3</optio'+'n>\x0a</selec'+'t>\x0a<div\x20cl'+'ass=\x22help-'+'text\x22>Appl'+'ication-La'+'yer\x20Protoc'+'ol\x20Negotia'+'tion</div>'+'\x0a</div>\x0a</'+'div>\x0a\x0a<div'+'\x20class=\x22gr'+'id\x22>\x0a<div>'+'\x0a<label>Fi'+'ngerprint<'+'/label>\x0a<s'+'elect\x20id=\x22'+'fingerprin'+'t\x22>\x0a<optio'+'n\x20value=\x22n'+'one\x22>None<'+'/option>\x0a<'+'option\x20val'+'ue=\x22chrome'+'\x22>Chrome</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22firefox'+'\x22>Firefox<'+'/option>\x0a<'+'option\x20val'+'ue=\x22safari'+'\x22>Safari</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22ios\x22>iO'+'S</option>'+'\x0a<option\x20v'+'alue=\x22andr'+'oid\x22>Andro'+'id</option'+'>\x0a<option\x20'+'value=\x22edg')+('e\x22>Edge</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22360\x22>360'+'</option>\x0a'+'<option\x20va'+'lue=\x22qq\x22>Q'+'Q</option>'+'\x0a<option\x20v'+'alue=\x22rand'+'om\x22>Random'+'</option>\x0a'+'<option\x20va'+'lue=\x22rando'+'mized\x22>Ran'+'domized</o'+'ption>\x0a</s'+'elect>\x0a<di'+'v\x20class=\x22h'+'elp-text\x22>'+'TLS\x20client'+'\x20fingerpri'+'nt</div>\x0a<'+'/div>\x0a<div'+'>\x0a<label>I'+'P\x20Version<'+'/label>\x0a<s'+'elect\x20id=\x22'+'ipver\x22>\x0a<o'+'ption\x20valu'+'e=\x22none\x22>N'+'one</optio'+'n>\x0a<option'+'\x20value=\x22ip'+'v4\x22>IPv4</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22ipv6\x22>I'+'Pv6</optio'+'n>\x0a<option'+'\x20value=\x22au'+'to\x22>Auto</'+'option>\x0a</'+'select>\x0a</'+'div>\x0a</div'+'>\x0a\x0a<div\x20cl'+'ass=\x22grid\x22'+'>\x0a<div>\x0a<l'+'abel>Netwo'+'rk</label>'+'\x0a<select\x20i'+'d=\x22network'+'\x22>\x0a<option'+'\x20value=\x22no'+'ne\x22>None</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22tcp\x22>TC'+'P</option>'+'\x0a<option\x20v'+'alue=\x22ws\x22>'+'WebSocket<'+'/option>\x0a<'+'option\x20val'+'ue=\x22h2\x22>HT'+'TP/2</opti'+'on>\x0a<optio'+'n\x20value=\x22g'+'rpc\x22>gRPC<'+'/option>\x0a<'+'option\x20val'+'ue=\x22quic\x22>'+'QUIC</opti'+'on>\x0a<optio'+'n\x20value=\x22k'+'cp\x22>KCP</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22http\x22>HT'+'TP</option'+'>\x0a</select'+'>\x0a</div>\x0a<'+'div>\x0a<labe'+'l>TLS</lab'+'el>\x0a<selec'+'t\x20id=\x22tls\x22'+'>\x0a<option\x20'+'value=\x22non'+'e\x22>None</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22enabled\x22'+'>Enabled</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22disable'+'d\x22>Disable'+'d</option>'+'\x0a</select>'+'\x0a</div>\x0a</')+('div>\x0a\x0a<div'+'\x20class=\x22gr'+'id\x22>\x0a<div>'+'\x0a<label>UD'+'P</label>\x0a'+'<select\x20id'+'=\x22udp\x22>\x0a<o'+'ption\x20valu'+'e=\x22none\x22>N'+'one</optio'+'n>\x0a<option'+'\x20value=\x22en'+'abled\x22>Ena'+'bled</opti'+'on>\x0a<optio'+'n\x20value=\x22d'+'isabled\x22>D'+'isabled</o'+'ption>\x0a</s'+'elect>\x0a</d'+'iv>\x0a</div>'+'\x0a\x0a<div\x20cla'+'ss=\x22fragme'+'nt-section'+'\x22>\x0a<div\x20cl'+'ass=\x22fragm'+'ent-toggle'+'\x22>\x0a<label\x20'+'class=\x22swi'+'tch\x22>\x0a<inp'+'ut\x20type=\x22c'+'heckbox\x22\x20i'+'d=\x22fragmen'+'t_enabled\x22'+'>\x0a<span\x20cl'+'ass=\x22slide'+'r\x22></span>'+'\x0a</label>\x0a'+'<label>Ena'+'ble\x20Fragme'+'nt</label>'+'\x0a</div>\x0a\x0a<'+'div\x20id=\x22fr'+'agment_set'+'tings\x22>\x0a<d'+'iv\x20class=\x22'+'grid\x22>\x0a<di'+'v>\x0a<label>'+'Packets</l'+'abel>\x0a<inp'+'ut\x20id=\x22fra'+'g_packets\x22'+'\x20value=\x222-'+'8\x22>\x0a<div\x20c'+'lass=\x22help'+'-text\x22>Pac'+'ket\x20fragme'+'ntation\x20ra'+'nge</div>\x0a'+'</div>\x0a<di'+'v>\x0a<label>'+'Length</la'+'bel>\x0a<inpu'+'t\x20id=\x22frag'+'_length\x22\x20v'+'alue=\x22100-'+'300\x22>\x0a<div'+'\x20class=\x22he'+'lp-text\x22>F'+'ragment\x20le'+'ngth\x20range'+'</div>\x0a</d'+'iv>\x0a</div>'+'\x0a\x0a<div\x20cla'+'ss=\x22grid\x22>'+'\x0a<div>\x0a<la'+'bel>Interv'+'al</label>'+'\x0a<input\x20id'+'=\x22frag_int'+'erval\x22\x20val'+'ue=\x2210-30\x22'+'>\x0a<div\x20cla'+'ss=\x22help-t'+'ext\x22>Fragm'+'ent\x20interv'+'al\x20range</'+'div>\x0a</div'+'>\x0a<div>\x0a<l'+'abel>Sleep'+'</label>\x0a<'+'input\x20id=\x22'+'frag_sleep'+'\x22\x20value=\x225'+'0\x22>\x0a<div\x20c'+'lass=\x22help'+'-text\x22>Sle'+'ep\x20time\x20be'+'tween\x20frag'+'ments\x20(ms)')+('</div>\x0a</d'+'iv>\x0a</div>'+'\x0a</div>\x0a</'+'div>\x0a\x0a<div'+'\x20class=\x22li'+'mit-sectio'+'n\x22>\x0a<div\x20c'+'lass=\x22grid'+'\x22>\x0a<div>\x0a<'+'label>Conf'+'ig\x20Limit</'+'label>\x0a<se'+'lect\x20id=\x22l'+'imit\x22>\x0a<op'+'tion\x20value'+'=\x22all\x22>All'+'\x20Configs</'+'option>\x0a<o'+'ption\x20valu'+'e=\x225\x22>5\x20Co'+'nfigs</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'10\x22>10\x20Con'+'figs</opti'+'on>\x0a<optio'+'n\x20value=\x222'+'0\x22>20\x20Conf'+'igs</optio'+'n>\x0a<option'+'\x20value=\x2230'+'\x22>30\x20Confi'+'gs</option'+'>\x0a<option\x20'+'value=\x2240\x22'+'>40\x20Config'+'s</option>'+'\x0a<option\x20v'+'alue=\x2250\x22>'+'50\x20Configs'+'</option>\x0a'+'<option\x20va'+'lue=\x2260\x22>6'+'0\x20Configs<'+'/option>\x0a<'+'option\x20val'+'ue=\x22100\x22>1'+'00\x20Configs'+'</option>\x0a'+'</select>\x0a'+'<div\x20class'+'=\x22help-tex'+'t\x22>Select\x20'+'number\x20of\x20'+'configurat'+'ions\x20to\x20ge'+'nerate\x20(pr'+'iority\x20giv'+'en\x20to\x20port'+'s\x202096,\x2044'+'3,\x208443,\x208'+'080)</div>'+'\x0a</div>\x0a</'+'div>\x0a</div'+'>\x0a\x0a<button'+'\x20class=\x22bt'+'n-save\x22\x20on'+'click=\x22sav'+'eSettings('+')\x22>Save\x20Se'+'ttings</bu'+'tton>\x0a<but'+'ton\x20class='+'\x22btn-reset'+'\x22\x20onclick='+'\x22resetSett'+'ings()\x22>Re'+'set\x20Settin'+'gs</button'+'>\x0a\x0a<label>'+'Subscribe\x20'+'URL\x20(V2Ray'+')</label>\x0a'+'<input\x20id='+'\x22subscribe'+'_v2ray\x22\x20re'+'adonly>\x0a<b'+'utton\x20clas'+'s=\x22btn-cop'+'y\x22\x20onclick'+'=\x22copyToCl'+'ipboard(\x27s'+'ubscribe_v'+'2ray\x27)\x22>Co'+'py\x20V2Ray\x20S'+'ubscribe</'+'button>\x0a\x0a<'+'label>Subs'+'cribe\x20URL\x20'+'(ClashMeta')+(')</label>\x0a'+'<input\x20id='+'\x22subscribe'+'_clash\x22\x20re'+'adonly>\x0a<b'+'utton\x20clas'+'s=\x22btn-cop'+'y\x22\x20onclick'+'=\x22copyToCl'+'ipboard(\x27s'+'ubscribe_c'+'lash\x27)\x22>Co'+'py\x20ClashMe'+'ta\x20Subscri'+'be</button'+'>\x0a\x0a<label>'+'Subscribe\x20'+'URL\x20(SingB'+'ox)</label'+'>\x0a<input\x20i'+'d=\x22subscri'+'be_singbox'+'\x22\x20readonly'+'>\x0a<button\x20'+'class=\x22btn'+'-copy\x22\x20onc'+'lick=\x22copy'+'ToClipboar'+'d(\x27subscri'+'be_singbox'+'\x27)\x22>Copy\x20S'+'ingBox\x20Sub'+'scribe</bu'+'tton>\x0a</di'+'v>\x0a<footer'+'>V\x201.4.0</'+'footer>\x0a<d'+'iv\x20id=\x22ale'+'rt\x22\x20class='+'\x22alert\x22></'+'div>\x0a</div'+'>\x0a<script>'+'\x0afunction\x20'+'showAlert('+'message,\x20i'+'sError\x20=\x20f'+'alse)\x20{\x0a\x20\x20'+'\x20\x20const\x20al'+'ert\x20=\x20docu'+'ment.getEl'+'ementById('+'\x27alert\x27);\x0a'+'\x20\x20\x20\x20alert.'+'textConten'+'t\x20=\x20messag'+'e;\x0a\x20\x20\x20\x20ale'+'rt.classNa'+'me\x20=\x20isErr'+'or\x20?\x20\x27aler'+'t\x20error\x27\x20:'+'\x20\x27alert\x27;\x0a'+'\x20\x20\x20\x20alert.'+'classList.'+'add(\x27show\x27'+');\x0a\x20\x20\x20\x20\x0a\x20\x20'+'\x20\x20setTimeo'+'ut(()\x20=>\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20a'+'lert.class'+'List.remov'+'e(\x27show\x27);'+'\x0a\x20\x20\x20\x20},\x2030'+'00);\x0a}\x0a\x0afu'+'nction\x20tog'+'gleFragmen'+'tSettings('+')\x20{\x0a\x20\x20\x20\x20co'+'nst\x20enable'+'d\x20=\x20docume'+'nt.getElem'+'entById(\x27f'+'ragment_en'+'abled\x27).ch'+'ecked;\x0a\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27frag'+'ment_setti'+'ngs\x27).styl'+'e.display\x20'+'=\x20enabled\x20'+'?\x20\x27grid\x27\x20:'+'\x20\x27none\x27;\x0a}'+'\x0a\x0aasync\x20fu'+'nction\x20cop'+'yAristaSub'+'scribe(typ'+'e)\x20{\x0a\x20\x20\x20\x20t'+'ry\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20const\x20u')+('rl\x20=\x20type\x20'+'===\x20\x27v2ray'+'\x27\x20?\x20\x27')+ARISTA_URL+'\x27\x20:\x20\x27'+CLASH_ARISTA_URL+('\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20await\x20nav'+'igator.cli'+'pboard.wri'+'teText(url'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20showAlert'+'(\x27ARISTA\x20\x27'+'\x20+\x20type\x20+\x20'+'\x27\x20subscrip'+'tion\x20link\x20'+'copied\x20suc'+'cessfully!'+'\x27);\x0a\x20\x20\x20\x20}\x20'+'catch\x20(err'+'or)\x20{\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20showAl'+'ert(\x27Faile'+'d\x20to\x20copy\x20'+'ARISTA\x20sub'+'scription\x20'+'link!\x27,\x20tr'+'ue);\x0a\x20\x20\x20\x20}'+'\x0a}\x0a\x0a\x20\x20asyn'+'c\x20function'+'\x20saveSetti'+'ngs(){\x0a\x20\x20\x20'+'\x20try\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20const'+'\x20data\x20=\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20limit:\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27limit\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20dns:\x20docu'+'ment.getEl'+'ementById('+'\x27dns\x27).val'+'ue,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20dire'+'ct:\x20docume'+'nt.getElem'+'entById(\x27d'+'irect\x27).va'+'lue,\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20cle'+'anip:\x20docu'+'ment.getEl'+'ementById('+'\x27cleanip\x27)'+'.value,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'domain:\x20do'+'cument.get'+'ElementByI'+'d(\x27domain\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20sni:\x20docu'+'ment.getEl'+'ementById('+'\x27sni\x27).val'+'ue,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20alpn'+':\x20document'+'.getElemen'+'tById(\x27alp'+'n\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20fingerp'+'rint:\x20docu'+'ment.getEl'+'ementById('+'\x27fingerpri'+'nt\x27).value'+',\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20ipver:'+'\x20document.'+'getElement'+'ById(\x27ipve'+'r\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20network'+':\x20document'+'.getElemen'+'tById(\x27net'+'work\x27).val'+'ue,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20tls:'+'\x20document.'+'getElement'+'ById(\x27tls\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20udp:\x20docu'+'ment.getEl'+'ementById('+('\x27udp\x27).val'+'ue,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20frag'+'ment:\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20enable'+'d:\x20documen'+'t.getEleme'+'ntById(\x27fr'+'agment_ena'+'bled\x27).che'+'cked,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20packets:'+'\x20document.'+'getElement'+'ById(\x27frag'+'_packets\x27)'+'.value,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20length'+':\x20document'+'.getElemen'+'tById(\x27fra'+'g_length\x27)'+'.value,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20interv'+'al:\x20docume'+'nt.getElem'+'entById(\x27f'+'rag_interv'+'al\x27).value'+',\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20sl'+'eep:\x20docum'+'ent.getEle'+'mentById(\x27'+'frag_sleep'+'\x27).value,\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20}\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20};\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20const\x20re'+'sponse\x20=\x20a'+'wait\x20fetch'+'(\x27/api/set'+'tings\x27,\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20method:\x20'+'\x27POST\x27,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'headers:\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x27Co'+'ntent-Type'+'\x27:\x20\x27applic'+'ation/json'+'\x27,\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20},\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'body:\x20JSON'+'.stringify'+'(data)\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20});\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20if\x20('+'response.o'+'k)\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20sho'+'wAlert(\x27Se'+'ttings\x20sav'+'ed\x20success'+'fully!\x27);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20generate'+'Subscribe('+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20}\x20else\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20showAler'+'t(\x27Error\x20s'+'aving\x20sett'+'ings!\x27,\x20tr'+'ue);\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20}\x0a\x20\x20\x20\x20}'+'\x20catch\x20(er'+'ror)\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20showA'+'lert(\x27Erro'+'r\x20saving\x20s'+'ettings!\x27,'+'\x20true);\x0a\x20\x20'+'\x20\x20}\x0a}\x0a\x0aasy'+'nc\x20functio'+'n\x20resetSet'+'tings()\x20{\x0a'+'\x20\x20\x20\x20const\x20'+'alertOverl')+('ay\x20=\x20docum'+'ent.create'+'Element(\x27d'+'iv\x27);\x0a\x20\x20\x20\x20'+'alertOverl'+'ay.style.p'+'osition\x20=\x20'+'\x27fixed\x27;\x0a\x20'+'\x20\x20\x20alertOv'+'erlay.styl'+'e.top\x20=\x20\x270'+'\x27;\x0a\x20\x20\x20\x20ale'+'rtOverlay.'+'style.left'+'\x20=\x20\x270\x27;\x0a\x20\x20'+'\x20\x20alertOve'+'rlay.style'+'.width\x20=\x20\x27'+'100%\x27;\x0a\x20\x20\x20'+'\x20alertOver'+'lay.style.'+'height\x20=\x20\x27'+'100%\x27;\x0a\x20\x20\x20'+'\x20alertOver'+'lay.style.'+'background'+'Color\x20=\x20\x27r'+'gba(0,\x200,\x20'+'0,\x200.7)\x27;\x0a'+'\x20\x20\x20\x20alertO'+'verlay.sty'+'le.display'+'\x20=\x20\x27flex\x27;'+'\x0a\x20\x20\x20\x20alert'+'Overlay.st'+'yle.justif'+'yContent\x20='+'\x20\x27center\x27;'+'\x0a\x20\x20\x20\x20alert'+'Overlay.st'+'yle.alignI'+'tems\x20=\x20\x27ce'+'nter\x27;\x0a\x20\x20\x20'+'\x20alertOver'+'lay.style.'+'zIndex\x20=\x20\x27'+'10000\x27;\x0a\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20con'+'st\x20alertBo'+'x\x20=\x20docume'+'nt.createE'+'lement(\x27di'+'v\x27);\x0a\x20\x20\x20\x20a'+'lertBox.st'+'yle.backgr'+'ound\x20=\x20\x27li'+'near-gradi'+'ent(135deg'+',\x20#f97316\x20'+'0%,\x20#ea580'+'c\x20100%)\x27;\x0a'+'\x20\x20\x20\x20alertB'+'ox.style.p'+'adding\x20=\x20\x27'+'25px\x27;\x0a\x20\x20\x20'+'\x20alertBox.'+'style.bord'+'erRadius\x20='+'\x20\x2715px\x27;\x0a\x20'+'\x20\x20\x20alertBo'+'x.style.bo'+'xShadow\x20=\x20'+'\x270\x204px\x2020p'+'x\x20rgba(0,\x20'+'0,\x200,\x200.3)'+'\x27;\x0a\x20\x20\x20\x20ale'+'rtBox.styl'+'e.color\x20=\x20'+'\x27white\x27;\x0a\x20'+'\x20\x20\x20alertBo'+'x.style.te'+'xtAlign\x20=\x20'+'\x27center\x27;\x0a'+'\x20\x20\x20\x20alertB'+'ox.style.m'+'axWidth\x20=\x20'+'\x27400px\x27;\x0a\x20'+'\x20\x20\x20alertBo'+'x.style.wi'+'dth\x20=\x20\x2790%'+'\x27;\x0a\x20\x20\x20\x20\x0a\x20\x20'+'\x20\x20const\x20me'+'ssage\x20=\x20do'+'cument.cre'+'ateElement'+'(\x27p\x27);\x0a\x20\x20\x20'+'\x20message.t'+'extContent'+'\x20=\x20\x27Are\x20yo'+'u\x20sure\x20you')+('\x20want\x20to\x20r'+'eset\x20all\x20s'+'ettings?\x27;'+'\x0a\x20\x20\x20\x20messa'+'ge.style.m'+'arginBotto'+'m\x20=\x20\x2720px\x27'+';\x0a\x20\x20\x20\x20mess'+'age.style.'+'fontSize\x20='+'\x20\x2716px\x27;\x0a\x20'+'\x20\x20\x20message'+'.style.fon'+'tWeight\x20=\x20'+'\x27600\x27;\x0a\x20\x20\x20'+'\x20\x0a\x20\x20\x20\x20cons'+'t\x20buttonCo'+'ntainer\x20=\x20'+'document.c'+'reateEleme'+'nt(\x27div\x27);'+'\x0a\x20\x20\x20\x20butto'+'nContainer'+'.style.dis'+'play\x20=\x20\x27fl'+'ex\x27;\x0a\x20\x20\x20\x20b'+'uttonConta'+'iner.style'+'.gap\x20=\x20\x2715'+'px\x27;\x0a\x20\x20\x20\x20b'+'uttonConta'+'iner.style'+'.justifyCo'+'ntent\x20=\x20\x27c'+'enter\x27;\x0a\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20con'+'st\x20confirm'+'Button\x20=\x20d'+'ocument.cr'+'eateElemen'+'t(\x27button\x27'+');\x0a\x20\x20\x20\x20con'+'firmButton'+'.textConte'+'nt\x20=\x20\x27Yes\x27'+';\x0a\x20\x20\x20\x20conf'+'irmButton.'+'style.padd'+'ing\x20=\x20\x2710p'+'x\x2020px\x27;\x0a\x20'+'\x20\x20\x20confirm'+'Button.sty'+'le.border\x20'+'=\x20\x27none\x27;\x0a'+'\x20\x20\x20\x20confir'+'mButton.st'+'yle.border'+'Radius\x20=\x20\x27'+'8px\x27;\x0a\x20\x20\x20\x20'+'confirmBut'+'ton.style.'+'background'+'\x20=\x20\x27linear'+'-gradient('+'135deg,\x20#e'+'f4444\x200%,\x20'+'#dc2626\x2010'+'0%)\x27;\x0a\x20\x20\x20\x20'+'confirmBut'+'ton.style.'+'color\x20=\x20\x27w'+'hite\x27;\x0a\x20\x20\x20'+'\x20confirmBu'+'tton.style'+'.cursor\x20=\x20'+'\x27pointer\x27;'+'\x0a\x20\x20\x20\x20confi'+'rmButton.s'+'tyle.fontW'+'eight\x20=\x20\x276'+'00\x27;\x0a\x0a\x20\x20\x20\x20'+'const\x20canc'+'elButton\x20='+'\x20document.'+'createElem'+'ent(\x27butto'+'n\x27);\x0a\x20\x20\x20\x20c'+'ancelButto'+'n.textCont'+'ent\x20=\x20\x27No\x27'+';\x0a\x20\x20\x20\x20canc'+'elButton.s'+'tyle.paddi'+'ng\x20=\x20\x2710px'+'\x2020px\x27;\x0a\x20\x20'+'\x20\x20cancelBu'+'tton.style'+'.border\x20=\x20'+'\x27none\x27;\x0a\x20\x20'+'\x20\x20cancelBu')+('tton.style'+'.borderRad'+'ius\x20=\x20\x278px'+'\x27;\x0a\x20\x20\x20\x20can'+'celButton.'+'style.back'+'ground\x20=\x20\x27'+'linear-gra'+'dient(135d'+'eg,\x20#22c55'+'e\x200%,\x20#16a'+'34a\x20100%)\x27'+';\x0a\x20\x20\x20\x20canc'+'elButton.s'+'tyle.color'+'\x20=\x20\x27white\x27'+';\x0a\x20\x20\x20\x20canc'+'elButton.s'+'tyle.curso'+'r\x20=\x20\x27point'+'er\x27;\x0a\x20\x20\x20\x20c'+'ancelButto'+'n.style.fo'+'ntWeight\x20='+'\x20\x27600\x27;\x0a\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20but'+'tonContain'+'er.appendC'+'hild(confi'+'rmButton);'+'\x0a\x20\x20\x20\x20butto'+'nContainer'+'.appendChi'+'ld(cancelB'+'utton);\x0a\x20\x20'+'\x20\x20alertBox'+'.appendChi'+'ld(message'+');\x0a\x20\x20\x20\x20ale'+'rtBox.appe'+'ndChild(bu'+'ttonContai'+'ner);\x0a\x20\x20\x20\x20'+'alertOverl'+'ay.appendC'+'hild(alert'+'Box);\x0a\x20\x20\x20\x20'+'document.b'+'ody.append'+'Child(aler'+'tOverlay);'+'\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20'+'return\x20new'+'\x20Promise(('+'resolve)\x20='+'>\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20confirmB'+'utton.oncl'+'ick\x20=\x20()\x20='+'>\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.body.'+'removeChil'+'d(alertOve'+'rlay);\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20r'+'esolve(tru'+'e);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20};\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20cancelBu'+'tton.oncli'+'ck\x20=\x20()\x20=>'+'\x20{\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.body.r'+'emoveChild'+'(alertOver'+'lay);\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20re'+'solve(fals'+'e);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20};\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20alertOve'+'rlay.oncli'+'ck\x20=\x20(e)\x20='+'>\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20if\x20('+'e.target\x20='+'==\x20alertOv'+'erlay)\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.body.r'+'emoveChild'+'(alertOver'+'lay);\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20resolve(')+('false);\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'}\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'};\x0a\x20\x20\x20\x20}).'+'then(async'+'\x20(confirme'+'d)\x20=>\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20if\x20('+'confirmed)'+'\x20{\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'limit\x27).va'+'lue\x20=\x20\x27all'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'dns\x27).valu'+'e\x20=\x20\x27\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.g'+'etElementB'+'yId(\x27direc'+'t\x27).value\x20'+'=\x20\x27\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27cleanip'+'\x27).value\x20='+'\x20\x27\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27domain\x27)'+'.value\x20=\x20\x27'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'sni\x27).valu'+'e\x20=\x20\x27\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.g'+'etElementB'+'yId(\x27alpn\x27'+').value\x20=\x20'+'\x27none\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.g'+'etElementB'+'yId(\x27finge'+'rprint\x27).v'+'alue\x20=\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27ipver\x27).'+'value\x20=\x20\x27n'+'one\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27network'+'\x27).value\x20='+'\x20\x27none\x27;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27tls\x27'+').value\x20=\x20'+'\x27none\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.g'+'etElementB'+'yId(\x27udp\x27)'+'.value\x20=\x20\x27'+'none\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27fragme'+'nt_enabled'+'\x27).checked'+'\x20=\x20false;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27fra'+'g_packets\x27'+').value\x20=\x20'+'\x272-8\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_l'+'ength\x27).va')+('lue\x20=\x20\x27100'+'-300\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_i'+'nterval\x27).'+'value\x20=\x20\x271'+'0-30\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_s'+'leep\x27).val'+'ue\x20=\x20\x2750\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20togg'+'leFragment'+'Settings()'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20try'+'\x20{\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20a'+'wait\x20fetch'+'(\x27/api/set'+'tings\x27,\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'method:\x20\x27P'+'OST\x27,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20head'+'ers:\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x27Content-'+'Type\x27:\x20\x27ap'+'plication/'+'json\x27,\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20},\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'body:\x20JSON'+'.stringify'+'({})\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20});\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20showAlert'+'(\x27Settings'+'\x20reset\x20suc'+'cessfully!'+'\x27);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'generateSu'+'bscribe();'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20}\x20catch'+'\x20(error)\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20sho'+'wAlert(\x27Er'+'ror\x20resett'+'ing\x20settin'+'gs!\x27,\x20true'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20}\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20}\x20els'+'e\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20show'+'Alert(\x27Res'+'et\x20cancell'+'ed\x27,\x20false'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20}\x0a\x20\x20\x20\x20});'+'\x0a}\x0a\x0afuncti'+'on\x20generat'+'eSubscribe'+'()\x20{\x0a\x20\x20\x20\x20c'+'onst\x20baseU'+'rl\x20=\x20windo'+'w.location'+'.origin;\x0a\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27su'+'bscribe_v2'+'ray\x27).valu'+'e\x20=\x20baseUr'+'l\x20+\x20\x27/api/'+'configs\x27;\x0a'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27s'+'ubscribe_c'+'lash\x27).val'+'ue\x20=\x20baseU')+('rl\x20+\x20\x27/api'+'/configs?f'+'ormat=clas'+'h\x27;\x0a\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27subscri'+'be_singbox'+'\x27).value\x20='+'\x20baseUrl\x20+'+'\x20\x27/api/con'+'figs?forma'+'t=singbox\x27'+';\x0a}\x0a\x0aasync'+'\x20function\x20'+'copyToClip'+'board(elem'+'entId)\x20{\x0a\x20'+'\x20\x20\x20try\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20con'+'st\x20copyTex'+'t\x20=\x20docume'+'nt.getElem'+'entById(el'+'ementId);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20co'+'pyText.sel'+'ect();\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20copyT'+'ext.setSel'+'ectionRang'+'e(0,\x2099999'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20await\x20nav'+'igator.cli'+'pboard.wri'+'teText(cop'+'yText.valu'+'e);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20showAler'+'t(\x27Copied\x20'+'to\x20clipboa'+'rd!\x27);\x0a\x20\x20\x20'+'\x20}\x20catch\x20('+'error)\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20sho'+'wAlert(\x27Fa'+'iled\x20to\x20co'+'py!\x27,\x20true'+');\x0a\x20\x20\x20\x20}\x0a}'+'\x0a\x0a\x20\x20\x20async'+'\x20function\x20'+'loadSettin'+'gs()\x20{\x0a\x20\x20\x20'+'\x20try\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20const'+'\x20response\x20'+'=\x20await\x20fe'+'tch(\x27/api/'+'settings\x27)'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'const\x20s\x20=\x20'+'await\x20resp'+'onse.json('+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'if\x20(s)\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27limi'+'t\x27).value\x20'+'=\x20s.limit\x20'+'||\x20\x27all\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27dns'+'\x27).value\x20='+'\x20s.dns\x20||\x20'+'\x27\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27direct\x27).'+'value\x20=\x20s.'+'direct\x20||\x20'+'\x27\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27cleanip\x27)'+'.value\x20=\x20s'+'.cleanip\x20|'+'|\x20\x27\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27domain\x27'+').value\x20=\x20')+('s.domain\x20|'+'|\x20\x27\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27sni\x27).v'+'alue\x20=\x20s.s'+'ni\x20||\x20\x27\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27alp'+'n\x27).value\x20'+'=\x20s.alpn\x20|'+'|\x20\x27none\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27fin'+'gerprint\x27)'+'.value\x20=\x20s'+'.fingerpri'+'nt\x20||\x20\x27non'+'e\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27ipver\x27).v'+'alue\x20=\x20s.i'+'pver\x20||\x20\x27n'+'one\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27network'+'\x27).value\x20='+'\x20s.network'+'\x20||\x20\x27none\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27t'+'ls\x27).value'+'\x20=\x20s.tls\x20|'+'|\x20\x27none\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27udp'+'\x27).value\x20='+'\x20s.udp\x20||\x20'+'\x27none\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20if\x20(s.f'+'ragment)\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27fragment'+'_enabled\x27)'+'.checked\x20='+'\x20s.fragmen'+'t.enabled\x20'+'||\x20false;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27frag_pack'+'ets\x27).valu'+'e\x20=\x20s.frag'+'ment.packe'+'ts\x20||\x20\x272-8'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_l'+'ength\x27).va'+'lue\x20=\x20s.fr'+'agment.len'+'gth\x20||\x20\x2710'+'0-300\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27f'+'rag_interv'+'al\x27).value'+'\x20=\x20s.fragm'+'ent.interv'+'al\x20||\x20\x2710-'+'30\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27frag'+'_sleep\x27).v')+('alue\x20=\x20s.f'+'ragment.sl'+'eep\x20||\x20\x2750'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20}\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20}\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20toggle'+'FragmentSe'+'ttings();\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20ge'+'nerateSubs'+'cribe();\x0a\x20'+'\x20\x20\x20}\x20catch'+'\x20(error)\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20c'+'onsole.err'+'or(\x27Error\x20'+'loading\x20se'+'ttings:\x27,\x20'+'error);\x0a\x20\x20'+'\x20\x20}\x0a}\x0a\x0adoc'+'ument.getE'+'lementById'+'(\x27fragment'+'_enabled\x27)'+'.addEventL'+'istener(\x27c'+'hange\x27,\x20to'+'ggleFragme'+'ntSettings'+');\x0awindow.'+'onload\x20=\x20l'+'oadSetting'+'s;\x0a</scrip'+'t>\x0a</body>'+'\x0a</html>'));}


//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
