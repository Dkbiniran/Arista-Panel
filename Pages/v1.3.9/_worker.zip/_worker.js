// ==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------

const _0x_0xe79f69=(function(){let _0x1e9041=!![];return function(_0x575e27,_0x54782a){const _0x359da2=_0x1e9041?function(){if(_0x54782a){const _0x4e21ff=_0x54782a['apply'](_0x575e27,arguments);_0x54782a=null;return _0x4e21ff;}}:function(){};_0x1e9041=![];return _0x359da2;};}());const _0x_0x555231=_0x_0xe79f69(this,function(){return _0x_0x555231['toString']()['search']('(((.+)+)+)'+'+$')['toString']()['constructo'+'r'](_0x_0x555231)['search']('(((.+)+)+)'+'+$');});_0x_0x555231();const _0x_0x9adec1=(function(){let _0x13dc0b=!![];return function(_0x1c32cd,_0x2173b4){const _0x4a91e9=_0x13dc0b?function(){if(_0x2173b4){const _0x55d5c8=_0x2173b4['apply'](_0x1c32cd,arguments);_0x2173b4=null;return _0x55d5c8;}}:function(){};_0x13dc0b=![];return _0x4a91e9;};}());const _0x_0x3f0c7d=_0x_0x9adec1(this,function(){const _0x1e48f8=function(){let _0x21c03c;try{_0x21c03c=Function('return\x20(fu'+'nction()\x20'+('{}.constru'+'ctor(\x22retu'+'rn\x20this\x22)('+'\x20)')+');')();}catch(_0x240ff7){_0x21c03c=window;}return _0x21c03c;};const _0x43b041=_0x1e48f8();const _0x138021=_0x43b041['console']=_0x43b041['console']||{};const _0x34e253=['log','warn','info','error','exception','table','trace'];for(let _0x33089b=0x0;_0x33089b<_0x34e253['length'];_0x33089b++){const _0x42ba51=_0x_0x9adec1['constructo'+'r']['prototype']['bind'](_0x_0x9adec1);const _0x15c124=_0x34e253[_0x33089b];const _0x2a5bd2=_0x138021[_0x15c124]||_0x42ba51;_0x42ba51['__proto__']=_0x_0x9adec1['bind'](_0x_0x9adec1);_0x42ba51['toString']=_0x2a5bd2['toString']['bind'](_0x2a5bd2);_0x138021[_0x15c124]=_0x42ba51;}});_0x_0x3f0c7d();const ARISTA_TAG='ARISTA🔥';const SETTINGS_KV_KEY='settings';const CONFIG_SOURCE_URLS=['https://cd'+'n.jsdelivr'+'.net/gh/Ma'+'hsaNetConf'+'igTopic/co'+'nfig@main/'+'xray_final'+'.txt','https://cd'+'n.jsdelivr'+'.net/gh/As'+'hkan-m/v2r'+'ay@main/Su'+'b.txt','https://cd'+'n.jsdelivr'+'.net/gh/Ra'+'yan-Config'+'/C-Sub@mai'+'n/configs/'+'proxy.txt'];const ARISTA_URL='https://ra'+'w.githubus'+'ercontent.'+'com/hamedp'+'-71/Arista'+'_HP/refs/h'+'eads/main/'+'Arista.txt';const CLASH_ARISTA_URL='https://ra'+'w.githubus'+'ercontent.'+'com/hamedp'+'-71/Vless-'+'Trojan_cla'+'sh/refs/he'+'ads/main/h'+'p.yaml';let ALL_CONFIGS=[];const PORT_PRIORITIES=[0x830,0x1bb,0x20fb,0x1f90];const CONFIG_LIMITS=[0x5,0xa,0x14,0x1e,0x28,0x32,0x3c,0x64,'all'];function isIP(_0x450fcd){return/^(\d{1,3}\.){3}\d{1,3}$/['test'](_0x450fcd)||/^([0-9a-fA-F]*:){2,7}[0-9a-fA-F]*$/['test'](_0x450fcd);}function sortConfigsByPortPriority(_0x2868cf){return _0x2868cf['sort']((_0x3d9974,_0x1a24e7)=>{const _0x59a9f0=_0x3bfc33=>{try{const _0x3b5389=new URL(_0x3bfc33);const _0x3379ae=parseInt(_0x3b5389['port'])||0x1bb;const _0x58a33d=PORT_PRIORITIES['indexOf'](_0x3379ae);return _0x58a33d!==-0x1?_0x58a33d:PORT_PRIORITIES['length'];}catch{return PORT_PRIORITIES['length'];}};const _0x31e439=_0x59a9f0(_0x3d9974);const _0x535e7c=_0x59a9f0(_0x1a24e7);if(_0x31e439!==_0x535e7c){return _0x31e439-_0x535e7c;}try{const _0x16e07c=parseInt(new URL(_0x3d9974)['port'])||0x1bb;const _0x6c47db=parseInt(new URL(_0x1a24e7)['port'])||0x1bb;return _0x16e07c-_0x6c47db;}catch{return 0x0;}});}function applyConfigLimit(_0x1934fa,_0x392097){if(_0x392097==='all')return _0x1934fa;const _0x5ba4ee=parseInt(_0x392097);if(isNaN(_0x5ba4ee)||_0x5ba4ee<=0x0)return _0x1934fa;const _0x40cdcc=sortConfigsByPortPriority(_0x1934fa);const _0x445b83=_0x40cdcc['filter'](_0xf2d087=>{try{const _0xb6a63=new URL(_0xf2d087);const _0x2ce28f=parseInt(_0xb6a63['port'])||0x1bb;return PORT_PRIORITIES['includes'](_0x2ce28f);}catch{return![];}});const _0x2fecc4=_0x40cdcc['filter'](_0x23ff87=>{try{const _0x49925a=new URL(_0x23ff87);const _0x5e7ff2=parseInt(_0x49925a['port'])||0x1bb;return!PORT_PRIORITIES['includes'](_0x5e7ff2);}catch{return![];}});const _0x5248d0=Math['min'](_0x445b83['length'],Math['ceil'](_0x5ba4ee*0.6));const _0x34255e=Math['min'](_0x2fecc4['length'],_0x5ba4ee-_0x5248d0);return[..._0x445b83['slice'](0x0,_0x5248d0),..._0x2fecc4['slice'](0x0,_0x34255e)]['slice'](0x0,_0x5ba4ee);}async function updateConfigs(){try{let _0x28ef84=[];for(const _0x206853 of CONFIG_SOURCE_URLS){const _0x35bd66=await fetch(_0x206853);if(!_0x35bd66['ok'])continue;const _0x77255d=await _0x35bd66['text']();let _0x5a2d9b=_0x77255d['split']('\x0a')['filter'](_0x12423e=>_0x12423e['startsWith']('vless://'));_0x28ef84=_0x28ef84['concat'](_0x5a2d9b);}ALL_CONFIGS=[...new Set(_0x28ef84)];console['log']('Updated\x20co'+'nfigs:\x20'+ALL_CONFIGS['length']+('\x20unique\x20co'+'nfiguratio'+'ns\x20loaded'));}catch(_0x8f358b){console['error']('Error\x20upda'+'ting\x20confi'+'gs:',_0x8f358b);}}async function checkConfigStatus(){try{console['log']('Config\x20Sta'+'tus:',{'configsLoaded':ALL_CONFIGS['length'],'configsSample':ALL_CONFIGS['slice'](0x0,0x3)});return!![];}catch(_0x5c287d){console['error']('Config\x20Sta'+'tus\x20Check\x20'+'Failed:',_0x5c287d);return![];}}function applyFragmentSettings(_0x1fbccb,_0x1e99cf){if(!_0x1e99cf||Object['keys'](_0x1e99cf)['length']===0x0||!_0x1e99cf['enabled']){return _0x1fbccb;}try{const _0x2d94e6=new URL(_0x1fbccb);_0x2d94e6['searchPara'+'ms']['set']('fragment','true');if(_0x1e99cf['packets'])_0x2d94e6['searchPara'+'ms']['set']('fragmentPa'+'ckets',_0x1e99cf['packets']);if(_0x1e99cf['length'])_0x2d94e6['searchPara'+'ms']['set']('fragmentLe'+'ngth',_0x1e99cf['length']);if(_0x1e99cf['interval'])_0x2d94e6['searchPara'+'ms']['set']('fragmentIn'+'terval',_0x1e99cf['interval']);if(_0x1e99cf['sleep'])_0x2d94e6['searchPara'+'ms']['set']('fragmentSl'+'eep',_0x1e99cf['sleep']['toString']());return _0x2d94e6['toString']();}catch(_0x26e89c){return _0x1fbccb;}}function applyTag(_0x203f25){try{const _0x4f5d09=new URL(_0x203f25);_0x4f5d09['hash']=ARISTA_TAG;return _0x4f5d09['toString']();}catch{return _0x203f25;}}function applyCustomSettings(_0x2d8d03,_0x4a2532){try{const _0x5493bb=new URL(_0x2d8d03);const _0x5759c6=Object['fromEntrie'+'s'](_0x5493bb['searchPara'+'ms']['entries']());const _0x11ce39=_0x5493bb['hostname'];const _0x53bc24=_0x5759c6['sni']||_0x5759c6['host']||_0x11ce39;const _0x83c7e1=(_0x5c7728,_0x1cabbc)=>{if(_0x4a2532[_0x5c7728]&&_0x4a2532[_0x5c7728]!=='none'){return _0x4a2532[_0x5c7728];}return _0x5759c6[_0x1cabbc]||undefined;};if(_0x4a2532['dns']&&_0x4a2532['dns']!=='none'){_0x5493bb['searchPara'+'ms']['set']('dns',_0x4a2532['dns']);}if(_0x4a2532['direct']&&_0x4a2532['direct']!=='none'){_0x5493bb['searchPara'+'ms']['set']('direct',_0x4a2532['direct']);}const _0x5480a3=_0x83c7e1('cleanip','cleanip');const _0x43edbf=(_0x5480a3||'')['split'](',')['map'](_0x144f4a=>_0x144f4a['trim']())['filter'](Boolean);if(_0x43edbf['length']>0x0){_0x5493bb['hostname']=_0x43edbf[0x0];}const _0x12ecd6=_0x83c7e1('domain','domain');const _0x51bd82=_0x83c7e1('domain','host')||_0x12ecd6;if(_0x51bd82&&_0x51bd82!=='none'){_0x5493bb['searchPara'+'ms']['set']('host',_0x51bd82);_0x5493bb['searchPara'+'ms']['set']('domain',_0x51bd82);}const _0x565bf0=_0x83c7e1('sni','sni');const _0x1dd2a3=(_0x565bf0||'')['split'](',')['map'](_0x1adde7=>_0x1adde7['trim']())['filter'](Boolean);let _0x117ca3=_0x1dd2a3[0x0]||_0x12ecd6||_0x51bd82||_0x53bc24;if(_0x43edbf['length']>0x0&&isIP(_0x5493bb['hostname'])){if(!_0x117ca3||isIP(_0x117ca3)){_0x117ca3=_0x53bc24||'cloudflare'+'.com';}_0x5493bb['searchPara'+'ms']['set']('sni',_0x117ca3);}else if(_0x565bf0&&_0x565bf0!=='none'){_0x5493bb['searchPara'+'ms']['set']('sni',_0x565bf0);}else if(_0x51bd82&&_0x51bd82!=='none'){_0x5493bb['searchPara'+'ms']['set']('sni',_0x51bd82);}if(_0x4a2532['alpn']&&_0x4a2532['alpn']!=='none'){_0x5493bb['searchPara'+'ms']['set']('alpn',_0x4a2532['alpn']);}if(_0x4a2532['ipver']&&_0x4a2532['ipver']!=='none'){_0x5493bb['searchPara'+'ms']['set']('ipver',_0x4a2532['ipver']);}if(_0x4a2532['network']&&_0x4a2532['network']!=='none'){_0x5493bb['searchPara'+'ms']['set']('type',_0x4a2532['network']);}if(_0x4a2532['tls']&&_0x4a2532['tls']!=='none'){_0x5493bb['searchPara'+'ms']['set']('security',_0x4a2532['tls']==='enabled'?'tls':'none');}if(_0x4a2532['udp']&&_0x4a2532['udp']!=='none'){_0x5493bb['searchPara'+'ms']['set']('udp',_0x4a2532['udp']==='enabled'?'true':'false');}if(_0x4a2532['fingerprin'+'t']&&_0x4a2532['fingerprin'+'t']!=='none'){_0x5493bb['searchPara'+'ms']['set']('fp',_0x4a2532['fingerprin'+'t']);}return _0x5493bb['toString']();}catch(_0x2c1f43){return _0x2d8d03;}}function vlessToClashMeta(_0x10c5bb,_0x1fd26b,_0x394bb3,_0x244a73){try{const _0x5990f8=new URL(_0x10c5bb);const _0x421318=Object['fromEntrie'+'s'](_0x5990f8['searchPara'+'ms']['entries']());const _0x2cbcd6='ARISTA🔥-'+_0x394bb3;const _0x9ddc08=(_0xce4f28,_0x449e48)=>{if(_0x244a73[_0xce4f28]&&_0x244a73[_0xce4f28]!=='none'){return _0x244a73[_0xce4f28];}return _0x421318[_0x449e48]||undefined;};const _0x37677b=(_0x1a0f47,_0x23aa11)=>{if(_0x244a73[_0x1a0f47]&&_0x244a73[_0x1a0f47]!=='none'){return _0x244a73[_0x1a0f47]==='enabled';}return _0x421318[_0x23aa11]==='true'||undefined;};const _0x1eb8df=_0x9ddc08('network','type')||'tcp';const _0xe7f903=_0x37677b('tls','security');const _0x12fd12=_0x37677b('udp','udp')!==![];const _0x34788e=_0x9ddc08('cleanip','cleanip');const _0x4db22a=(_0x34788e||'')['split'](',')['map'](_0x199717=>_0x199717['trim']())['filter'](Boolean);const _0x50b289=_0x9ddc08('domain','domain');const _0xce55c0=_0x9ddc08('domain','host')||_0x50b289;const _0x3ae19c=isIP(_0x5990f8['hostname'])?_0x5990f8['hostname']:_0x4db22a[0x0]||_0x50b289||_0x5990f8['hostname'];let _0x345fc5=_0x50b289||_0x421318['host']||_0x9ddc08('sni','sni')||_0x5990f8['hostname'];if(isIP(_0x3ae19c)&&isIP(_0x345fc5)){_0x345fc5=_0x421318['host']||_0x5990f8['hostname']||'cloudflare'+'.com';}const _0xd19950=_0x9ddc08('fingerprin'+'t','fp')||'chrome';const _0x3933a7=_0x9ddc08('alpn','alpn');const _0x2da95a={'name':_0x2cbcd6,'type':'vless','server':_0x3ae19c,'port':parseInt(_0x5990f8['port'])||0x1bb,'uuid':_0x5990f8['username']['split']('@')[0x0],'network':_0x1eb8df,'tls':_0xe7f903!==![],'udp':_0x12fd12,'skip-cert-verify':![],'tcp-fast-open':!![],'fast-open':!![],'servername':_0x345fc5,'flow':_0x421318['flow']||'','client-fingerprint':_0xd19950,'packet-encoding':'xudp'};if(_0x244a73['dns']&&_0x244a73['dns']!=='none'){_0x2da95a['dns']=_0x244a73['dns']['split'](',')['map'](_0x4f4012=>_0x4f4012['trim']());}if(_0x244a73['direct']&&_0x244a73['direct']!=='none'){if(_0x2da95a['dns']){if(!_0x2da95a['fallback-d'+'ns']){_0x2da95a['fallback-d'+'ns']=_0x244a73['direct']['split'](',')['map'](_0x4c8d90=>_0x4c8d90['trim']());}}else{_0x2da95a['dns']=_0x244a73['direct']['split'](',')['map'](_0x11a64e=>_0x11a64e['trim']());}}if(_0x3933a7&&_0x3933a7!=='none'){_0x2da95a['alpn']=_0x3933a7['split'](',')['map'](_0x445d35=>_0x445d35['trim']());}else if(_0xe7f903){_0x2da95a['alpn']=['h2','http/1.1'];}if(_0x244a73['fragment']&&_0x244a73['fragment']['enabled']){_0x2da95a['fragment']={'enabled':!![],'packets':_0x244a73['fragment']['packets']||_0x421318['fragmentPa'+'ckets']||'2-5','length':_0x244a73['fragment']['length']||_0x421318['fragmentLe'+'ngth']||'100-200','interval':_0x244a73['fragment']['interval']||_0x421318['fragmentIn'+'terval']||'10-20','sleep':parseInt(_0x244a73['fragment']['sleep']||_0x421318['fragmentSl'+'eep']||'10')};}if(_0x1eb8df==='ws'){const _0x51e82c={};_0x51e82c['Host']=_0x345fc5;_0x51e82c['User-Agent']='Mozilla/5.'+'0\x20(Windows'+'\x20NT\x2010.0;\x20'+'Win64;\x20x64'+')\x20AppleWeb'+'Kit/537.36';_0x2da95a['ws-opts']={'path':_0x421318['path']||'/','headers':_0x51e82c,'max-early-data':parseInt(_0x421318['maxEarlyDa'+'ta'])||0x800,'early-data-header-name':_0x421318['earlyDataH'+'eaderName']||'Sec-WebSoc'+'ket-Protoc'+'ol'};}if(_0x1eb8df==='grpc'){const _0x1a7430={};_0x1a7430['grpc-servi'+'ce-name']=_0x50b289||_0x421318['serviceNam'+'e']||'GunService';_0x1a7430['grpc-mode']='gun';_0x2da95a['grpc-opts']=_0x1a7430;}if(_0x1eb8df==='http'){const _0x4dca76={};_0x4dca76['Host']=_0x345fc5;_0x4dca76['User-Agent']='Mozilla/5.'+'0\x20(Windows'+'\x20NT\x2010.0;\x20'+'Win64;\x20x64'+')\x20AppleWeb'+'Kit/537.36';const _0x526301={};_0x526301['method']=_0x421318['method']||'GET';_0x526301['path']=_0x421318['path']||'/';_0x526301['headers']=_0x4dca76;_0x2da95a['http-opts']=_0x526301;}if(_0x1eb8df==='quic'){const _0x243ed3={};_0x243ed3['security']=_0x421318['quicSecuri'+'ty']||'none';_0x243ed3['key']=_0x421318['key']||'';_0x243ed3['type']=_0x421318['headerType']||'none';_0x2da95a['quic-opts']=_0x243ed3;}if(_0x421318['security']==='reality'){const _0x2ab955={};_0x2ab955['public-key']=_0x421318['pbk']||'';_0x2ab955['short-id']=_0x421318['sid']||'';_0x2da95a['reality-op'+'ts']=_0x2ab955;}if(_0x244a73['ipver']&&_0x244a73['ipver']!=='none'){_0x2da95a['ipversion']=_0x244a73['ipver'];}return _0x2da95a;}catch(_0x119129){console['error']('Error\x20in\x20v'+'lessToClas'+'hMeta:',_0x119129);return null;}}function generateSingBoxConfig(_0x110e05,_0x4d295e){const _0x49fbf3=[];const _0x3f0cd9=[];_0x110e05['forEach']((_0x523875,_0x39910e)=>{try{const _0xba36bb=new URL(_0x523875);if(_0xba36bb['username']&&_0xba36bb['hostname']&&_0xba36bb['port']){const _0x11e67a=vlessToSingBox(_0x523875,_0x39910e+0x1,_0x4d295e);if(_0x11e67a){_0x49fbf3['push'](_0x11e67a);_0x3f0cd9['push'](_0x11e67a['tag']);}}}catch(_0x5a5074){console['error']('Invalid\x20co'+'nfig\x20skipp'+'ed:',_0x5a5074);}});if(_0x3f0cd9['length']===0x0){const _0x177563={};_0x177563['level']='info';_0x177563['timestamp']=!![];const _0xe7ef7c={};_0xe7ef7c['type']='direct';_0xe7ef7c['tag']='direct';const _0x25beb6={};_0x25beb6['rules']=[];const _0x3d3a5d={};_0x3d3a5d['log']=_0x177563;_0x3d3a5d['inbounds']=[];_0x3d3a5d['outbounds']=[_0xe7ef7c];_0x3d3a5d['route']=_0x25beb6;return _0x3d3a5d;}const _0x4301e2={};_0x4301e2['type']='selector';_0x4301e2['tag']='select';_0x4301e2['outbounds']=['auto','direct',..._0x3f0cd9];_0x4301e2['default']='auto';const _0x38cfc0={};_0x38cfc0['type']='urltest';_0x38cfc0['tag']='auto';_0x38cfc0['outbounds']=[..._0x3f0cd9];_0x38cfc0['url']='http://www'+'.gstatic.c'+'om/generat'+'e_204';_0x38cfc0['interval']='10m0s';_0x38cfc0['tolerance']=0x32;const _0x14a388=[_0x4301e2,_0x38cfc0];function _0x5e55a0(_0x4f4dd4,_0x1298b0=null,_0x129093=undefined){_0x4f4dd4=(_0x4f4dd4||'')['toString']()['trim']();if(!_0x4f4dd4)return null;if(_0x4f4dd4==='local'||_0x4f4dd4==='local-dns'){const _0x271b13={};_0x271b13['type']='local';_0x271b13['tag']=_0x1298b0;_0x271b13['detour']=_0x129093;return _0x271b13;}if(_0x4f4dd4==='fakeip'){const _0x41b44d={};_0x41b44d['type']='fakeip';_0x41b44d['tag']=_0x1298b0;_0x41b44d['inet4_rang'+'e']='198.18.0.0'+'/15';_0x41b44d['inet6_rang'+'e']='fc00::/18';_0x41b44d['detour']=_0x129093;return _0x41b44d;}if(_0x4f4dd4['startsWith']('dhcp://')){const _0x3731d1=_0x4f4dd4['split']('://')[0x1]||'';const _0x22f440=_0x3731d1==='auto'?undefined:_0x3731d1;const _0x507a15={};_0x507a15['type']='dhcp';_0x507a15['tag']=_0x1298b0;_0x507a15['detour']=_0x129093;const _0x2871a0=_0x507a15;if(_0x22f440)_0x2871a0['interface']=_0x22f440;return _0x2871a0;}const _0x2e63ca=_0x4f4dd4['toLowerCas'+'e']();const _0x5623a0=_0x2e63ca['match'](/^([a-z0-9+.-]+):\/\/(.+)$/);if(_0x5623a0){const _0x52f65d=_0x5623a0[0x1];const _0x5d2026=_0x4f4dd4['substring'](_0x52f65d['length']+0x3);let _0x5319ce=_0x5d2026['split']('/')[0x0];_0x5319ce=_0x5319ce['trim']();switch(_0x52f65d){case'udp':case'tcp':case'tls':case'quic':case'h3':case'https':case'http3':const _0xc12338={};_0xc12338['type']=_0x52f65d==='http3'?'h3':_0x52f65d;_0xc12338['server']=_0x5319ce;_0xc12338['tag']=_0x1298b0;_0xc12338['detour']=_0x129093;return _0xc12338;default:const _0x1e32e8={};_0x1e32e8['type']='udp';_0x1e32e8['server']=_0x4f4dd4;_0x1e32e8['tag']=_0x1298b0;_0x1e32e8['detour']=_0x129093;return _0x1e32e8;}}const _0x4bbe16={};_0x4bbe16['type']='udp';_0x4bbe16['server']=_0x4f4dd4;_0x4bbe16['tag']=_0x1298b0;_0x4bbe16['detour']=_0x129093;return _0x4bbe16;}function _0xfbde19(_0x3745db,_0x4bda49='dns'){if(!_0x3745db)return[];const _0x3a7f41=Array['isArray'](_0x3745db)?_0x3745db:_0x3745db['toString']()['split'](',');const _0x465de2=[];for(let _0x2a2911=0x0;_0x2a2911<_0x3a7f41['length'];_0x2a2911++){const _0x11daef=_0x3a7f41[_0x2a2911]['trim']();if(!_0x11daef)continue;const _0x50e53e=''+_0x4bda49+(_0x2a2911===0x0?'':'-'+(_0x2a2911+0x1));const _0x5da947=_0x5e55a0(_0x11daef,_0x50e53e);if(_0x5da947)_0x465de2['push'](_0x5da947);}return _0x465de2;}const _0xda19fd=_0xfbde19(_0x4d295e['direct']&&_0x4d295e['direct']!=='none'?_0x4d295e['direct']:'8.8.8.8','direct-dns');const _0x15b418=_0xfbde19(_0x4d295e['dns']&&_0x4d295e['dns']!=='none'?_0x4d295e['dns']:'8.8.8.8','proxy-dns');const _0x474bde={};_0x474bde['type']='udp';_0x474bde['server']='8.8.8.8';_0x474bde['tag']='direct-dns';if(_0xda19fd['length']===0x0)_0xda19fd['push'](_0x474bde);const _0x9b71b1={};_0x9b71b1['type']='udp';_0x9b71b1['server']='8.8.8.8';_0x9b71b1['tag']='proxy-dns';if(_0x15b418['length']===0x0)_0x15b418['push'](_0x9b71b1);const _0x3adecc={};_0x3adecc['level']='info';_0x3adecc['timestamp']=!![];const _0x457c7f={};_0x457c7f['type']='local';_0x457c7f['tag']='local-dns';_0x457c7f['detour']='direct';const _0x2f5618={};_0x2f5618['clash_mode']='Global';_0x2f5618['server']='proxy-dns';const _0x418df2={};_0x418df2['source_ip_'+'cidr']=[_0x4d295e['tun_ipv4_c'+'idr']||'172.19.0.0'+'/30',_0x4d295e['tun_ipv6_c'+'idr']||'fdfe:dcba:'+'9876::1/12'+'6'];_0x418df2['server']='direct-dns';const _0x162962={};_0x162962['clash_mode']='Direct';_0x162962['server']='direct-dns';const _0x428a46={};_0x428a46['rule_set']=['geosite-ir','geoip-ir'];_0x428a46['server']='direct-dns';const _0x808a80={};_0x808a80['domain_suf'+'fix']='.ir';_0x808a80['server']='direct-dns';const _0x41da3f={};_0x41da3f['type']='tun';_0x41da3f['tag']='tun-in';_0x41da3f['interface_'+'name']='tun0';_0x41da3f['mtu']=0x5dc;_0x41da3f['address']=[_0x4d295e['tun_inet4']||'172.19.0.1'+'/30',_0x4d295e['tun_inet6']||'fdfe:dcba:'+'9876::1/12'+'6'];_0x41da3f['auto_route']=!![];_0x41da3f['strict_rou'+'te']=![];_0x41da3f['stack']='mixed';_0x41da3f['sniff']=!![];const _0x44c47f={};_0x44c47f['type']='direct';_0x44c47f['tag']='direct';const _0x5d8214={};_0x5d8214['type']='block';_0x5d8214['tag']='block';const _0xf6cf3={};_0xf6cf3['action']='sniff';const _0x14a0a7={};_0x14a0a7['clash_mode']='Direct';_0x14a0a7['outbound']='direct';const _0x385b43={};_0x385b43['clash_mode']='Global';_0x385b43['outbound']='select';const _0x4b9016={};_0x4b9016['protocol']='dns';_0x4b9016['action']='hijack-dns';const _0x183fde={};_0x183fde['rule_set']=['geoip-priv'+'ate','geosite-pr'+'ivate','geosite-ir','geoip-ir'];_0x183fde['outbound']='direct';const _0x4be924={};_0x4be924['rule_set']='geosite-ad'+'s';_0x4be924['action']='reject';const _0x130e03={};_0x130e03['type']='remote';_0x130e03['tag']='geosite-ad'+'s';_0x130e03['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'osite/cate'+'gory-ads-a'+'ll.srs';_0x130e03['download_d'+'etour']='direct';const _0xbbce2c={};_0xbbce2c['type']='remote';_0xbbce2c['tag']='geosite-pr'+'ivate';_0xbbce2c['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'osite/priv'+'ate.srs';_0xbbce2c['download_d'+'etour']='direct';const _0x1d0c66={};_0x1d0c66['type']='remote';_0x1d0c66['tag']='geosite-ir';_0x1d0c66['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'osite/cate'+'gory-ir.sr'+'s';_0x1d0c66['download_d'+'etour']='direct';const _0x25f75f={};_0x25f75f['type']='remote';_0x25f75f['tag']='geoip-priv'+'ate';_0x25f75f['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'oip/privat'+'e.srs';_0x25f75f['download_d'+'etour']='direct';const _0x2098ae={};_0x2098ae['type']='remote';_0x2098ae['tag']='geoip-ir';_0x2098ae['url']='https://te'+'stingcf.js'+'delivr.net'+'/gh/MetaCu'+'beX/meta-r'+'ules-dat@s'+'ing/geo/ge'+'oip/ir.srs';_0x2098ae['download_d'+'etour']='direct';const _0x2f13c5={};_0x2f13c5['rules']=[_0xf6cf3,_0x14a0a7,_0x385b43,_0x4b9016,_0x183fde,_0x4be924];_0x2f13c5['rule_set']=[_0x130e03,_0xbbce2c,_0x1d0c66,_0x25f75f,_0x2098ae];_0x2f13c5['final']='select';_0x2f13c5['auto_detec'+'t_interfac'+'e']=!![];_0x2f13c5['default_do'+'main_resol'+'ver']='local-dns';const _0x1324b7={'log':_0x3adecc,'dns':{'servers':[..._0xda19fd['map']((_0x44aaf0,_0x58b1fc)=>{if(!_0x44aaf0['tag'])_0x44aaf0['tag']='direct-dns'+(_0x58b1fc===0x0?'':'-'+(_0x58b1fc+0x1));if(_0x44aaf0['tag']&&_0x44aaf0['tag']['startsWith']('proxy-dns')){_0x44aaf0['detour']='select';}if(['https','tls','h3','quic']['includes'](_0x44aaf0['type'])){_0x44aaf0['domain_res'+'olver']='local-dns';}return _0x44aaf0;}),..._0x15b418['map']((_0x3133df,_0x23100f)=>{if(!_0x3133df['tag'])_0x3133df['tag']='proxy-dns'+(_0x23100f===0x0?'':'-'+(_0x23100f+0x1));if(_0x3133df['tag']&&_0x3133df['tag']['startsWith']('proxy-dns'))_0x3133df['detour']='select';if(['https','tls','h3','quic']['includes'](_0x3133df['type'])){_0x3133df['domain_res'+'olver']='local-dns';}return _0x3133df;}),_0x457c7f],'rules':[_0x2f5618,_0x418df2,_0x162962,_0x428a46,_0x808a80],'final':'local-dns','strategy':'prefer_ipv'+'4','independent_cache':!![]},'inbounds':[_0x41da3f],'outbounds':[_0x44c47f,_0x5d8214,..._0x14a388,..._0x49fbf3],'route':_0x2f13c5};return _0x1324b7;}function vlessToSingBox(_0x244bd6,_0x39edc5,_0x2c90e9){try{const _0x27646b=new URL(_0x244bd6);const _0x33cafc=Object['fromEntrie'+'s'](_0x27646b['searchPara'+'ms']['entries']());const _0x345a72='ARISTA-'+(_0x39edc5+0x1);const _0x3ce6e4=(_0x528523,_0x4a7d85)=>{if(_0x2c90e9[_0x528523]&&_0x2c90e9[_0x528523]!=='none'){return _0x2c90e9[_0x528523];}return _0x33cafc[_0x4a7d85]||undefined;};const _0x16010e=_0x3ce6e4('cleanip','cleanip');const _0x4419a7=(_0x16010e||'')['split'](',')['map'](_0x1395df=>_0x1395df['trim']())['filter'](Boolean);const _0x10b1cc=_0x3ce6e4('domain','domain');const _0x4deffa=_0x3ce6e4('domain','host')||_0x10b1cc;const _0x2c66b4=_0x3ce6e4('sni','sni');const _0x3aa673=_0x3ce6e4('fingerprin'+'t','fp');const _0x5573c8=_0x3ce6e4('alpn','alpn');const _0x540cdb=_0x3ce6e4('network','type');const _0x19b596=_0x3ce6e4('tls','security');const _0x35f990=_0x3ce6e4('udp','udp');const _0x55a9a4=_0x3ce6e4('ipver','ipver');const _0x3023c0=isIP(_0x27646b['hostname'])?_0x27646b['hostname']:_0x4419a7[0x0]||_0x27646b['hostname'];let _0x377ae2=_0x2c66b4||_0x10b1cc||_0x4deffa||_0x33cafc['sni']||_0x33cafc['host']||_0x27646b['hostname'];if(isIP(_0x3023c0)&&(!_0x377ae2||isIP(_0x377ae2)||!_0x377ae2['includes']('.'))){_0x377ae2=_0x10b1cc||_0x4deffa||_0x33cafc['host']||_0x27646b['hostname']||'cloudflare'+'.com';}const _0x3a5598={};_0x3a5598['enabled']=!![];_0x3a5598['fingerprin'+'t']=_0x3aa673||'chrome';const _0x2e7eb7={};_0x2e7eb7['enabled']=!![];_0x2e7eb7['server_nam'+'e']=_0x377ae2;_0x2e7eb7['insecure']=![];_0x2e7eb7['utls']=_0x3a5598;const _0x45210c={'type':'vless','tag':_0x345a72,'server':_0x3023c0,'server_port':parseInt(_0x27646b['port'])||0x1bb,'uuid':_0x27646b['username'],'packet_encoding':'xudp','tls':_0x2e7eb7};if(_0x33cafc['flow']){_0x45210c['flow']=_0x33cafc['flow'];}if(_0x5573c8&&_0x5573c8!=='none'){_0x45210c['tls']['alpn']=_0x5573c8['split'](',')['map'](_0x5135f6=>_0x5135f6['trim']());}if(_0x35f990&&_0x35f990!=='none'){_0x45210c['udp']=_0x35f990==='enabled';}if(_0x55a9a4&&_0x55a9a4!=='none'){_0x45210c['domain_str'+'ategy']=_0x55a9a4;}const _0x4ac860=_0x540cdb&&_0x540cdb!=='none'?_0x540cdb:_0x33cafc['type']||'tcp';if(_0x4ac860==='ws'){const _0x24e77a={};_0x24e77a['Host']=_0x377ae2;const _0x234cd9={};_0x234cd9['type']='ws';_0x234cd9['path']=_0x33cafc['path']||'/';_0x234cd9['headers']=_0x24e77a;_0x45210c['transport']=_0x234cd9;}else if(_0x4ac860==='grpc'){const _0x38ab3e={};_0x38ab3e['type']='grpc';_0x38ab3e['service_na'+'me']=_0x10b1cc||_0x33cafc['serviceNam'+'e']||'GunService';_0x45210c['transport']=_0x38ab3e;}else if(_0x4ac860==='http'){const _0x1f1af6={};_0x1f1af6['type']='http';_0x1f1af6['host']=[_0x377ae2];_0x1f1af6['path']=_0x33cafc['path']||'/';_0x45210c['transport']=_0x1f1af6;}if(_0x19b596==='disabled'){const _0x1138d3={};_0x1138d3['enabled']=![];_0x45210c['tls']=_0x1138d3;}if(_0x33cafc['security']==='reality'){const _0x12f896={};_0x12f896['enabled']=!![];_0x12f896['public_key']=_0x33cafc['pbk']||'';_0x12f896['short_id']=_0x33cafc['sid']||'';_0x45210c['tls']['reality']=_0x12f896;}return _0x45210c;}catch(_0x3b6de2){console['error']('Error\x20conv'+'erting\x20VLE'+'SS\x20to\x20Sing'+'Box:',_0x3b6de2);return null;}}export default{async 'scheduled'(_0x555fd8,_0x525d5c,_0x40d223){if(_0x555fd8['cron']==='0\x20*/3\x20*\x20*\x20'+'*'){_0x40d223['waitUntil'](updateConfigs());}},async 'fetch'(_0x5b300b,_0x59e610,_0x302c5a){const _0x34c5c1=new URL(_0x5b300b['url']);if(_0x34c5c1['pathname']==='/'){const _0x238db0={};_0x238db0['content-ty'+'pe']='text/html;'+'charset=ut'+'f-8';_0x238db0['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x1fac90={};_0x1fac90['headers']=_0x238db0;return new Response(getHTML(),_0x1fac90);}if(_0x34c5c1['pathname']==='/api/setti'+'ngs'){if(_0x5b300b['method']==='POST'){try{const _0xb7107d=await _0x5b300b['json']();await _0x59e610['KV']['put'](SETTINGS_KV_KEY,JSON['stringify'](_0xb7107d));const _0x437a57={};_0x437a57['ok']=!![];const _0x107465={};_0x107465['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';const _0x22831c={};_0x22831c['headers']=_0x107465;return new Response(JSON['stringify'](_0x437a57),_0x22831c);}catch(_0x48cd79){const _0x5528b8={};_0x5528b8['error']='Invalid\x20JS'+'ON';const _0x2f4cbc={};_0x2f4cbc['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';const _0x7ab26e={};_0x7ab26e['status']=0x190;_0x7ab26e['headers']=_0x2f4cbc;return new Response(JSON['stringify'](_0x5528b8),_0x7ab26e);}}else{try{const _0x25a98a=await _0x59e610['KV']['get'](SETTINGS_KV_KEY);const _0x2b9970={};_0x2b9970['content-ty'+'pe']='applicatio'+'n/json';_0x2b9970['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x5c5041={};_0x5c5041['headers']=_0x2b9970;return new Response(_0x25a98a||'{}',_0x5c5041);}catch(_0x67c6fe){const _0x421c9d={};_0x421c9d['content-ty'+'pe']='applicatio'+'n/json';const _0x2a0bfe={};_0x2a0bfe['headers']=_0x421c9d;return new Response('{}',_0x2a0bfe);}}}if(_0x34c5c1['pathname']==='/api/confi'+'gs'){try{if(ALL_CONFIGS['length']===0x0){await updateConfigs();}let _0x52fa1e=[...ALL_CONFIGS];if(_0x52fa1e['length']===0x0){const _0x2698ab={};_0x2698ab['status']=0x194;return new Response('No\x20configu'+'rations\x20fo'+'und',_0x2698ab);}const _0x2a59a4=await _0x59e610['KV']['get'](SETTINGS_KV_KEY);const _0x352ce5=_0x2a59a4?JSON['parse'](_0x2a59a4):{};const _0x31e99c=_0x352ce5['limit']||'all';_0x52fa1e=applyConfigLimit(_0x52fa1e,_0x31e99c);const _0x2d53e6=(_0x352ce5['cleanip']||'')['split'](',')['map'](_0x5a4b49=>_0x5a4b49['trim']())['filter'](Boolean);const _0x187f98=(_0x352ce5['sni']||'')['split'](',')['map'](_0x47ce25=>_0x47ce25['trim']())['filter'](Boolean);let _0x5dc26f=[];if(_0x2d53e6['length']>0x1){_0x52fa1e['forEach']((_0xaa77e2,_0x27c0a8)=>{_0x2d53e6['forEach']((_0x582572,_0x5e74c2)=>{let _0x5d7394=_0xaa77e2;const _0x224d05={..._0x352ce5};const _0xd2c26=_0x224d05;_0xd2c26['cleanip']=_0x582572;if(_0x187f98[_0x5e74c2]){_0xd2c26['sni']=_0x187f98[_0x5e74c2];}else if(_0x187f98['length']>0x0){_0xd2c26['sni']=_0x187f98[_0x187f98['length']-0x1];}_0x5d7394=applyCustomSettings(_0x5d7394,_0xd2c26);if(_0x352ce5['fragment']&&_0x352ce5['fragment']['enabled']){_0x5d7394=applyFragmentSettings(_0x5d7394,_0x352ce5['fragment']);}_0x5dc26f['push'](applyTag(_0x5d7394));});});}else{_0x5dc26f=_0x52fa1e['map'](_0xcbc5aa=>{let _0x5d185b=_0xcbc5aa;_0x5d185b=applyCustomSettings(_0x5d185b,_0x352ce5);if(_0x352ce5['fragment']&&_0x352ce5['fragment']['enabled']){_0x5d185b=applyFragmentSettings(_0x5d185b,_0x352ce5['fragment']);}return applyTag(_0x5d185b);});}_0x52fa1e=_0x5dc26f;const _0x4f308c=_0x34c5c1['searchPara'+'ms']['get']('format')||'v2ray';if(_0x4f308c==='clash'){const _0x50d7de={};_0x50d7de['geoip']=!![];_0x50d7de['geoip-code']='IR';_0x50d7de['ipcidr']=['0.0.0.0/8','127.0.0.0/'+'8','10.0.0.0/8','172.16.0.0'+'/12','192.168.0.'+'0/16'];const _0x4891b4={'port':0x1ed2,'socks-port':0x1ed3,'mixed-port':0x1ed5,'mode':'rule','log-level':'info','dns':{'enable':!![],'listen':':53','enhanced-mode':'fake-ip','fake-ip-range':'198.18.0.1'+'/16','fake-ip-filter':['*.lan','*.local','*.localhos'+'t','*.ir','*.test'],'nameserver':_0x352ce5['dns']&&_0x352ce5['dns']!=='none'?_0x352ce5['dns']['split'](',')['map'](_0x4d736b=>_0x4d736b['trim']()):['78.157.42.'+'100','78.157.42.'+'101','10.202.10.'+'10','8.8.8.8','1.1.1.1'],'fallback':_0x352ce5['direct']&&_0x352ce5['direct']!=='none'?_0x352ce5['direct']['split'](',')['map'](_0x238e52=>_0x238e52['trim']()):['10.202.10.'+'11','78.157.42.'+'100','8.8.4.4'],'fallback-filter':_0x50d7de},'proxies':[],'proxy-groups':[],'rules':['DOMAIN-SUF'+'FIX,google'+'.com,ARIST'+'A\x20Auto','DOMAIN-SUF'+'FIX,youtub'+'e.com,ARIS'+'TA\x20Auto','DOMAIN-SUF'+'FIX,github'+'.com,ARIST'+'A\x20Auto','DOMAIN-KEY'+'WORD,teleg'+'ram,ARISTA'+'\x20Auto','DOMAIN-SUF'+'FIX,instag'+'ram.com,AR'+'ISTA\x20Auto','DOMAIN-SUF'+'FIX,twitte'+'r.com,ARIS'+'TA\x20Auto','DOMAIN-SUF'+'FIX,whatsa'+'pp.com,ARI'+'STA\x20Auto','DOMAIN-SUF'+'FIX,cdn.ir'+',DIRECT','DOMAIN-SUF'+'FIX,aparat'+'.com,DIREC'+'T','DOMAIN-SUF'+'FIX,digika'+'la.com,DIR'+'ECT','DOMAIN-SUF'+'FIX,divar.'+'ir,DIRECT','DOMAIN-SUF'+'FIX,snapp.'+'ir,DIRECT','DOMAIN-SUF'+'FIX,torob.'+'com,DIRECT','DOMAIN-SUF'+'FIX,bamilo'+'.com,DIREC'+'T','DOMAIN-SUF'+'FIX,alibab'+'a.ir,DIREC'+'T','DOMAIN-SUF'+'FIX,ban.ir'+',DIRECT','GEOIP,IR,D'+'IRECT','MATCH,ARIS'+'TA\x20Auto']};const _0x598d0a=[];_0x52fa1e['forEach']((_0x28e2f8,_0x5191da)=>{const _0xae10a6=vlessToClashMeta(_0x28e2f8,'ARISTA',_0x5191da+0x1,_0x352ce5);if(_0xae10a6){_0x598d0a['push'](_0xae10a6);}});_0x4891b4['proxies']=_0x598d0a;if(_0x4891b4['proxies']['length']>0x0){const _0x17e72d=[];_0x17e72d['push']({'name':'ARISTA\x20Sel'+'ect','type':'select','proxies':['ARISTA\x20Aut'+'o','ARISTA\x20Fal'+'lback','ARISTA\x20Loa'+'d\x20Balance',..._0x598d0a['map'](_0x51c27d=>_0x51c27d['name'])],'disable-udp':![]});_0x17e72d['push']({'name':'ARISTA\x20Aut'+'o','type':'url-test','proxies':_0x598d0a['map'](_0xf0b11f=>_0xf0b11f['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x78,'tolerance':0x32,'lazy':!![],'disable-udp':![]});_0x17e72d['push']({'name':'ARISTA\x20Fal'+'lback','type':'fallback','proxies':_0x598d0a['map'](_0xa98395=>_0xa98395['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x78,'tolerance':0x64,'disable-udp':![]});_0x17e72d['push']({'name':'ARISTA\x20Loa'+'d\x20Balance','type':'load-balan'+'ce','proxies':_0x598d0a['map'](_0x49a4c0=>_0x49a4c0['name']),'url':'http://www'+'.gstatic.c'+'om/generat'+'e_204','interval':0x12c,'strategy':'consistent'+'-hashing','disable-udp':![]});_0x4891b4['proxy-grou'+'ps']=_0x17e72d;}const _0x5e2160={};_0x5e2160['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';_0x5e2160['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x577ebc={};_0x577ebc['headers']=_0x5e2160;return new Response(JSON['stringify'](_0x4891b4,null,0x2),_0x577ebc);}if(_0x4f308c==='singbox'){const _0x5ad0d5=generateSingBoxConfig(_0x52fa1e,_0x352ce5);const _0x2bfd40={};_0x2bfd40['content-ty'+'pe']='applicatio'+'n/json;cha'+'rset=utf-8';_0x2bfd40['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x440c2d={};_0x440c2d['headers']=_0x2bfd40;return new Response(JSON['stringify'](_0x5ad0d5,null,0x2),_0x440c2d);}const _0xe174dc={};_0xe174dc['content-ty'+'pe']='text/plain'+';charset=u'+'tf-8';_0xe174dc['cache-cont'+'rol']='no-cache,\x20'+'no-store,\x20'+'must-reval'+'idate';const _0x14649b={};_0x14649b['headers']=_0xe174dc;return new Response(_0x52fa1e['join']('\x0a'),_0x14649b);}catch(_0x1aee02){console['error']('Error\x20in\x20/'+'api/config'+'s:',_0x1aee02);const _0x3776bc={};_0x3776bc['status']=0x1f4;return new Response('Internal\x20S'+'erver\x20Erro'+'r',_0x3776bc);}}const _0x149487={};_0x149487['status']=0x194;return new Response('Not\x20Found',_0x149487);}};function getHTML(){return'<!DOCTYPE\x20'+'html>\x0a<htm'+'l\x20lang=\x22en'+'\x22>\x0a<head>\x0a'+'<meta\x20char'+'set=\x22UTF-8'+'\x22\x20/>\x0a<meta'+'\x20name=\x22vie'+'wport\x22\x20con'+'tent=\x22widt'+'h=device-w'+'idth,\x20init'+'ial-scale='+'1.0\x22\x20/>\x0a<t'+'itle>ARIST'+'A\x20Config\x20G'+'enerator</'+'title>\x0a<st'+'yle>\x0a*\x20{\x20b'+'ox-sizing:'+'\x20border-bo'+'x;\x20margin:'+'\x200;\x20paddin'+'g:\x200;\x20}\x0abo'+'dy\x20{\x20font-'+'family:\x20\x27S'+'egoe\x20UI\x27,\x20'+'Tahoma,\x20Ge'+'neva,\x20Verd'+'ana,\x20sans-'+'serif;\x20bac'+'kground:\x20#'+'0b1c3d;\x20co'+'lor:\x20#fff;'+'\x20line-heig'+'ht:\x201.6;\x20}'+'\x0a.containe'+'r\x20{\x20max-wi'+'dth:\x20800px'+';\x20margin:\x20'+'0\x20auto;\x20pa'+'dding:\x2020p'+'x;\x20}\x0a.head'+'er\x20{\x20backg'+'round:\x20lin'+'ear-gradie'+'nt(135deg,'+'\x20#1a3b7c\x200'+'%,\x20#2c5282'+'\x20100%);\x20co'+'lor:\x20white'+';\x20padding:'+'\x2025px;\x20bor'+'der-radius'+':\x2015px;\x20ma'+'rgin-botto'+'m:\x2025px;\x20t'+'ext-align:'+'\x20center;\x20b'+'ox-shadow:'+'\x200\x204px\x2015p'+'x\x20rgba(0,0'+',0,0.2);\x20}'+'\x0ah1\x20{\x20marg'+'in:\x200;\x20fon'+'t-size:\x2028'+'px;\x20font-w'+'eight:\x20700'+';\x20}\x0a.heade'+'r\x20p\x20{\x20marg'+'in:\x2010px\x200'+'\x200;\x20opacit'+'y:\x200.9;\x20}\x0a'+'.card\x20{\x20ba'+'ckground:\x20'+'#13274f;\x20p'+'adding:\x2025'+'px;\x20border'+'-radius:\x201'+'5px;\x20margi'+'n:\x2015px\x200;'+'\x20box-shado'+'w:\x200\x204px\x201'+'0px\x20rgba(0'+',0,0,0.15)'+';\x20}\x0a.arist'+'a-subscrib'+'e-card\x20{\x20\x0a'+'\x20\x20\x20\x20backgr'+'ound:\x20line'+'ar-gradien'+'t(135deg,\x20'+'rgba(138,\x20'+'43,\x20226,\x200'+'.2),\x20rgba('+'218,\x20112,\x20'+'214,\x200.2))'+';\x0a\x20\x20\x20\x20back'+'drop-filte'+'r:\x20blur(10'+('px);\x0a\x20\x20\x20\x20p'+'adding:\x2020'+'px;\x0a\x20\x20\x20\x20bo'+'rder-radiu'+'s:\x2012px;\x0a\x20'+'\x20\x20\x20margin:'+'\x2020px\x20auto'+';\x0a\x20\x20\x20\x20text'+'-align:\x20ce'+'nter;\x0a\x20\x20\x20\x20'+'box-shadow'+':\x200\x204px\x2020'+'px\x20rgba(13'+'8,\x2043,\x20226'+',\x200.3);\x0a\x20\x20'+'\x20\x20border:\x20'+'1px\x20solid\x20'+'rgba(255,\x20'+'255,\x20255,\x20'+'0.1);\x0a}\x0a.a'+'rista-subs'+'cribe-card'+':hover\x20{\x0a}'+'\x0a.arista-s'+'ubscribe-c'+'ard\x20h3\x20{\x0a\x20'+'\x20\x20\x20color:\x20'+'#fff;\x0a\x20\x20\x20\x20'+'margin-bot'+'tom:\x2010px;'+'\x0a\x20\x20\x20\x20font-'+'size:\x2018px'+';\x0a\x20\x20\x20\x20font'+'-weight:\x206'+'00;\x0a}\x0a.ari'+'sta-subscr'+'ibe-card\x20p'+'\x20{\x0a\x20\x20\x20\x20col'+'or:\x20#e2e8f'+'0;\x0a\x20\x20\x20\x20fon'+'t-size:\x2014'+'px;\x0a\x20\x20\x20\x20ma'+'rgin-botto'+'m:\x2015px;\x0a}'+'\x0a.arista-s'+'ubscribe-c'+'ard\x20.copy-'+'btn\x20{\x0a\x20\x20\x20\x20'+'background'+':\x20linear-g'+'radient(13'+'5deg,\x20#8b5'+'cf6\x200%,\x20#7'+'c3aed\x20100%'+');\x0a\x20\x20\x20\x20col'+'or:\x20white;'+'\x0a\x20\x20\x20\x20borde'+'r:\x20none;\x0a\x20'+'\x20\x20\x20padding'+':\x2010px\x2020p'+'x;\x0a\x20\x20\x20\x20bor'+'der-radius'+':\x208px;\x0a\x20\x20\x20'+'\x20cursor:\x20p'+'ointer;\x0a\x20\x20'+'\x20\x20font-wei'+'ght:\x20600;\x0a'+'\x20\x20\x20\x20transi'+'tion:\x20all\x20'+'0.3s\x20ease;'+'\x0a}\x0a.arista'+'-subscribe'+'-card\x20.cop'+'y-btn:hove'+'r\x20{\x0a\x20\x20\x20\x20tr'+'ansform:\x20s'+'cale(1.05)'+';\x0a\x20\x20\x20\x20box-'+'shadow:\x200\x20'+'4px\x2015px\x20r'+'gba(139,\x209'+'2,\x20246,\x200.'+'4);\x0a}\x0alabe'+'l\x20{\x20displa'+'y:\x20block;\x20'+'margin-top'+':\x2015px;\x20fo'+'nt-weight:'+'\x20600;\x20colo'+'r:\x20#e2e8f0'+';\x20}\x0a.help-'+'text\x20{\x20fon'+'t-size:\x2013'+'px;\x20color:'+'\x20#a0aec0;\x20'+'margin-top'+':\x205px;\x20}\x0ai'+'nput,\x20sele'+'ct,\x20textar'+'ea\x20{\x20width')+(':\x20100%;\x20pa'+'dding:\x2012p'+'x;\x20margin-'+'top:\x208px;\x20'+'border:\x201p'+'x\x20solid\x20#2'+'d3748;\x20bor'+'der-radius'+':\x208px;\x20bac'+'kground:\x20#'+'0b1c3d;\x20co'+'lor:\x20#fff;'+'\x20font-size'+':\x2014px;\x20tr'+'ansition:\x20'+'all\x200.3s\x20e'+'ase;\x20}\x0ainp'+'ut:focus,\x20'+'select:foc'+'us,\x20textar'+'ea:focus\x20{'+'\x20outline:\x20'+'none;\x20bord'+'er-color:\x20'+'#4299e1;\x20b'+'ox-shadow:'+'\x200\x200\x200\x203px'+'\x20rgba(66,\x20'+'153,\x20225,\x20'+'0.2);\x20}\x0abu'+'tton\x20{\x20mar'+'gin-top:\x202'+'0px;\x20paddi'+'ng:\x2014px;\x20'+'width:\x20100'+'%;\x20border:'+'\x20none;\x20bor'+'der-radius'+':\x208px;\x20col'+'or:\x20#fff;\x20'+'font-weigh'+'t:\x20600;\x20cu'+'rsor:\x20poin'+'ter;\x20trans'+'ition:\x20all'+'\x200.3s\x20ease'+';\x20font-siz'+'e:\x2016px;\x20}'+'\x0abutton:ho'+'ver\x20{\x20tran'+'sform:\x20tra'+'nslateY(-2'+'px);\x20box-s'+'hadow:\x200\x204'+'px\x2012px\x20rg'+'ba(0,0,0,0'+'.2);\x20}\x0a.bt'+'n-save\x20{\x20b'+'ackground:'+'\x20linear-gr'+'adient(135'+'deg,\x20#22c5'+'5e\x200%,\x20#16'+'a34a\x20100%)'+';\x20}\x0a.btn-r'+'eset\x20{\x20\x0a\x20\x20'+'background'+':\x20linear-g'+'radient(13'+'5deg,\x20#f97'+'316\x2050%,\x20#'+'ea580c\x20100'+'%);\x20\x0a}\x0a.bt'+'n-copy\x20{\x20b'+'ackground:'+'\x20linear-gr'+'adient(135'+'deg,\x20#8b5c'+'f6\x200%,\x20#7c'+'3aed\x20100%)'+';\x20}\x0a.fragm'+'ent-sectio'+'n\x20{\x20backgr'+'ound:\x20#1e3'+'a8a;\x20paddi'+'ng:\x2015px;\x20'+'border-rad'+'ius:\x2010px;'+'\x20margin-to'+'p:\x2015px;\x20}'+'\x0a.fragment'+'-toggle\x20{\x20'+'display:\x20f'+'lex;\x20align'+'-items:\x20ce'+'nter;\x20marg'+'in-bottom:'+'\x2015px;\x20}\x0a.'+'fragment-t'+'oggle\x20labe')+('l\x20{\x20margin'+':\x200\x200\x200\x2015'+'px;\x20font-w'+'eight:\x20600'+';\x20}\x0a.switc'+'h\x20{\x20positi'+'on:\x20relati'+'ve;\x20displa'+'y:\x20inline-'+'block;\x20wid'+'th:\x2060px;\x20'+'height:\x2030'+'px;\x20}\x0a.swi'+'tch\x20input\x20'+'{\x20opacity:'+'\x200;\x20width:'+'\x200;\x20height'+':\x200;\x20}\x0a.sl'+'ider\x20{\x20pos'+'ition:\x20abs'+'olute;\x20cur'+'sor:\x20point'+'er;\x20top:\x200'+';\x20left:\x200;'+'\x20right:\x200;'+'\x20bottom:\x200'+';\x20backgrou'+'nd-color:\x20'+'#4a5568;\x20t'+'ransition:'+'\x20.4s;\x20bord'+'er-radius:'+'\x2034px;\x20}\x0a.'+'slider:bef'+'ore\x20{\x20posi'+'tion:\x20abso'+'lute;\x20cont'+'ent:\x20\x22\x22;\x20h'+'eight:\x2022p'+'x;\x20width:\x20'+'22px;\x20left'+':\x204px;\x20bot'+'tom:\x204px;\x20'+'background'+'-color:\x20wh'+'ite;\x20trans'+'ition:\x20.4s'+';\x20border-r'+'adius:\x2050%'+';\x20}\x0ainput:'+'checked\x20+\x20'+'.slider\x20{\x20'+'background'+'-color:\x20#2'+'196F3;\x20}\x0ai'+'nput:check'+'ed\x20+\x20.slid'+'er:before\x20'+'{\x20transfor'+'m:\x20transla'+'teX(30px);'+'\x20}\x0a.limit-'+'section\x20{\x20'+'\x0a\x20\x20\x20\x20backg'+'round:\x20rgb'+'a(220,\x2038,'+'\x2038,\x200.1);'+'\x20\x0a\x20\x20\x20\x20padd'+'ing:\x2020px;'+'\x20\x0a\x20\x20\x20\x20bord'+'er-radius:'+'\x2010px;\x20\x0a\x20\x20'+'\x20\x20margin:\x20'+'20px\x200;\x20\x0a\x20'+'\x20\x20\x20border:'+'\x202px\x20solid'+'\x20#ef4444;\x20'+'\x0a\x20\x20\x20\x20anima'+'tion:\x20blin'+'k-border\x202'+'s\x20infinite'+';\x0a\x20\x20\x20\x20posi'+'tion:\x20rela'+'tive;\x0a}\x0a@k'+'eyframes\x20b'+'link-borde'+'r\x20{\x0a\x20\x20\x20\x200%'+',\x20100%\x20{\x20b'+'order-colo'+'r:\x20#ef4444'+';\x20}\x0a\x20\x20\x20\x2050'+'%\x20{\x20border'+'-color:\x20#f'+'ca5a5;\x20}\x0a}'+'\x0a.limit-se'+'ction\x20{\x20\x0a\x20'+'\x20\x20\x20backgro'+'und:\x20rgba('+'220,\x2038,\x203'+'8,\x200.1);\x20\x0a')+('\x20\x20\x20\x20paddin'+'g:\x2020px;\x20\x0a'+'\x20\x20\x20\x20border'+'-radius:\x201'+'2px;\x20\x0a\x20\x20\x20\x20'+'margin:\x2020'+'px\x20auto;\x0a\x20'+'\x20\x20\x20border:'+'\x202px\x20solid'+'\x20#ef4444;\x20'+'\x0a\x20\x20\x20\x20anima'+'tion:\x20blin'+'k-border\x202'+'s\x20infinite'+';\x0a\x20\x20\x20\x20posi'+'tion:\x20rela'+'tive;\x0a\x20\x20\x20\x20'+'max-width:'+'\x20400px;\x0a\x20\x20'+'\x20\x20text-ali'+'gn:\x20center'+';\x0a\x20\x20\x20\x20widt'+'h:\x20100%;\x0a}'+'\x0a@keyframe'+'s\x20blink-bo'+'rder\x20{\x0a\x20\x20\x20'+'\x200%,\x20100%\x20'+'{\x20border-c'+'olor:\x20#ef4'+'444;\x20box-s'+'hadow:\x200\x200'+'\x2010px\x20rgba'+'(239,\x2068,\x20'+'68,\x200.3);\x20'+'}\x0a\x20\x20\x20\x2050%\x20'+'{\x20border-c'+'olor:\x20#fca'+'5a5;\x20box-s'+'hadow:\x200\x200'+'\x2015px\x20rgba'+'(239,\x2068,\x20'+'68,\x200.5);\x20'+'}\x0a}\x0a.limit'+'-section::'+'before\x20{\x0a\x20'+'\x20\x20\x20content'+':\x20\x22⚠️\x20IMPOR'+'TANT\x20SETTI'+'NG\x22;\x0a\x20\x20\x20\x20p'+'osition:\x20a'+'bsolute;\x0a\x20'+'\x20\x20\x20top:\x20-1'+'2px;\x0a\x20\x20\x20\x20l'+'eft:\x2050%;\x0a'+'\x20\x20\x20\x20transf'+'orm:\x20trans'+'lateX(-50%'+');\x0a\x20\x20\x20\x20bac'+'kground:\x20l'+'inear-grad'+'ient(135de'+'g,\x20#ef4444'+'\x200%,\x20#dc26'+'26\x20100%);\x0a'+'\x20\x20\x20\x20color:'+'\x20white;\x0a\x20\x20'+'\x20\x20padding:'+'\x206px\x2016px;'+'\x0a\x20\x20\x20\x20borde'+'r-radius:\x20'+'8px;\x0a\x20\x20\x20\x20f'+'ont-size:\x20'+'12px;\x0a\x20\x20\x20\x20'+'font-weigh'+'t:\x20700;\x0a\x20\x20'+'\x20\x20animatio'+'n:\x20blink-t'+'ext\x202s\x20inf'+'inite;\x0a\x20\x20\x20'+'\x20white-spa'+'ce:\x20nowrap'+';\x0a\x20\x20\x20\x20box-'+'shadow:\x200\x20'+'2px\x208px\x20rg'+'ba(239,\x2068'+',\x2068,\x200.3)'+';\x0a}\x0a@keyfr'+'ames\x20blink'+'-text\x20{\x0a\x20\x20'+'\x20\x200%,\x20100%'+'\x20{\x20opacity'+':\x201;\x20trans'+'form:\x20tran'+'slateX(-50'+'%)\x20scale(1'+');\x20}\x0a\x20\x20\x20\x205'+'0%\x20{\x20opaci'+'ty:\x200.8;\x20t'+'ransform:\x20'+'translateX')+('(-50%)\x20sca'+'le(1.02);\x20'+'}\x0a}\x0a\x0a.limi'+'t-section\x20'+'.grid\x20{\x0a\x20\x20'+'\x20\x20display:'+'\x20flex;\x0a\x20\x20\x20'+'\x20justify-c'+'ontent:\x20ce'+'nter;\x0a\x20\x20\x20\x20'+'gap:\x2015px;'+'\x0a}\x0a\x0a.limit'+'-section\x20.'+'grid\x20>\x20div'+'\x20{\x0a\x20\x20\x20\x20fle'+'x:\x201;\x0a\x20\x20\x20\x20'+'max-width:'+'\x20300px;\x0a}\x0a'+'\x0a.limit-se'+'ction\x20sele'+'ct\x20{\x0a\x20\x20\x20\x20b'+'ackground:'+'\x20rgba(11,\x20'+'28,\x2061,\x200.'+'8);\x0a\x20\x20\x20\x20bo'+'rder:\x201px\x20'+'solid\x20#ef4'+'444;\x0a\x20\x20\x20\x20c'+'olor:\x20whit'+'e;\x0a\x20\x20\x20\x20tex'+'t-align:\x20c'+'enter;\x0a\x20\x20\x20'+'\x20font-weig'+'ht:\x20600;\x0a}'+'\x0a\x0a.limit-s'+'ection\x20.he'+'lp-text\x20{\x0a'+'\x20\x20\x20\x20color:'+'\x20#fecaca;\x0a'+'\x20\x20\x20\x20font-s'+'ize:\x2012px;'+'\x0a\x20\x20\x20\x20margi'+'n-top:\x208px'+';\x0a}\x0atextar'+'ea\x20{\x20heigh'+'t:\x20120px;\x20'+'resize:\x20ve'+'rtical;\x20}\x0a'+'footer\x20{\x20t'+'ext-align:'+'\x20center;\x20m'+'argin-top:'+'\x2030px;\x20opa'+'city:\x200.7;'+'\x20font-size'+':\x2014px;\x20}\x0a'+'.alert\x20{\x20p'+'osition:\x20f'+'ixed;\x20top:'+'\x2020px;\x20rig'+'ht:\x2020px;\x20'+'padding:\x201'+'5px\x2025px;\x20'+'background'+':\x20#22c55e;'+'\x20color:\x20wh'+'ite;\x20borde'+'r-radius:\x20'+'8px;\x20box-s'+'hadow:\x200\x204'+'px\x2015px\x20rg'+'ba(0,0,0,0'+'.2);\x20z-ind'+'ex:\x201000;\x20'+'opacity:\x200'+';\x20transfor'+'m:\x20transla'+'teY(-20px)'+';\x20transiti'+'on:\x20all\x200.'+'3s\x20ease;\x20}'+'\x0a.alert.sh'+'ow\x20{\x20opaci'+'ty:\x201;\x20tra'+'nsform:\x20tr'+'anslateY(0'+');\x20}\x0a.aler'+'t.error\x20{\x20'+'background'+':\x20#ef4444;'+'\x20}\x0a.grid\x20{'+'\x20display:\x20'+'grid;\x20grid'+'-template-'+'columns:\x201'+'fr\x201fr;\x20ga'+'p:\x2015px;\x20}'+'\x0a@media\x20(m'+'ax-width:\x20'+'768px)\x20{\x0a\x20')+('\x20\x20\x20.grid\x20{'+'\x20grid-temp'+'late-colum'+'ns:\x201fr;\x20}'+'\x0a\x20\x20\x20\x20.cont'+'ainer\x20{\x20pa'+'dding:\x2015p'+'x;\x20}\x0a\x20\x20\x20\x20.'+'header\x20{\x20p'+'adding:\x2020'+'px;\x20}\x0a\x20\x20\x20\x20'+'.card\x20{\x20pa'+'dding:\x2020p'+'x;\x20}\x0a\x20\x20\x20\x20.'+'limit-sect'+'ion\x20{\x20padd'+'ing:\x2015px;'+'\x20}\x0a\x20\x20\x20\x20.ar'+'ista-subsc'+'ribe-card\x20'+'{\x20padding:'+'\x2015px;\x20}\x0a}'+'\x0a</style>\x0a'+'</head>\x0a<b'+'ody>\x0a<div\x20'+'class=\x22con'+'tainer\x22>\x0a<'+'div\x20class='+'\x22header\x22>\x0a'+'<h1>ARISTA'+'\x20Config\x20Ge'+'nerator</h'+'1>\x0a<p>Gene'+'rate\x20and\x20c'+'ustomize\x20V'+'LESS\x20confi'+'gurations<'+'/p>\x0a</div>'+'\x0a<div\x20styl'+'e=\x22\x0a\x20\x20\x20\x20ba'+'ckground:\x20'+'linear-gra'+'dient(135d'+'eg,\x20rgba(1'+'38,\x2043,\x2022'+'6,\x200.1),\x20r'+'gba(218,\x201'+'12,\x20214,\x200'+'.1));\x0a\x20\x20\x20\x20'+'backdrop-f'+'ilter:\x20blu'+'r(10px);\x0a\x20'+'\x20\x20\x20padding'+':\x2015px\x2020p'+'x;\x0a\x20\x20\x20\x20bor'+'der-radius'+':\x2012px;\x0a\x20\x20'+'\x20\x20margin:\x20'+'20px\x20auto;'+'\x0a\x20\x20\x20\x20text-'+'align:\x20cen'+'ter;\x0a\x20\x20\x20\x20b'+'ox-shadow:'+'\x200\x204px\x2020p'+'x\x20rgba(138'+',\x2043,\x20226,'+'\x200.2);\x0a\x20\x20\x20'+'\x20border:\x201'+'px\x20solid\x20w'+'hite;\x0a\x20\x20\x20\x20'+'max-width:'+'\x2090%;\x0a\x22>\x0a\x20'+'\x20\x20\x20<div\x20st'+'yle=\x22\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20displa'+'y:\x20flex;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20jus'+'tify-conte'+'nt:\x20center'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'gap:\x2025px;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20f'+'lex-wrap:\x20'+'wrap;\x0a\x20\x20\x20\x20'+'\x22>\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20<a\x20href=\x22'+'https://t.'+'me/aristap'+'roject\x22\x20ta'+'rget=\x22_bla'+'nk\x22\x20style='+'\x22\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20displa'+'y:\x20flex;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20align-ite'+'ms:\x20center'+';\x20\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20gap:\x20'+'8px;\x0a\x20\x20\x20\x20\x20')+('\x20\x20\x20\x20\x20\x20\x20pad'+'ding:\x2010px'+'\x2020px;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20b'+'ackground:'+'\x20linear-gr'+'adient(135'+'deg,\x20rgba('+'0,\x20136,\x2020'+'4,\x200.2),\x20r'+'gba(0,\x20119'+',\x20181,\x200.3'+'));\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20colo'+'r:\x20white;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20text-dec'+'oration:\x20n'+'one;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20bor'+'der-radius'+':\x208px;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20t'+'ransition:'+'\x20all\x200.3s\x20'+'ease;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20bo'+'rder:\x201px\x20'+'solid\x20rgba'+'(0,\x20136,\x202'+'04,\x200.3);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20font-wei'+'ght:\x20600;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x22\x20'+'onmouseove'+'r=\x22this.st'+'yle.transf'+'orm=\x27trans'+'lateY(-2px'+')\x27;this.st'+'yle.boxSha'+'dow=\x270\x206px'+'\x2015px\x20rgba'+'(0,136,204'+',0.3)\x27;\x22\x20\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20onmouseou'+'t=\x22this.st'+'yle.transf'+'orm=\x27trans'+'lateY(0)\x27;'+'this.style'+'.boxShadow'+'=\x27none\x27;\x22>'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20<svg\x20xm'+'lns=\x22http:'+'//www.w3.o'+'rg/2000/sv'+'g\x22\x20width=\x22'+'18\x22\x20height'+'=\x2218\x22\x20fill'+'=\x22currentC'+'olor\x22\x20view'+'Box=\x220\x200\x201'+'6\x2016\x22>\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20<path\x20d'+'=\x22M16\x208A8\x20'+'8\x200\x201\x201\x200\x20'+'8a8\x208\x200\x200\x20'+'1\x2016\x200zM8.'+'287\x205.906c'+'-.778.324-'+'2.334.994-'+'4.666\x202.01'+'-.378.15-.'+'577.298-.5'+'95.442-.03'+'.243.275.3'+'39.69.47l.'+'175.055c.4'+'08.133.958'+'.288\x201.243'+'.294.26.00'+'6.549-.1.8'+'68-.32\x202.1'+'79-1.471\x203'+'.304-2.214'+'\x203.374-2.2'+'3.05-.012.'+'12-.026.16'+'6.016.047.'+'041.042.12'+'.037.141-.'+'03.129-1.2'+'27\x201.241-1'+'.846\x201.817'+'-.193.18-.')+('33.307-.35'+'8.336a8.15'+'4\x208.154\x200\x20'+'0\x201-.188.1'+'86c-.38.36'+'6-.664.64.'+'015\x201.088.'+'327.216.58'+'9.393.85.5'+'71.284.194'+'.568.387.9'+'36.629.093'+'.06.183.12'+'5.27.187.3'+'31.236.63.'+'448.997.41'+'4.214-.02.'+'435-.22.54'+'7-.82.265-'+'1.417.786-'+'4.486.906-'+'5.751a1.42'+'6\x201.426\x200\x20'+'0\x200-.013-.'+'315.337.33'+'7\x200\x200\x200-.1'+'14-.217.52'+'6.526\x200\x200\x20'+'0-.31-.093'+'c-.3.005-.'+'763.166-2.'+'984\x201.09z\x22'+'/>\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20</svg'+'>\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20Arista'+'\x20Telegram\x20'+'Channel\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20</a>'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20<a'+'\x20href=\x22htt'+'ps://arist'+'a-proxy.pa'+'ges.dev\x22\x20t'+'arget=\x22_bl'+'ank\x22\x20style'+'=\x22\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20displ'+'ay:\x20flex;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20align-it'+'ems:\x20cente'+'r;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20gap:\x20'+'8px;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20pad'+'ding:\x2010px'+'\x2020px;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20b'+'ackground:'+'\x20linear-gr'+'adient(135'+'deg,\x20rgba('+'74,\x20144,\x202'+'26,\x200.2),\x20'+'rgba(66,\x201'+'33,\x20214,\x200'+'.3));\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20co'+'lor:\x20white'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20text-d'+'ecoration:'+'\x20none;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20b'+'order-radi'+'us:\x208px;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20transitio'+'n:\x20all\x200.3'+'s\x20ease;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'border:\x201p'+'x\x20solid\x20rg'+'ba(74,\x20144'+',\x20226,\x200.3'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20font-'+'weight:\x2060'+'0;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x22\x20onmouse'+'over=\x22this'+'.style.tra'+'nsform=\x27tr'+'anslateY(-'+'2px)\x27;this'+'.style.box'+'Shadow=\x270\x20'+'6px\x2015px\x20r')+('gba(74,144'+',226,0.3)\x27'+';\x22\x20\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20onmou'+'seout=\x22thi'+'s.style.tr'+'ansform=\x27t'+'ranslateY('+'0)\x27;this.s'+'tyle.boxSh'+'adow=\x27none'+'\x27;\x22>\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20<sv'+'g\x20xmlns=\x22h'+'ttp://www.'+'w3.org/200'+'0/svg\x22\x20wid'+'th=\x2218\x22\x20he'+'ight=\x2218\x22\x20'+'fill=\x22curr'+'entColor\x22\x20'+'viewBox=\x220'+'\x200\x2016\x2016\x22>'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20<pa'+'th\x20d=\x22M0\x208'+'a8\x208\x200\x201\x201'+'\x2016\x200A8\x208\x20'+'0\x200\x201\x200\x208z'+'m7.5-6.923'+'c-.67.204-'+'1.335.82-1'+'.887\x201.855'+'A7.97\x207.97'+'\x200\x200\x200\x205.1'+'45\x204H7.5V1'+'.077zM4.09'+'\x204a9.267\x209'+'.267\x200\x200\x201'+'\x20.64-1.539'+'\x206.7\x206.7\x200'+'\x200\x201\x20.597-'+'.933A7.025'+'\x207.025\x200\x200'+'\x200\x202.255\x204'+'H4.09zm-.5'+'82\x203.5c.03'+'-.877.138-'+'1.718.312-'+'2.5H1.674a'+'6.958\x206.95'+'8\x200\x200\x200-.6'+'56\x202.5h2.4'+'9zM4.847\x205'+'a12.5\x2012.5'+'\x200\x200\x200-.33'+'8\x202.5H7.5V'+'5H4.847zM8'+'.5\x205v2.5h2'+'.99a12.495'+'\x2012.495\x200\x20'+'0\x200-.337-2'+'.5H8.5zM4.'+'51\x208.5a12.'+'5\x2012.5\x200\x200'+'\x200\x20.337\x202.'+'5H7.5V8.5H'+'4.51zm3.99'+'\x200V11h2.65'+'3c.187-.76'+'5.306-1.60'+'8.338-2.5H'+'8.5zM5.145'+'\x2012c.138.3'+'86.295.744'+'.468\x201.068'+'.552\x201.035'+'\x201.218\x201.6'+'5\x201.887\x201.'+'855V12H5.1'+'45zm.182\x202'+'.472a6.696'+'\x206.696\x200\x200'+'\x201-.597-.9'+'33A9.268\x209'+'.268\x200\x200\x201'+'\x204.09\x2012H2'+'.255a7.024'+'\x207.024\x200\x200'+'\x200\x203.072\x202'+'.472zM3.82'+'\x2011a13.652'+'\x2013.652\x200\x20'+'0\x201-.312-2'+'.5h-2.49c.'+'062.97.291'+'\x201.87.656\x20'+'2.5H3.82zm'+'6.853\x203.47'+'2A7.024\x207.')+('024\x200\x200\x200\x20'+'13.745\x2012H'+'11.91a9.27'+'\x209.27\x200\x200\x20'+'1-.64\x201.53'+'9\x206.688\x206.'+'688\x200\x200\x201-'+'.597.933zM'+'8.5\x2012v2.9'+'23c.67-.20'+'4\x201.335-.8'+'2\x201.887-1.'+'855.173-.3'+'24.33-.682'+'.468-1.068'+'H8.5zm3.68'+'0-1h2.146c'+'.365-.63.5'+'94-1.53.65'+'6-2.5h-2.4'+'9a13.65\x2013'+'.65\x200\x200\x201-'+'.312\x202.5zm'+'2.802-3.5a'+'6.959\x206.95'+'9\x200\x200\x200-.6'+'56-2.5H12.'+'18c.174.78'+'2.282\x201.62'+'3.312\x202.5h'+'2.49zM11.2'+'7\x202.461c.2'+'47.35.462.'+'739.64\x201.5'+'39h1.835a7'+'.024\x207.024'+'\x200\x200\x200-3.0'+'72-2.472c.'+'218.284.41'+'8.598.597.'+'933zM10.85'+'5\x204a7.966\x20'+'7.966\x200\x200\x20'+'0-.468-1.0'+'68C9.835\x201'+'.897\x209.17\x20'+'1.282\x208.5\x20'+'1.077V4h2.'+'355z\x22/>\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'</svg>\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20T'+'elegram\x20Pr'+'oxy\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20</a>\x0a\x20\x20\x20'+'\x20</div>\x0a</'+'div>\x0a\x0a<div'+'\x20class=\x22ar'+'ista-subsc'+'ribe-card\x22'+'>\x0a\x20\x20\x20\x20<h3>'+'ARISTA\x20Exc'+'lusive\x20Sub'+'scribe\x20for'+'\x20v2ray</h3'+'>\x0a\x20\x20\x20\x20<p>C'+'lick\x20to\x20co'+'py\x20ARISTA\x20'+'v2ray\x20subs'+'cription\x20l'+'ink</p>\x0a\x20\x20'+'\x20\x20<button\x20'+'class=\x22cop'+'y-btn\x22\x20onc'+'lick=\x22copy'+'AristaSubs'+'cribe(\x27v2r'+'ay\x27)\x22>Copy'+'\x20v2ray\x20Sub'+'scribe</bu'+'tton>\x0a</di'+'v>\x0a\x0a<div\x20c'+'lass=\x22aris'+'ta-subscri'+'be-card\x22>\x0a'+'\x20\x20\x20\x20<h3>AR'+'ISTA\x20Exclu'+'sive\x20Subsc'+'ribe\x20for\x20C'+'lashMeta</'+'h3>\x0a\x20\x20\x20\x20<p'+'>Click\x20to\x20'+'copy\x20ARIST'+'A\x20ClashMet'+'a\x20subscrip'+'tion\x20link<'+'/p>\x0a\x20\x20\x20\x20<b'+'utton\x20clas'+'s=\x22copy-bt'+'n\x22\x20onclick')+('=\x22copyAris'+'taSubscrib'+'e(\x27clash\x27)'+'\x22>Copy\x20Cla'+'shMeta\x20Sub'+'scribe</bu'+'tton>\x0a</di'+'v>\x0a\x0a<div\x20c'+'lass=\x22card'+'\x22>\x0a\x0a<div\x20c'+'lass=\x22grid'+'\x22>\x0a<div>\x0a<'+'label>Remo'+'te\x20DNS</la'+'bel>\x0a<inpu'+'t\x20id=\x22dns\x22'+'\x20placehold'+'er=\x22e.g.,\x20'+'8.8.8.8,1.'+'1.1.1,http'+'s://dns.go'+'ogle/dns-q'+'uery\x22>\x0a<di'+'v\x20class=\x22h'+'elp-text\x22>'+'Enter\x20DNS\x20'+'servers\x20or'+'\x20DoH\x20URLs\x20'+'(comma-sep'+'arated,\x20e.'+'g.,\x208.8.8.'+'8,1.1.1.1\x20'+'or\x20https:/'+'/dns.googl'+'e/dns-quer'+'y)</div>\x0a<'+'/div>\x0a<div'+'>\x0a<label>D'+'irect\x20DNS<'+'/label>\x0a<i'+'nput\x20id=\x22d'+'irect\x22\x20pla'+'ceholder=\x22'+'e.g.,\x20127.'+'0.0.1,8.8.'+'8.8\x22>\x0a<div'+'\x20class=\x22he'+'lp-text\x22>E'+'nter\x20DNS\x20s'+'ervers\x20for'+'\x20direct\x20co'+'nnections\x20'+'(comma-sep'+'arated,\x20e.'+'g.,\x20127.0.'+'0.1,8.8.8.'+'8)</div>\x0a<'+'/div>\x0a</di'+'v>\x0a\x0a<div\x20c'+'lass=\x22grid'+'\x22>\x0a<div>\x0a<'+'label>Clea'+'n\x20IP</labe'+'l>\x0a<input\x20'+'id=\x22cleani'+'p\x22\x20placeho'+'lder=\x22e.g.'+',\x208.219.19'+'0.62,1.1.1'+'.1\x22>\x0a<div\x20'+'class=\x22hel'+'p-text\x22>En'+'ter\x20clean\x20'+'IP\x20address'+'es\x20for\x20byp'+'ass\x20(comma'+'-separated'+',\x20e.g.,\x208.'+'219.190.62'+',1.1.1.1)<'+'/div>\x0a</di'+'v>\x0a<div>\x0a<'+'label>Doma'+'in</label>'+'\x0a<input\x20id'+'=\x22domain\x22\x20'+'placeholde'+'r=\x22e.g.,\x20z'+'ula.ir,exa'+'mple.com\x22>'+'\x0a<div\x20clas'+'s=\x22help-te'+'xt\x22>Enter\x20'+'domains\x20fo'+'r\x20routing\x20'+'(comma-sep'+'arated,\x20e.'+'g.,\x20zula.i'+'r,example.'+'com)</div>')+('\x0a</div>\x0a</'+'div>\x0a\x0a<div'+'\x20class=\x22gr'+'id\x22>\x0a<div>'+'\x0a<label>SN'+'I</label>\x0a'+'<input\x20id='+'\x22sni\x22\x20plac'+'eholder=\x22e'+'.g.,\x20examp'+'le.com,clo'+'udflare.co'+'m\x22>\x0a<div\x20c'+'lass=\x22help'+'-text\x22>Ent'+'er\x20Server\x20'+'Name\x20Indic'+'ation\x20for\x20'+'TLS\x20(comma'+'-separated'+',\x20e.g.,\x20ex'+'ample.com,'+'cloudflare'+'.com)</div'+'>\x0a</div>\x0a<'+'div>\x0a<labe'+'l>ALPN</la'+'bel>\x0a<sele'+'ct\x20id=\x22alp'+'n\x22>\x0a<optio'+'n\x20value=\x22n'+'one\x22>None<'+'/option>\x0a<'+'option\x20val'+'ue=\x22h2\x22>HT'+'TP/2</opti'+'on>\x0a<optio'+'n\x20value=\x22h'+'ttp/1.1\x22>H'+'TTP/1.1</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22h2,http/'+'1.1\x22>HTTP/'+'2\x20+\x20HTTP/1'+'.1</option'+'>\x0a<option\x20'+'value=\x22h3\x22'+'>HTTP/3</o'+'ption>\x0a</s'+'elect>\x0a<di'+'v\x20class=\x22h'+'elp-text\x22>'+'Applicatio'+'n-Layer\x20Pr'+'otocol\x20Neg'+'otiation</'+'div>\x0a</div'+'>\x0a</div>\x0a\x0a'+'<div\x20class'+'=\x22grid\x22>\x0a<'+'div>\x0a<labe'+'l>Fingerpr'+'int</label'+'>\x0a<select\x20'+'id=\x22finger'+'print\x22>\x0a<o'+'ption\x20valu'+'e=\x22none\x22>N'+'one</optio'+'n>\x0a<option'+'\x20value=\x22ch'+'rome\x22>Chro'+'me</option'+'>\x0a<option\x20'+'value=\x22fir'+'efox\x22>Fire'+'fox</optio'+'n>\x0a<option'+'\x20value=\x22sa'+'fari\x22>Safa'+'ri</option'+'>\x0a<option\x20'+'value=\x22ios'+'\x22>iOS</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'android\x22>A'+'ndroid</op'+'tion>\x0a<opt'+'ion\x20value='+'\x22edge\x22>Edg'+'e</option>'+'\x0a<option\x20v'+'alue=\x22360\x22'+'>360</opti'+'on>\x0a<optio'+'n\x20value=\x22q'+'q\x22>QQ</opt'+'ion>\x0a<opti')+('on\x20value=\x22'+'random\x22>Ra'+'ndom</opti'+'on>\x0a<optio'+'n\x20value=\x22r'+'andomized\x22'+'>Randomize'+'d</option>'+'\x0a</select>'+'\x0a<div\x20clas'+'s=\x22help-te'+'xt\x22>TLS\x20cl'+'ient\x20finge'+'rprint</di'+'v>\x0a</div>\x0a'+'<div>\x0a<lab'+'el>IP\x20Vers'+'ion</label'+'>\x0a<select\x20'+'id=\x22ipver\x22'+'>\x0a<option\x20'+'value=\x22non'+'e\x22>None</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22ipv4\x22>IP'+'v4</option'+'>\x0a<option\x20'+'value=\x22ipv'+'6\x22>IPv6</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22auto\x22>Au'+'to</option'+'>\x0a</select'+'>\x0a</div>\x0a<'+'/div>\x0a\x0a<di'+'v\x20class=\x22g'+'rid\x22>\x0a<div'+'>\x0a<label>N'+'etwork</la'+'bel>\x0a<sele'+'ct\x20id=\x22net'+'work\x22>\x0a<op'+'tion\x20value'+'=\x22none\x22>No'+'ne</option'+'>\x0a<option\x20'+'value=\x22tcp'+'\x22>TCP</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'ws\x22>WebSoc'+'ket</optio'+'n>\x0a<option'+'\x20value=\x22h2'+'\x22>HTTP/2</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22grpc\x22>g'+'RPC</optio'+'n>\x0a<option'+'\x20value=\x22qu'+'ic\x22>QUIC</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22kcp\x22>KC'+'P</option>'+'\x0a<option\x20v'+'alue=\x22http'+'\x22>HTTP</op'+'tion>\x0a</se'+'lect>\x0a</di'+'v>\x0a<div>\x0a<'+'label>TLS<'+'/label>\x0a<s'+'elect\x20id=\x22'+'tls\x22>\x0a<opt'+'ion\x20value='+'\x22none\x22>Non'+'e</option>'+'\x0a<option\x20v'+'alue=\x22enab'+'led\x22>Enabl'+'ed</option'+'>\x0a<option\x20'+'value=\x22dis'+'abled\x22>Dis'+'abled</opt'+'ion>\x0a</sel'+'ect>\x0a</div'+'>\x0a</div>\x0a\x0a'+'<div\x20class'+'=\x22grid\x22>\x0a<'+'div>\x0a<labe'+'l>UDP</lab'+'el>\x0a<selec'+'t\x20id=\x22udp\x22'+'>\x0a<option\x20'+'value=\x22non')+('e\x22>None</o'+'ption>\x0a<op'+'tion\x20value'+'=\x22enabled\x22'+'>Enabled</'+'option>\x0a<o'+'ption\x20valu'+'e=\x22disable'+'d\x22>Disable'+'d</option>'+'\x0a</select>'+'\x0a</div>\x0a</'+'div>\x0a\x0a<div'+'\x20class=\x22fr'+'agment-sec'+'tion\x22>\x0a<di'+'v\x20class=\x22f'+'ragment-to'+'ggle\x22>\x0a<la'+'bel\x20class='+'\x22switch\x22>\x0a'+'<input\x20typ'+'e=\x22checkbo'+'x\x22\x20id=\x22fra'+'gment_enab'+'led\x22>\x0a<spa'+'n\x20class=\x22s'+'lider\x22></s'+'pan>\x0a</lab'+'el>\x0a<label'+'>Enable\x20Fr'+'agment</la'+'bel>\x0a</div'+'>\x0a\x0a<div\x20id'+'=\x22fragment'+'_settings\x22'+'>\x0a<div\x20cla'+'ss=\x22grid\x22>'+'\x0a<div>\x0a<la'+'bel>Packet'+'s</label>\x0a'+'<input\x20id='+'\x22frag_pack'+'ets\x22\x20value'+'=\x222-8\x22>\x0a<d'+'iv\x20class=\x22'+'help-text\x22'+'>Packet\x20fr'+'agmentatio'+'n\x20range</d'+'iv>\x0a</div>'+'\x0a<div>\x0a<la'+'bel>Length'+'</label>\x0a<'+'input\x20id=\x22'+'frag_lengt'+'h\x22\x20value=\x22'+'100-300\x22>\x0a'+'<div\x20class'+'=\x22help-tex'+'t\x22>Fragmen'+'t\x20length\x20r'+'ange</div>'+'\x0a</div>\x0a</'+'div>\x0a\x0a<div'+'\x20class=\x22gr'+'id\x22>\x0a<div>'+'\x0a<label>In'+'terval</la'+'bel>\x0a<inpu'+'t\x20id=\x22frag'+'_interval\x22'+'\x20value=\x2210'+'-30\x22>\x0a<div'+'\x20class=\x22he'+'lp-text\x22>F'+'ragment\x20in'+'terval\x20ran'+'ge</div>\x0a<'+'/div>\x0a<div'+'>\x0a<label>S'+'leep</labe'+'l>\x0a<input\x20'+'id=\x22frag_s'+'leep\x22\x20valu'+'e=\x2250\x22>\x0a<d'+'iv\x20class=\x22'+'help-text\x22'+'>Sleep\x20tim'+'e\x20between\x20'+'fragments\x20'+'(ms)</div>'+'\x0a</div>\x0a</'+'div>\x0a</div'+'>\x0a</div>\x0a\x0a'+'<div\x20class'+'=\x22limit-se'+'ction\x22>\x0a<d'+'iv\x20class=\x22'+'grid\x22>\x0a<di')+('v>\x0a<label>'+'Config\x20Lim'+'it</label>'+'\x0a<select\x20i'+'d=\x22limit\x22>'+'\x0a<option\x20v'+'alue=\x22all\x22'+'>All\x20Confi'+'gs</option'+'>\x0a<option\x20'+'value=\x225\x22>'+'5\x20Configs<'+'/option>\x0a<'+'option\x20val'+'ue=\x2210\x22>10'+'\x20Configs</'+'option>\x0a<o'+'ption\x20valu'+'e=\x2220\x22>20\x20'+'Configs</o'+'ption>\x0a<op'+'tion\x20value'+'=\x2230\x22>30\x20C'+'onfigs</op'+'tion>\x0a<opt'+'ion\x20value='+'\x2240\x22>40\x20Co'+'nfigs</opt'+'ion>\x0a<opti'+'on\x20value=\x22'+'50\x22>50\x20Con'+'figs</opti'+'on>\x0a<optio'+'n\x20value=\x226'+'0\x22>60\x20Conf'+'igs</optio'+'n>\x0a<option'+'\x20value=\x2210'+'0\x22>100\x20Con'+'figs</opti'+'on>\x0a</sele'+'ct>\x0a<div\x20c'+'lass=\x22help'+'-text\x22>Sel'+'ect\x20number'+'\x20of\x20config'+'urations\x20t'+'o\x20generate'+'\x20(priority'+'\x20given\x20to\x20'+'ports\x202096'+',\x20443,\x20844'+'3,\x208080)</'+'div>\x0a</div'+'>\x0a</div>\x0a<'+'/div>\x0a\x0a<bu'+'tton\x20class'+'=\x22btn-save'+'\x22\x20onclick='+'\x22saveSetti'+'ngs()\x22>Sav'+'e\x20Settings'+'</button>\x0a'+'<button\x20cl'+'ass=\x22btn-r'+'eset\x22\x20oncl'+'ick=\x22reset'+'Settings()'+'\x22>Reset\x20Se'+'ttings</bu'+'tton>\x0a\x0a<la'+'bel>Subscr'+'ibe\x20URL\x20(V'+'2Ray)</lab'+'el>\x0a<input'+'\x20id=\x22subsc'+'ribe_v2ray'+'\x22\x20readonly'+'>\x0a<button\x20'+'class=\x22btn'+'-copy\x22\x20onc'+'lick=\x22copy'+'ToClipboar'+'d(\x27subscri'+'be_v2ray\x27)'+'\x22>Copy\x20V2R'+'ay\x20Subscri'+'be</button'+'>\x0a\x0a<label>'+'Subscribe\x20'+'URL\x20(Clash'+'Meta)</lab'+'el>\x0a<input'+'\x20id=\x22subsc'+'ribe_clash'+'\x22\x20readonly'+'>\x0a<button\x20'+'class=\x22btn'+'-copy\x22\x20onc'+'lick=\x22copy')+('ToClipboar'+'d(\x27subscri'+'be_clash\x27)'+'\x22>Copy\x20Cla'+'shMeta\x20Sub'+'scribe</bu'+'tton>\x0a\x0a<la'+'bel>Subscr'+'ibe\x20URL\x20(S'+'ingBox)</l'+'abel>\x0a<inp'+'ut\x20id=\x22sub'+'scribe_sin'+'gbox\x22\x20read'+'only>\x0a<but'+'ton\x20class='+'\x22btn-copy\x22'+'\x20onclick=\x22'+'copyToClip'+'board(\x27sub'+'scribe_sin'+'gbox\x27)\x22>Co'+'py\x20SingBox'+'\x20Subscribe'+'</button>\x0a'+'</div>\x0a<fo'+'oter>V\x201.3'+'.9</footer'+'>\x0a<div\x20id='+'\x22alert\x22\x20cl'+'ass=\x22alert'+'\x22></div>\x0a<'+'/div>\x0a<scr'+'ipt>\x0afunct'+'ion\x20showAl'+'ert(messag'+'e,\x20isError'+'\x20=\x20false)\x20'+'{\x0a\x20\x20\x20\x20cons'+'t\x20alert\x20=\x20'+'document.g'+'etElementB'+'yId(\x27alert'+'\x27);\x0a\x20\x20\x20\x20al'+'ert.textCo'+'ntent\x20=\x20me'+'ssage;\x0a\x20\x20\x20'+'\x20alert.cla'+'ssName\x20=\x20i'+'sError\x20?\x20\x27'+'alert\x20erro'+'r\x27\x20:\x20\x27aler'+'t\x27;\x0a\x20\x20\x20\x20al'+'ert.classL'+'ist.add(\x27s'+'how\x27);\x0a\x20\x20\x20'+'\x20\x0a\x20\x20\x20\x20setT'+'imeout(()\x20'+'=>\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20alert.c'+'lassList.r'+'emove(\x27sho'+'w\x27);\x0a\x20\x20\x20\x20}'+',\x203000);\x0a}'+'\x0a\x0afunction'+'\x20toggleFra'+'gmentSetti'+'ngs()\x20{\x0a\x20\x20'+'\x20\x20const\x20en'+'abled\x20=\x20do'+'cument.get'+'ElementByI'+'d(\x27fragmen'+'t_enabled\x27'+').checked;'+'\x0a\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'fragment_s'+'ettings\x27).'+'style.disp'+'lay\x20=\x20enab'+'led\x20?\x20\x27gri'+'d\x27\x20:\x20\x27none'+'\x27;\x0a}\x0a\x0aasyn'+'c\x20function'+'\x20copyArist'+'aSubscribe'+'(type)\x20{\x0a\x20'+'\x20\x20\x20try\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20con'+'st\x20url\x20=\x20t'+'ype\x20===\x20\x27v'+'2ray\x27\x20?\x20\x27')+ARISTA_URL+'\x27\x20:\x20\x27'+CLASH_ARISTA_URL+('\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20await\x20nav'+'igator.cli'+'pboard.wri'+'teText(url'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20showAlert'+'(\x27ARISTA\x20\x27'+'\x20+\x20type\x20+\x20'+'\x27\x20subscrip'+'tion\x20link\x20'+'copied\x20suc'+'cessfully!'+'\x27);\x0a\x20\x20\x20\x20}\x20'+'catch\x20(err'+'or)\x20{\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20showAl'+'ert(\x27Faile'+'d\x20to\x20copy\x20'+'ARISTA\x20sub'+'scription\x20'+'link!\x27,\x20tr'+'ue);\x0a\x20\x20\x20\x20}'+'\x0a}\x0a\x0a\x20\x20asyn'+'c\x20function'+'\x20saveSetti'+'ngs(){\x0a\x20\x20\x20'+'\x20try\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20const'+'\x20data\x20=\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20limit:\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27limit\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20dns:\x20docu'+'ment.getEl'+'ementById('+'\x27dns\x27).val'+'ue,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20dire'+'ct:\x20docume'+'nt.getElem'+'entById(\x27d'+'irect\x27).va'+'lue,\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20cle'+'anip:\x20docu'+'ment.getEl'+'ementById('+'\x27cleanip\x27)'+'.value,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'domain:\x20do'+'cument.get'+'ElementByI'+'d(\x27domain\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20sni:\x20docu'+'ment.getEl'+'ementById('+'\x27sni\x27).val'+'ue,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20alpn'+':\x20document'+'.getElemen'+'tById(\x27alp'+'n\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20fingerp'+'rint:\x20docu'+'ment.getEl'+'ementById('+'\x27fingerpri'+'nt\x27).value'+',\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20ipver:'+'\x20document.'+'getElement'+'ById(\x27ipve'+'r\x27).value,'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20network'+':\x20document'+'.getElemen'+'tById(\x27net'+'work\x27).val'+'ue,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20tls:'+'\x20document.'+'getElement'+'ById(\x27tls\x27'+').value,\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20udp:\x20docu'+'ment.getEl'+'ementById('+('\x27udp\x27).val'+'ue,\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20frag'+'ment:\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20enable'+'d:\x20documen'+'t.getEleme'+'ntById(\x27fr'+'agment_ena'+'bled\x27).che'+'cked,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20packets:'+'\x20document.'+'getElement'+'ById(\x27frag'+'_packets\x27)'+'.value,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20length'+':\x20document'+'.getElemen'+'tById(\x27fra'+'g_length\x27)'+'.value,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20interv'+'al:\x20docume'+'nt.getElem'+'entById(\x27f'+'rag_interv'+'al\x27).value'+',\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20sl'+'eep:\x20docum'+'ent.getEle'+'mentById(\x27'+'frag_sleep'+'\x27).value,\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20}\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20};\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20const\x20re'+'sponse\x20=\x20a'+'wait\x20fetch'+'(\x27/api/set'+'tings\x27,\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20method:\x20'+'\x27POST\x27,\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'headers:\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x27Co'+'ntent-Type'+'\x27:\x20\x27applic'+'ation/json'+'\x27,\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20},\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'body:\x20JSON'+'.stringify'+'(data)\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20});\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20if\x20('+'response.o'+'k)\x20{\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20sho'+'wAlert(\x27Se'+'ttings\x20sav'+'ed\x20success'+'fully!\x27);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20generate'+'Subscribe('+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20}\x20else\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20showAler'+'t(\x27Error\x20s'+'aving\x20sett'+'ings!\x27,\x20tr'+'ue);\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20}\x0a\x20\x20\x20\x20}'+'\x20catch\x20(er'+'ror)\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20showA'+'lert(\x27Erro'+'r\x20saving\x20s'+'ettings!\x27,'+'\x20true);\x0a\x20\x20'+'\x20\x20}\x0a}\x0a\x0aasy'+'nc\x20functio'+'n\x20resetSet'+'tings()\x20{\x0a'+'\x20\x20\x20\x20const\x20'+'alertOverl')+('ay\x20=\x20docum'+'ent.create'+'Element(\x27d'+'iv\x27);\x0a\x20\x20\x20\x20'+'alertOverl'+'ay.style.p'+'osition\x20=\x20'+'\x27fixed\x27;\x0a\x20'+'\x20\x20\x20alertOv'+'erlay.styl'+'e.top\x20=\x20\x270'+'\x27;\x0a\x20\x20\x20\x20ale'+'rtOverlay.'+'style.left'+'\x20=\x20\x270\x27;\x0a\x20\x20'+'\x20\x20alertOve'+'rlay.style'+'.width\x20=\x20\x27'+'100%\x27;\x0a\x20\x20\x20'+'\x20alertOver'+'lay.style.'+'height\x20=\x20\x27'+'100%\x27;\x0a\x20\x20\x20'+'\x20alertOver'+'lay.style.'+'background'+'Color\x20=\x20\x27r'+'gba(0,\x200,\x20'+'0,\x200.7)\x27;\x0a'+'\x20\x20\x20\x20alertO'+'verlay.sty'+'le.display'+'\x20=\x20\x27flex\x27;'+'\x0a\x20\x20\x20\x20alert'+'Overlay.st'+'yle.justif'+'yContent\x20='+'\x20\x27center\x27;'+'\x0a\x20\x20\x20\x20alert'+'Overlay.st'+'yle.alignI'+'tems\x20=\x20\x27ce'+'nter\x27;\x0a\x20\x20\x20'+'\x20alertOver'+'lay.style.'+'zIndex\x20=\x20\x27'+'10000\x27;\x0a\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20con'+'st\x20alertBo'+'x\x20=\x20docume'+'nt.createE'+'lement(\x27di'+'v\x27);\x0a\x20\x20\x20\x20a'+'lertBox.st'+'yle.backgr'+'ound\x20=\x20\x27li'+'near-gradi'+'ent(135deg'+',\x20#f97316\x20'+'0%,\x20#ea580'+'c\x20100%)\x27;\x0a'+'\x20\x20\x20\x20alertB'+'ox.style.p'+'adding\x20=\x20\x27'+'25px\x27;\x0a\x20\x20\x20'+'\x20alertBox.'+'style.bord'+'erRadius\x20='+'\x20\x2715px\x27;\x0a\x20'+'\x20\x20\x20alertBo'+'x.style.bo'+'xShadow\x20=\x20'+'\x270\x204px\x2020p'+'x\x20rgba(0,\x20'+'0,\x200,\x200.3)'+'\x27;\x0a\x20\x20\x20\x20ale'+'rtBox.styl'+'e.color\x20=\x20'+'\x27white\x27;\x0a\x20'+'\x20\x20\x20alertBo'+'x.style.te'+'xtAlign\x20=\x20'+'\x27center\x27;\x0a'+'\x20\x20\x20\x20alertB'+'ox.style.m'+'axWidth\x20=\x20'+'\x27400px\x27;\x0a\x20'+'\x20\x20\x20alertBo'+'x.style.wi'+'dth\x20=\x20\x2790%'+'\x27;\x0a\x20\x20\x20\x20\x0a\x20\x20'+'\x20\x20const\x20me'+'ssage\x20=\x20do'+'cument.cre'+'ateElement'+'(\x27p\x27);\x0a\x20\x20\x20'+'\x20message.t'+'extContent'+'\x20=\x20\x27Are\x20yo'+'u\x20sure\x20you')+('\x20want\x20to\x20r'+'eset\x20all\x20s'+'ettings?\x27;'+'\x0a\x20\x20\x20\x20messa'+'ge.style.m'+'arginBotto'+'m\x20=\x20\x2720px\x27'+';\x0a\x20\x20\x20\x20mess'+'age.style.'+'fontSize\x20='+'\x20\x2716px\x27;\x0a\x20'+'\x20\x20\x20message'+'.style.fon'+'tWeight\x20=\x20'+'\x27600\x27;\x0a\x20\x20\x20'+'\x20\x0a\x20\x20\x20\x20cons'+'t\x20buttonCo'+'ntainer\x20=\x20'+'document.c'+'reateEleme'+'nt(\x27div\x27);'+'\x0a\x20\x20\x20\x20butto'+'nContainer'+'.style.dis'+'play\x20=\x20\x27fl'+'ex\x27;\x0a\x20\x20\x20\x20b'+'uttonConta'+'iner.style'+'.gap\x20=\x20\x2715'+'px\x27;\x0a\x20\x20\x20\x20b'+'uttonConta'+'iner.style'+'.justifyCo'+'ntent\x20=\x20\x27c'+'enter\x27;\x0a\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20con'+'st\x20confirm'+'Button\x20=\x20d'+'ocument.cr'+'eateElemen'+'t(\x27button\x27'+');\x0a\x20\x20\x20\x20con'+'firmButton'+'.textConte'+'nt\x20=\x20\x27Yes\x27'+';\x0a\x20\x20\x20\x20conf'+'irmButton.'+'style.padd'+'ing\x20=\x20\x2710p'+'x\x2020px\x27;\x0a\x20'+'\x20\x20\x20confirm'+'Button.sty'+'le.border\x20'+'=\x20\x27none\x27;\x0a'+'\x20\x20\x20\x20confir'+'mButton.st'+'yle.border'+'Radius\x20=\x20\x27'+'8px\x27;\x0a\x20\x20\x20\x20'+'confirmBut'+'ton.style.'+'background'+'\x20=\x20\x27linear'+'-gradient('+'135deg,\x20#e'+'f4444\x200%,\x20'+'#dc2626\x2010'+'0%)\x27;\x0a\x20\x20\x20\x20'+'confirmBut'+'ton.style.'+'color\x20=\x20\x27w'+'hite\x27;\x0a\x20\x20\x20'+'\x20confirmBu'+'tton.style'+'.cursor\x20=\x20'+'\x27pointer\x27;'+'\x0a\x20\x20\x20\x20confi'+'rmButton.s'+'tyle.fontW'+'eight\x20=\x20\x276'+'00\x27;\x0a\x0a\x20\x20\x20\x20'+'const\x20canc'+'elButton\x20='+'\x20document.'+'createElem'+'ent(\x27butto'+'n\x27);\x0a\x20\x20\x20\x20c'+'ancelButto'+'n.textCont'+'ent\x20=\x20\x27No\x27'+';\x0a\x20\x20\x20\x20canc'+'elButton.s'+'tyle.paddi'+'ng\x20=\x20\x2710px'+'\x2020px\x27;\x0a\x20\x20'+'\x20\x20cancelBu'+'tton.style'+'.border\x20=\x20'+'\x27none\x27;\x0a\x20\x20'+'\x20\x20cancelBu')+('tton.style'+'.borderRad'+'ius\x20=\x20\x278px'+'\x27;\x0a\x20\x20\x20\x20can'+'celButton.'+'style.back'+'ground\x20=\x20\x27'+'linear-gra'+'dient(135d'+'eg,\x20#22c55'+'e\x200%,\x20#16a'+'34a\x20100%)\x27'+';\x0a\x20\x20\x20\x20canc'+'elButton.s'+'tyle.color'+'\x20=\x20\x27white\x27'+';\x0a\x20\x20\x20\x20canc'+'elButton.s'+'tyle.curso'+'r\x20=\x20\x27point'+'er\x27;\x0a\x20\x20\x20\x20c'+'ancelButto'+'n.style.fo'+'ntWeight\x20='+'\x20\x27600\x27;\x0a\x20\x20'+'\x20\x20\x0a\x20\x20\x20\x20but'+'tonContain'+'er.appendC'+'hild(confi'+'rmButton);'+'\x0a\x20\x20\x20\x20butto'+'nContainer'+'.appendChi'+'ld(cancelB'+'utton);\x0a\x20\x20'+'\x20\x20alertBox'+'.appendChi'+'ld(message'+');\x0a\x20\x20\x20\x20ale'+'rtBox.appe'+'ndChild(bu'+'ttonContai'+'ner);\x0a\x20\x20\x20\x20'+'alertOverl'+'ay.appendC'+'hild(alert'+'Box);\x0a\x20\x20\x20\x20'+'document.b'+'ody.append'+'Child(aler'+'tOverlay);'+'\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20'+'return\x20new'+'\x20Promise(('+'resolve)\x20='+'>\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20confirmB'+'utton.oncl'+'ick\x20=\x20()\x20='+'>\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.body.'+'removeChil'+'d(alertOve'+'rlay);\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20r'+'esolve(tru'+'e);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20};\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20cancelBu'+'tton.oncli'+'ck\x20=\x20()\x20=>'+'\x20{\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.body.r'+'emoveChild'+'(alertOver'+'lay);\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20re'+'solve(fals'+'e);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20};\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20alertOve'+'rlay.oncli'+'ck\x20=\x20(e)\x20='+'>\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20if\x20('+'e.target\x20='+'==\x20alertOv'+'erlay)\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.body.r'+'emoveChild'+'(alertOver'+'lay);\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20resolve(')+('false);\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'}\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'};\x0a\x20\x20\x20\x20}).'+'then(async'+'\x20(confirme'+'d)\x20=>\x20{\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20if\x20('+'confirmed)'+'\x20{\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'limit\x27).va'+'lue\x20=\x20\x27all'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'dns\x27).valu'+'e\x20=\x20\x27\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.g'+'etElementB'+'yId(\x27direc'+'t\x27).value\x20'+'=\x20\x27\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27cleanip'+'\x27).value\x20='+'\x20\x27\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27domain\x27)'+'.value\x20=\x20\x27'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20docum'+'ent.getEle'+'mentById(\x27'+'sni\x27).valu'+'e\x20=\x20\x27\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.g'+'etElementB'+'yId(\x27alpn\x27'+').value\x20=\x20'+'\x27none\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.g'+'etElementB'+'yId(\x27finge'+'rprint\x27).v'+'alue\x20=\x20\x27no'+'ne\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27ipver\x27).'+'value\x20=\x20\x27n'+'one\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27network'+'\x27).value\x20='+'\x20\x27none\x27;\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27tls\x27'+').value\x20=\x20'+'\x27none\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'document.g'+'etElementB'+'yId(\x27udp\x27)'+'.value\x20=\x20\x27'+'none\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27fragme'+'nt_enabled'+'\x27).checked'+'\x20=\x20false;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27fra'+'g_packets\x27'+').value\x20=\x20'+'\x272-8\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_l'+'ength\x27).va')+('lue\x20=\x20\x27100'+'-300\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_i'+'nterval\x27).'+'value\x20=\x20\x271'+'0-30\x27;\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_s'+'leep\x27).val'+'ue\x20=\x20\x2750\x27;'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20togg'+'leFragment'+'Settings()'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20try'+'\x20{\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20a'+'wait\x20fetch'+'(\x27/api/set'+'tings\x27,\x20{\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'method:\x20\x27P'+'OST\x27,\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20head'+'ers:\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x27Content-'+'Type\x27:\x20\x27ap'+'plication/'+'json\x27,\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20},\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'body:\x20JSON'+'.stringify'+'({})\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20});\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20showAlert'+'(\x27Settings'+'\x20reset\x20suc'+'cessfully!'+'\x27);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'generateSu'+'bscribe();'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20}\x20catch'+'\x20(error)\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20sho'+'wAlert(\x27Er'+'ror\x20resett'+'ing\x20settin'+'gs!\x27,\x20true'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20}\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20}\x20els'+'e\x20{\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20show'+'Alert(\x27Res'+'et\x20cancell'+'ed\x27,\x20false'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20}\x0a\x20\x20\x20\x20});'+'\x0a}\x0a\x0afuncti'+'on\x20generat'+'eSubscribe'+'()\x20{\x0a\x20\x20\x20\x20c'+'onst\x20baseU'+'rl\x20=\x20windo'+'w.location'+'.origin;\x0a\x20'+'\x20\x20\x20documen'+'t.getEleme'+'ntById(\x27su'+'bscribe_v2'+'ray\x27).valu'+'e\x20=\x20baseUr'+'l\x20+\x20\x27/api/'+'configs\x27;\x0a'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27s'+'ubscribe_c'+'lash\x27).val'+'ue\x20=\x20baseU')+('rl\x20+\x20\x27/api'+'/configs?f'+'ormat=clas'+'h\x27;\x0a\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27subscri'+'be_singbox'+'\x27).value\x20='+'\x20baseUrl\x20+'+'\x20\x27/api/con'+'figs?forma'+'t=singbox\x27'+';\x0a}\x0a\x0aasync'+'\x20function\x20'+'copyToClip'+'board(elem'+'entId)\x20{\x0a\x20'+'\x20\x20\x20try\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20con'+'st\x20copyTex'+'t\x20=\x20docume'+'nt.getElem'+'entById(el'+'ementId);\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20co'+'pyText.sel'+'ect();\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20copyT'+'ext.setSel'+'ectionRang'+'e(0,\x2099999'+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20await\x20nav'+'igator.cli'+'pboard.wri'+'teText(cop'+'yText.valu'+'e);\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20showAler'+'t(\x27Copied\x20'+'to\x20clipboa'+'rd!\x27);\x0a\x20\x20\x20'+'\x20}\x20catch\x20('+'error)\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20sho'+'wAlert(\x27Fa'+'iled\x20to\x20co'+'py!\x27,\x20true'+');\x0a\x20\x20\x20\x20}\x0a}'+'\x0a\x0a\x20\x20\x20async'+'\x20function\x20'+'loadSettin'+'gs()\x20{\x0a\x20\x20\x20'+'\x20try\x20{\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20const'+'\x20response\x20'+'=\x20await\x20fe'+'tch(\x27/api/'+'settings\x27)'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'const\x20s\x20=\x20'+'await\x20resp'+'onse.json('+');\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'if\x20(s)\x20{\x0a\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27limi'+'t\x27).value\x20'+'=\x20s.limit\x20'+'||\x20\x27all\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27dns'+'\x27).value\x20='+'\x20s.dns\x20||\x20'+'\x27\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27direct\x27).'+'value\x20=\x20s.'+'direct\x20||\x20'+'\x27\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27cleanip\x27)'+'.value\x20=\x20s'+'.cleanip\x20|'+'|\x20\x27\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27domain\x27'+').value\x20=\x20')+('s.domain\x20|'+'|\x20\x27\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27sni\x27).v'+'alue\x20=\x20s.s'+'ni\x20||\x20\x27\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27alp'+'n\x27).value\x20'+'=\x20s.alpn\x20|'+'|\x20\x27none\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27fin'+'gerprint\x27)'+'.value\x20=\x20s'+'.fingerpri'+'nt\x20||\x20\x27non'+'e\x27;\x0a\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27ipver\x27).v'+'alue\x20=\x20s.i'+'pver\x20||\x20\x27n'+'one\x27;\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20do'+'cument.get'+'ElementByI'+'d(\x27network'+'\x27).value\x20='+'\x20s.network'+'\x20||\x20\x27none\x27'+';\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27t'+'ls\x27).value'+'\x20=\x20s.tls\x20|'+'|\x20\x27none\x27;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20document'+'.getElemen'+'tById(\x27udp'+'\x27).value\x20='+'\x20s.udp\x20||\x20'+'\x27none\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20if\x20(s.f'+'ragment)\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20doc'+'ument.getE'+'lementById'+'(\x27fragment'+'_enabled\x27)'+'.checked\x20='+'\x20s.fragmen'+'t.enabled\x20'+'||\x20false;\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20docu'+'ment.getEl'+'ementById('+'\x27frag_pack'+'ets\x27).valu'+'e\x20=\x20s.frag'+'ment.packe'+'ts\x20||\x20\x272-8'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20d'+'ocument.ge'+'tElementBy'+'Id(\x27frag_l'+'ength\x27).va'+'lue\x20=\x20s.fr'+'agment.len'+'gth\x20||\x20\x2710'+'0-300\x27;\x0a\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20docume'+'nt.getElem'+'entById(\x27f'+'rag_interv'+'al\x27).value'+'\x20=\x20s.fragm'+'ent.interv'+'al\x20||\x20\x2710-'+'30\x27;\x0a\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+'\x20document.'+'getElement'+'ById(\x27frag'+'_sleep\x27).v')+('alue\x20=\x20s.f'+'ragment.sl'+'eep\x20||\x20\x2750'+'\x27;\x0a\x20\x20\x20\x20\x20\x20\x20'+'\x20\x20\x20\x20\x20}\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20}\x0a\x20\x20\x20'+'\x20\x20\x20\x20\x20\x0a\x20\x20\x20\x20'+'\x20\x20\x20\x20toggle'+'FragmentSe'+'ttings();\x0a'+'\x20\x20\x20\x20\x20\x20\x20\x20ge'+'nerateSubs'+'cribe();\x0a\x20'+'\x20\x20\x20}\x20catch'+'\x20(error)\x20{'+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20c'+'onsole.err'+'or(\x27Error\x20'+'loading\x20se'+'ttings:\x27,\x20'+'error);\x0a\x20\x20'+'\x20\x20}\x0a}\x0a\x0adoc'+'ument.getE'+'lementById'+'(\x27fragment'+'_enabled\x27)'+'.addEventL'+'istener(\x27c'+'hange\x27,\x20to'+'ggleFragme'+'ntSettings'+');\x0awindow.'+'onload\x20=\x20l'+'oadSetting'+'s;\x0a</scrip'+'t>\x0a</body>'+'\x0a</html>'));}


//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
//This is a decompiled and commented version of the original obfuscated code
//==============================================
//----------------------------
//SECTION 1: OBFUSCATION WRAPPERS AND ANTI-DEBUGGING
//----------------------------
//==============================================
//ARISTA CONFIG GENERATOR - OBFUSCATED CODE
